package com.qrx.scanner.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.absoluteOffset
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.material3.MaterialTheme
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Row with two swipe actions using physical directions (right = [onSwipeRight], left = [onSwipeLeft]),
 * independent of the layout direction. A right swipe springs back after firing; a left swipe slides out.
 */
@Composable
fun SwipeableRow(
    rightActionLabel: String,
    leftActionLabel: String,
    onSwipeRight: () -> Unit,
    onSwipeLeft: () -> Unit,
    rightBackground: @Composable BoxScope.() -> Unit,
    leftBackground: @Composable BoxScope.() -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val contentDirection = LocalLayoutDirection.current
    val offset = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var widthPx by remember { mutableFloatStateOf(0f) }
    val currentRight = rememberUpdatedState(onSwipeRight)
    val currentLeft = rememberUpdatedState(onSwipeLeft)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(
            modifier = modifier
                .clip(MaterialTheme.shapes.large)
                .onSizeChanged { widthPx = it.width.toFloat() }
                .semantics {
                    customActions = listOf(
                        CustomAccessibilityAction(rightActionLabel) {
                            currentRight.value()
                            true
                        },
                        CustomAccessibilityAction(leftActionLabel) {
                            currentLeft.value()
                            true
                        },
                    )
                },
        ) {
            if (offset.value > 0f) Box(Modifier.matchParentSize(), content = rightBackground)
            if (offset.value < 0f) Box(Modifier.matchParentSize(), content = leftBackground)

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .absoluteOffset { IntOffset(offset.value.roundToInt(), 0) }
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures(
                            onDragEnd = {
                                val threshold = widthPx * TRIGGER_FRACTION
                                val current = offset.value
                                scope.launch {
                                    when {
                                        current > threshold -> {
                                            currentRight.value()
                                            offset.animateTo(0f, tween(SETTLE_MILLIS))
                                        }
                                        current < -threshold -> {
                                            offset.animateTo(-widthPx, tween(SETTLE_MILLIS))
                                            currentLeft.value()
                                        }
                                        else -> offset.animateTo(0f, tween(SETTLE_MILLIS))
                                    }
                                }
                            },
                            onDragCancel = { scope.launch { offset.animateTo(0f, tween(SETTLE_MILLIS)) } },
                            onHorizontalDrag = { change, dragAmount ->
                                change.consume()
                                val target = (offset.value + dragAmount).coerceIn(-widthPx, widthPx)
                                if (abs(target - offset.value) > 0f) scope.launch { offset.snapTo(target) }
                            },
                        )
                    },
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides contentDirection) { content() }
            }
        }
    }
}

private const val TRIGGER_FRACTION = 0.32f
private const val SETTLE_MILLIS = 180
