package com.qrx.scanner.generator

import com.qrx.scanner.domain.model.WifiSecurity
import com.qrx.scanner.domain.parser.TextCodec
import com.qrx.scanner.domain.parser.UrlParser
import java.util.Locale
import javax.inject.Inject

/** Validates form input and builds the standard payload string for each QR type. Pure Kotlin. */
class QrPayloadBuilder @Inject constructor() {

    fun build(input: CreateInput): PayloadResult = when (input) {
        is CreateInput.Website -> website(input)
        is CreateInput.Text -> text(input)
        is CreateInput.Wifi -> wifi(input)
        is CreateInput.Contact -> contact(input)
        is CreateInput.Phone -> phone(input)
        is CreateInput.Email -> email(input)
        is CreateInput.Sms -> sms(input)
        is CreateInput.Location -> location(input)
    }

    private fun website(input: CreateInput.Website): PayloadResult {
        val url = input.url.trim()
        if (url.isEmpty()) return error(InputError.EMPTY)
        return normalizeUrl(url)?.let(::success) ?: error(InputError.INVALID_URL)
    }

    private fun text(input: CreateInput.Text): PayloadResult {
        if (input.text.isBlank()) return error(InputError.EMPTY)
        if (input.text.length > MAX_TEXT_LENGTH) return error(InputError.TOO_LONG)
        return success(input.text)
    }

    private fun wifi(input: CreateInput.Wifi): PayloadResult {
        val ssid = input.ssid.trim()
        if (ssid.isEmpty()) {
            return error(if (input.password.isEmpty()) InputError.EMPTY else InputError.MISSING_SSID)
        }
        val needsPassword = input.security != WifiSecurity.OPEN
        if (needsPassword && input.password.isEmpty()) return error(InputError.MISSING_PASSWORD)

        val type = when (input.security) {
            WifiSecurity.OPEN -> "nopass"
            WifiSecurity.WEP -> "WEP"
            WifiSecurity.WPA, WifiSecurity.EAP -> "WPA"
            WifiSecurity.WPA3 -> "SAE"
        }
        val payload = buildString {
            append("WIFI:T:").append(type).append(";S:").append(escapeWifi(ssid)).append(';')
            if (needsPassword) append("P:").append(escapeWifi(input.password)).append(';')
            if (input.hidden) append("H:true;")
            append(';')
        }
        return success(payload)
    }

    private fun contact(input: CreateInput.Contact): PayloadResult {
        val name = input.name.trim()
        val fields = listOf(
            name, input.phone, input.email, input.organization, input.jobTitle,
            input.address, input.website, input.note,
        )
        if (fields.all { it.isBlank() }) return error(InputError.EMPTY)
        if (name.isEmpty()) return error(InputError.MISSING_NAME)

        val phone = input.phone.trim()
        val email = input.email.trim()
        val website = input.website.trim()
        val cleanedPhone = if (phone.isEmpty()) null else cleanPhone(phone) ?: return error(InputError.INVALID_PHONE)
        if (email.isNotEmpty() && !EMAIL.matches(email)) return error(InputError.INVALID_EMAIL)
        val normalizedWebsite = if (website.isEmpty()) null else normalizeUrl(website) ?: return error(InputError.INVALID_URL)

        val words = name.split(Regex("\\s+"))
        val family = if (words.size > 1) words.last() else ""
        val given = if (words.size > 1) words.dropLast(1).joinToString(" ") else words.first()

        val payload = buildString {
            append("BEGIN:VCARD\n")
            append("VERSION:3.0\n")
            append("N:").append(escapeVCard(family)).append(';').append(escapeVCard(given)).append(";;;\n")
            append("FN:").append(escapeVCard(name)).append('\n')
            if (input.organization.isNotBlank()) append("ORG:").append(escapeVCard(input.organization.trim())).append('\n')
            if (input.jobTitle.isNotBlank()) append("TITLE:").append(escapeVCard(input.jobTitle.trim())).append('\n')
            if (cleanedPhone != null) append("TEL;TYPE=CELL:").append(cleanedPhone).append('\n')
            if (email.isNotEmpty()) append("EMAIL:").append(escapeVCard(email)).append('\n')
            if (input.address.isNotBlank()) append("ADR;TYPE=WORK:;;").append(escapeVCard(input.address.trim())).append(";;;;\n")
            if (normalizedWebsite != null) append("URL:").append(normalizedWebsite).append('\n')
            if (input.note.isNotBlank()) append("NOTE:").append(escapeVCard(input.note.trim())).append('\n')
            append("END:VCARD")
        }
        return success(payload)
    }

    private fun phone(input: CreateInput.Phone): PayloadResult {
        if (input.number.isBlank()) return error(InputError.EMPTY)
        val cleaned = cleanPhone(input.number) ?: return error(InputError.INVALID_PHONE)
        return success("tel:$cleaned")
    }

    private fun email(input: CreateInput.Email): PayloadResult {
        val address = input.address.trim()
        if (address.isEmpty()) return error(InputError.EMPTY)
        if (!EMAIL.matches(address)) return error(InputError.INVALID_EMAIL)
        val params = buildList {
            if (input.subject.isNotBlank()) add("subject=" + TextCodec.percentEncode(input.subject.trim()))
            if (input.body.isNotBlank()) add("body=" + TextCodec.percentEncode(input.body.trim()))
        }
        return success("mailto:$address" + if (params.isEmpty()) "" else "?" + params.joinToString("&"))
    }

    private fun sms(input: CreateInput.Sms): PayloadResult {
        if (input.number.isBlank()) return error(InputError.EMPTY)
        val cleaned = cleanPhone(input.number) ?: return error(InputError.INVALID_PHONE)
        val message = input.message.trim()
        return success("sms:$cleaned" + if (message.isEmpty()) "" else "?body=" + TextCodec.percentEncode(message))
    }

    private fun location(input: CreateInput.Location): PayloadResult {
        val rawLatitude = input.latitude.trim()
        val rawLongitude = input.longitude.trim()
        if (rawLatitude.isEmpty() && rawLongitude.isEmpty()) return error(InputError.EMPTY)
        val latitude = parseCoordinate(rawLatitude)
        val longitude = parseCoordinate(rawLongitude)
        if (latitude == null || longitude == null || latitude !in -90.0..90.0 || longitude !in -180.0..180.0) {
            return error(InputError.INVALID_COORDINATES)
        }
        val label = input.label.trim()
        val base = "geo:${formatCoordinate(latitude)},${formatCoordinate(longitude)}"
        return success(if (label.isEmpty()) base else base + "?q=" + TextCodec.percentEncode(label))
    }

    // region helpers

    /** Adds https:// when no scheme is present. Only http(s) with a plausible host is accepted. */
    internal fun normalizeUrl(value: String): String? {
        if (value.any { it.isWhitespace() }) return null
        val lower = value.lowercase(Locale.ROOT)
        val candidate = when {
            lower.startsWith("http://") || lower.startsWith("https://") -> value
            value.contains("://") -> return null
            else -> "https://$value"
        }
        val parts = UrlParser.parse(candidate) ?: return null
        return if (isPlausibleHost(parts.host)) candidate else null
    }

    private fun isPlausibleHost(host: String): Boolean {
        if (host.isEmpty()) return false
        if (host == "localhost" || IPV4.matches(host)) return true
        val labels = host.split('.')
        if (labels.size < 2) return false
        return labels.all { label ->
            label.isNotEmpty() &&
                !label.startsWith('-') &&
                !label.endsWith('-') &&
                label.all { it.isLetterOrDigit() || it == '-' }
        }
    }

    private fun cleanPhone(value: String): String? {
        val cleaned = TextCodec.normalizeDigits(value.trim()).replace(Regex("[\\s().-]"), "")
        return cleaned.takeIf { PHONE.matches(it) }
    }

    private fun parseCoordinate(value: String): Double? {
        if (value.isEmpty()) return null
        var normalized = TextCodec.normalizeDigits(value)
        if (normalized.contains(',') && !normalized.contains('.')) normalized = normalized.replace(',', '.')
        return normalized.toDoubleOrNull()?.takeIf { it.isFinite() }
    }

    private fun formatCoordinate(value: Double): String {
        val text = String.format(Locale.US, "%.6f", value).trimEnd('0').trimEnd('.')
        return if (text == "-0" || text.isEmpty()) "0" else text
    }

    private fun escapeWifi(value: String): String {
        val out = StringBuilder(value.length + 4)
        for (char in value) {
            if (char == '\\' || char == ';' || char == ',' || char == ':' || char == '"') out.append('\\')
            out.append(char)
        }
        return out.toString()
    }

    private fun escapeVCard(value: String): String {
        val out = StringBuilder(value.length + 4)
        for (char in value) {
            when (char) {
                '\\' -> out.append("\\\\")
                ';' -> out.append("\\;")
                ',' -> out.append("\\,")
                '\n' -> out.append("\\n")
                '\r' -> Unit
                else -> out.append(char)
            }
        }
        return out.toString()
    }

    private fun success(payload: String): PayloadResult = PayloadResult.Success(payload)
    private fun error(error: InputError): PayloadResult = PayloadResult.Error(error)

    // endregion

    private companion object {
        const val MAX_TEXT_LENGTH = 2_000
        val EMAIL = Regex("^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$")
        val PHONE = Regex("^\\+?[0-9*#]{3,20}$")
        val IPV4 = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")
    }
}
