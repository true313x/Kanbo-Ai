package com.qrx.scanner.core.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.room.Room
import com.qrx.scanner.core.DispatcherProvider
import com.qrx.scanner.core.StandardDispatcherProvider
import com.qrx.scanner.core.SystemTimeProvider
import com.qrx.scanner.core.TimeProvider
import com.qrx.scanner.data.settings.settingsDataStore
import com.qrx.scanner.database.QrxDatabase
import com.qrx.scanner.database.ScanHistoryDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): QrxDatabase =
        Room.databaseBuilder(context, QrxDatabase::class.java, QrxDatabase.NAME).build()

    @Provides
    fun provideScanHistoryDao(database: QrxDatabase): ScanHistoryDao = database.scanHistoryDao()

    @Provides
    @Singleton
    fun provideSettingsDataStore(@ApplicationContext context: Context): DataStore<Preferences> =
        context.settingsDataStore

    @Provides
    fun provideTimeProvider(): TimeProvider = SystemTimeProvider

    @Provides
    fun provideDispatchers(): DispatcherProvider = StandardDispatcherProvider
}
