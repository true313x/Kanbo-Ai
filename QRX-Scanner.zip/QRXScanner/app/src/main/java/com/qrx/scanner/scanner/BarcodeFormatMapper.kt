package com.qrx.scanner.scanner

import com.google.mlkit.vision.barcode.common.Barcode
import com.qrx.scanner.domain.model.CodeFormat
import com.qrx.scanner.domain.model.ScanMode

/** Translates between ML Kit format constants, our [CodeFormat] and the user's [ScanMode]. */
object BarcodeFormatMapper {

    fun toCodeFormat(mlKitFormat: Int): CodeFormat? = when (mlKitFormat) {
        Barcode.FORMAT_QR_CODE -> CodeFormat.QR_CODE
        Barcode.FORMAT_AZTEC -> CodeFormat.AZTEC
        Barcode.FORMAT_CODABAR -> CodeFormat.CODABAR
        Barcode.FORMAT_CODE_39 -> CodeFormat.CODE_39
        Barcode.FORMAT_CODE_93 -> CodeFormat.CODE_93
        Barcode.FORMAT_CODE_128 -> CodeFormat.CODE_128
        Barcode.FORMAT_DATA_MATRIX -> CodeFormat.DATA_MATRIX
        Barcode.FORMAT_EAN_8 -> CodeFormat.EAN_8
        Barcode.FORMAT_EAN_13 -> CodeFormat.EAN_13
        Barcode.FORMAT_ITF -> CodeFormat.ITF
        Barcode.FORMAT_UPC_A -> CodeFormat.UPC_A
        Barcode.FORMAT_UPC_E -> CodeFormat.UPC_E
        Barcode.FORMAT_PDF417 -> CodeFormat.PDF_417
        else -> null
    }

    fun toMlKitFormat(format: CodeFormat): Int = when (format) {
        CodeFormat.QR_CODE -> Barcode.FORMAT_QR_CODE
        CodeFormat.AZTEC -> Barcode.FORMAT_AZTEC
        CodeFormat.CODABAR -> Barcode.FORMAT_CODABAR
        CodeFormat.CODE_39 -> Barcode.FORMAT_CODE_39
        CodeFormat.CODE_93 -> Barcode.FORMAT_CODE_93
        CodeFormat.CODE_128 -> Barcode.FORMAT_CODE_128
        CodeFormat.DATA_MATRIX -> Barcode.FORMAT_DATA_MATRIX
        CodeFormat.EAN_8 -> Barcode.FORMAT_EAN_8
        CodeFormat.EAN_13 -> Barcode.FORMAT_EAN_13
        CodeFormat.ITF -> Barcode.FORMAT_ITF
        CodeFormat.UPC_A -> Barcode.FORMAT_UPC_A
        CodeFormat.UPC_E -> Barcode.FORMAT_UPC_E
        CodeFormat.PDF_417 -> Barcode.FORMAT_PDF417
    }

    /** The set of formats ML Kit should look for in the given scan mode. */
    fun formatsFor(mode: ScanMode): List<CodeFormat> = when (mode) {
        ScanMode.AUTO -> CodeFormat.entries
        ScanMode.QR_ONLY -> listOf(CodeFormat.QR_CODE)
        ScanMode.BARCODE_ONLY -> CodeFormat.entries.filter { it != CodeFormat.QR_CODE }
    }
}
