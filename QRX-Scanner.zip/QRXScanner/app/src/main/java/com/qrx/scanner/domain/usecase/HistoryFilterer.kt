package com.qrx.scanner.domain.usecase

import com.qrx.scanner.domain.model.CodeFormat
import com.qrx.scanner.domain.model.ContentType
import com.qrx.scanner.domain.model.HistoryFilter
import com.qrx.scanner.domain.model.ScanRecord
import java.util.Locale

/** Pure in-memory filtering/searching of history. Type labels are supplied by the UI so they are localised. */
object HistoryFilterer {

    fun apply(
        records: List<ScanRecord>,
        filter: HistoryFilter,
        query: String,
        typeLabel: (ContentType) -> String,
    ): List<ScanRecord> {
        val needle = query.trim().lowercase(Locale.ROOT)
        return records.filter { record ->
            matchesFilter(record, filter) && (needle.isEmpty() || matchesQuery(record, needle, typeLabel))
        }
    }

    fun matchesFilter(record: ScanRecord, filter: HistoryFilter): Boolean = when (filter) {
        HistoryFilter.ALL -> true
        HistoryFilter.QR -> record.format == CodeFormat.QR_CODE
        HistoryFilter.BARCODE -> record.format != CodeFormat.QR_CODE
        HistoryFilter.URLS -> record.type == ContentType.URL
        HistoryFilter.TEXT -> record.type == ContentType.TEXT
        HistoryFilter.WIFI -> record.type == ContentType.WIFI
        HistoryFilter.CONTACTS -> record.type == ContentType.CONTACT
        HistoryFilter.OTHER -> record.type in OTHER_TYPES
    }

    private fun matchesQuery(record: ScanRecord, needle: String, typeLabel: (ContentType) -> String): Boolean =
        record.displayValue.lowercase(Locale.ROOT).contains(needle) ||
            record.rawValue.lowercase(Locale.ROOT).contains(needle) ||
            record.format.displayName.lowercase(Locale.ROOT).contains(needle) ||
            typeLabel(record.type).lowercase(Locale.ROOT).contains(needle)

    private val OTHER_TYPES = setOf(
        ContentType.PHONE,
        ContentType.EMAIL,
        ContentType.SMS,
        ContentType.GEO,
        ContentType.BARCODE,
    )
}
