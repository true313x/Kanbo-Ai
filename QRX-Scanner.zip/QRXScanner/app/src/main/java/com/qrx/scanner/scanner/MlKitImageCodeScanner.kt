package com.qrx.scanner.scanner

import android.graphics.Bitmap
import android.net.Uri
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.NotFoundException
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.GlobalHistogramBinarizer
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.multi.GenericMultipleBarcodeReader
import com.qrx.scanner.core.DispatcherProvider
import com.qrx.scanner.domain.model.CodeFormat
import com.qrx.scanner.domain.model.DetectedCode
import com.qrx.scanner.util.awaitResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withContext
import javax.inject.Inject

/** ML Kit first (fast, robust); ZXing as a second opinion for images ML Kit cannot decode. */
class MlKitImageCodeScanner @Inject constructor(
    private val bitmapLoader: BitmapLoader,
    private val dispatchers: DispatcherProvider,
) : ImageCodeScanner {

    override suspend fun scan(uri: Uri): ImageScanResult {
        val bitmap = bitmapLoader.load(uri, MAX_SIDE_PX) ?: return ImageScanResult.Unreadable
        val mlKitCodes = scanWithMlKit(bitmap)
        if (!mlKitCodes.isNullOrEmpty()) return ImageScanResult.Found(mlKitCodes)

        val zxingCodes = withContext(dispatchers.default) { scanWithZxing(bitmap) }
        return when {
            zxingCodes.isNotEmpty() -> ImageScanResult.Found(zxingCodes)
            mlKitCodes == null -> ImageScanResult.Unreadable
            else -> ImageScanResult.NoCode
        }
    }

    /** Returns null when ML Kit itself failed, an empty list when it ran but found nothing. */
    private suspend fun scanWithMlKit(bitmap: Bitmap): List<DetectedCode>? {
        val options = BarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
            .build()
        val client = BarcodeScanning.getClient(options)
        return try {
            client.process(InputImage.fromBitmap(bitmap, 0)).awaitResult()
                .sortedWith(compareBy({ it.boundingBox?.top ?: 0 }, { it.boundingBox?.left ?: 0 }))
                .mapNotNull { barcode ->
                    val format = BarcodeFormatMapper.toCodeFormat(barcode.format) ?: return@mapNotNull null
                    val value = barcode.rawValue?.takeIf { it.isNotEmpty() } ?: return@mapNotNull null
                    DetectedCode(value, format)
                }
                .distinct()
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            null
        } finally {
            client.close()
        }
    }

    private fun scanWithZxing(bitmap: Bitmap): List<DetectedCode> {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        val source = RGBLuminanceSource(width, height, pixels)

        val hints = mapOf<DecodeHintType, Any>(
            DecodeHintType.TRY_HARDER to true,
            DecodeHintType.ALSO_INVERTED to true,
            DecodeHintType.POSSIBLE_FORMATS to CodeFormat.entries.map(ZxingFormatMapper::toZxing),
        )
        val reader = GenericMultipleBarcodeReader(MultiFormatReader())
        val found = LinkedHashSet<DetectedCode>()
        for (binarizer in listOf(HybridBinarizer(source), GlobalHistogramBinarizer(source))) {
            try {
                for (result in reader.decodeMultiple(BinaryBitmap(binarizer), hints)) {
                    val format = ZxingFormatMapper.toCodeFormat(result.barcodeFormat) ?: continue
                    if (result.text.isNotEmpty()) found += DetectedCode(result.text, format)
                }
            } catch (error: NotFoundException) {
                continue
            }
            if (found.isNotEmpty()) break
        }
        return found.toList()
    }

    private companion object {
        const val MAX_SIDE_PX = 3072
    }
}
