package com.qrx.scanner.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Space that scrolling content must leave at the bottom: the floating navigation bar plus the system
 * navigation inset when the bar is visible, or just the inset otherwise.
 */
val LocalContentBottomPadding = compositionLocalOf { 0.dp }

/** Top and horizontal system insets (status bar, display cutout, side bars). Bottom is handled by content. */
@Composable
fun Modifier.screenInsets(): Modifier = windowInsetsPadding(
    WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal),
)

val ScreenHorizontalPadding: Dp = 20.dp

/** Keeps forms and lists readable on tablets and in landscape. */
val ContentMaxWidth: Dp = 640.dp
