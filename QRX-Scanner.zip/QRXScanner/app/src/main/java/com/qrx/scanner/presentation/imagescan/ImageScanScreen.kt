package com.qrx.scanner.presentation.imagescan

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.BrokenImage
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.qrx.scanner.R
import com.qrx.scanner.domain.model.DetectedCode
import com.qrx.scanner.ui.components.ContentMaxWidth
import com.qrx.scanner.ui.components.EmptyState
import com.qrx.scanner.ui.components.EmptyStateAction
import com.qrx.scanner.ui.components.LocalContentBottomPadding
import com.qrx.scanner.ui.components.ObserveEvents
import com.qrx.scanner.ui.components.ScreenHeader
import com.qrx.scanner.ui.components.icon
import com.qrx.scanner.ui.components.labelRes
import com.qrx.scanner.ui.components.screenInsets

@Composable
fun ImageScanScreen(
    uri: Uri,
    onBack: () -> Unit,
    onOpenCode: (DetectedCode) -> Unit,
    onOpenSingleCode: (DetectedCode) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: ImageScanViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val currentOnSingle by rememberUpdatedState(onOpenSingleCode)

    LaunchedEffect(uri) { viewModel.load(uri) }
    ObserveEvents(viewModel.singleCode) { code -> currentOnSingle(code) }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { picked ->
        if (picked != null) viewModel.load(picked, force = true)
    }
    val choose = { pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }

    Column(modifier = modifier.fillMaxSize().screenInsets()) {
        ScreenHeader(title = stringResource(R.string.image_scan_title), onBack = onBack)
        val bottom = LocalContentBottomPadding.current
        when (val current = state) {
            ImageScanState.Loading -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    CircularProgressIndicator()
                    Text(
                        text = stringResource(R.string.image_scan_loading),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            is ImageScanState.Found -> FoundList(current.codes, bottom, onOpenCode, Modifier.weight(1f))
            ImageScanState.NoCode -> EmptyState(
                icon = Icons.Rounded.QrCodeScanner,
                title = stringResource(R.string.image_scan_none_title),
                message = stringResource(R.string.image_scan_none_message),
                primaryAction = EmptyStateAction(stringResource(R.string.action_try_again)) { viewModel.retry() },
                secondaryAction = EmptyStateAction(stringResource(R.string.action_choose_image), choose),
                modifier = Modifier.weight(1f).padding(bottom = bottom),
            )
            ImageScanState.Unreadable -> EmptyState(
                icon = Icons.Rounded.BrokenImage,
                title = stringResource(R.string.image_scan_unreadable_title),
                message = stringResource(R.string.image_scan_unreadable_message),
                primaryAction = EmptyStateAction(stringResource(R.string.action_try_again)) { viewModel.retry() },
                secondaryAction = EmptyStateAction(stringResource(R.string.action_choose_image), choose),
                modifier = Modifier.weight(1f).padding(bottom = bottom),
            )
        }
    }
}

@Composable
private fun FoundList(
    codes: List<FoundCode>,
    bottomPadding: Dp,
    onOpenCode: (DetectedCode) -> Unit,
    modifier: Modifier = Modifier,
) {
    val resources = LocalContext.current.resources
    Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.widthIn(max = ContentMaxWidth).fillMaxSize(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = 4.dp,
                bottom = bottomPadding + 16.dp,
            ),
        ) {
            item {
                Text(
                    text = resources.getQuantityString(R.plurals.codes_found, codes.size, codes.size),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(bottom = 6.dp),
                )
            }
            items(codes, key = { "${it.code.format.name}:${it.code.rawValue}" }) { found ->
                FoundCodeRow(found, onClick = { onOpenCode(found.code) })
            }
        }
    }
}

@Composable
private fun FoundCodeRow(found: FoundCode, onClick: () -> Unit) {
    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth().clip(MaterialTheme.shapes.large).clickable(role = Role.Button, onClick = onClick),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.padding(14.dp),
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
            ) {
                Icon(
                    imageVector = found.content.type.icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(22.dp),
                )
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = found.content.displayValue.ifBlank { found.code.rawValue },
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = stringResource(R.string.type_and_format, stringResource(found.content.type.labelRes), found.code.format.displayName),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
