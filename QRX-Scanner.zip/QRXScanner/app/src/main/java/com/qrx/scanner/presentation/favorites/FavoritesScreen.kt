package com.qrx.scanner.presentation.favorites

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.qrx.scanner.R
import com.qrx.scanner.presentation.history.SwipeableHistoryItem
import com.qrx.scanner.ui.components.ContentMaxWidth
import com.qrx.scanner.ui.components.EmptyState
import com.qrx.scanner.ui.components.LocalContentBottomPadding
import com.qrx.scanner.ui.components.ObserveEvents
import com.qrx.scanner.ui.components.ScreenHeader
import com.qrx.scanner.ui.components.screenInsets
import kotlinx.coroutines.launch

@Composable
fun FavoritesScreen(
    onBack: () -> Unit,
    onOpenRecord: (Long) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: FavoritesViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val deletedMessage = stringResource(R.string.history_deleted)
    val undoLabel = stringResource(R.string.action_undo)
    ObserveEvents(viewModel.events) { event ->
        when (event) {
            FavoritesEvent.Deleted -> scope.launch {
                snackbar.currentSnackbarData?.dismiss()
                val result = snackbar.showSnackbar(
                    message = deletedMessage,
                    actionLabel = undoLabel,
                    duration = SnackbarDuration.Short,
                )
                if (result == SnackbarResult.ActionPerformed) viewModel.undoDelete()
            }
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().screenInsets()) {
            ScreenHeader(title = stringResource(R.string.favorites_title), onBack = onBack)
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                when {
                    state.isLoading -> Unit
                    state.records.isEmpty() -> EmptyState(
                        icon = Icons.Rounded.StarBorder,
                        title = stringResource(R.string.favorites_empty_title),
                        message = stringResource(R.string.favorites_empty_message),
                        modifier = Modifier.fillMaxSize().padding(bottom = LocalContentBottomPadding.current),
                    )
                    else -> LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(
                            start = 20.dp,
                            end = 20.dp,
                            top = 4.dp,
                            bottom = LocalContentBottomPadding.current + 16.dp,
                        ),
                        modifier = Modifier.widthIn(max = ContentMaxWidth).fillMaxSize(),
                    ) {
                        items(state.records, key = { it.id }) { record ->
                            SwipeableHistoryItem(
                                record = record,
                                onClick = { onOpenRecord(record.id) },
                                onToggleFavorite = { viewModel.toggleFavorite(record) },
                                onDelete = { viewModel.delete(record) },
                                modifier = Modifier.animateItem(),
                            )
                        }
                    }
                }
            }
        }
        SnackbarHost(
            hostState = snackbar,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = LocalContentBottomPadding.current)
                .padding(horizontal = 16.dp),
        )
    }
}
