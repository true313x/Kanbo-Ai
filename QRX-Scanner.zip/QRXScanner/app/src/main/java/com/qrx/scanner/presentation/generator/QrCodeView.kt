package com.qrx.scanner.presentation.generator

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.qrx.scanner.generator.QrLogoGeometry
import com.qrx.scanner.generator.QrMatrix
import kotlin.math.min
import kotlin.math.roundToInt

/** Draws a QR matrix with the same geometry the exporter uses, so what you see is what you save. */
@Composable
fun QrCodeView(
    matrix: QrMatrix,
    foreground: Color,
    background: Color,
    logo: Bitmap?,
    description: String,
    modifier: Modifier = Modifier,
) {
    val logoImage = remember(logo) { logo?.asImageBitmap() }
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .semantics { contentDescription = description },
    ) {
        drawRect(color = background)
        val module = size.width / matrix.size
        val overlap = 0.6f
        for (y in 0 until matrix.size) {
            for (x in 0 until matrix.size) {
                if (matrix[x, y]) {
                    drawRect(
                        color = foreground,
                        topLeft = Offset(x * module, y * module),
                        size = Size(module + overlap, module + overlap),
                    )
                }
            }
        }
        if (logoImage != null) {
            val dataSide = matrix.dataSize * module
            val plate = dataSide * QrLogoGeometry.PLATE_FRACTION
            val center = size.width / 2f
            drawRoundRect(
                color = background,
                topLeft = Offset(center - plate / 2f, center - plate / 2f),
                size = Size(plate, plate),
                cornerRadius = CornerRadius(plate * 0.22f),
            )
            val logoSide = dataSide * QrLogoGeometry.LOGO_FRACTION
            val fit = min(logoSide / logoImage.width, logoSide / logoImage.height)
            val width = (logoImage.width * fit).roundToInt()
            val height = (logoImage.height * fit).roundToInt()
            drawImage(
                image = logoImage,
                dstOffset = IntOffset((center - width / 2f).roundToInt(), (center - height / 2f).roundToInt()),
                dstSize = IntSize(width, height),
                filterQuality = FilterQuality.High,
            )
        }
    }
}
