package com.qrx.scanner.database

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [ScanHistory::class],
    version = 1,
    exportSchema = true,
)
abstract class QrxDatabase : RoomDatabase() {
    abstract fun scanHistoryDao(): ScanHistoryDao

    companion object {
        const val NAME = "qrx.db"
    }
}
