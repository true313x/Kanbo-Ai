package com.qrx.scanner.data.repository

import com.qrx.scanner.data.mapper.ScanHistoryMapper
import com.qrx.scanner.database.ScanHistoryDao
import com.qrx.scanner.domain.model.ScanRecord
import com.qrx.scanner.domain.repository.HistoryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class HistoryRepositoryImpl @Inject constructor(
    private val dao: ScanHistoryDao,
) : HistoryRepository {

    override fun observeAll(): Flow<List<ScanRecord>> =
        dao.observeAll().map { list -> list.map(ScanHistoryMapper::toDomain) }

    override fun observeFavorites(): Flow<List<ScanRecord>> =
        dao.observeFavorites().map { list -> list.map(ScanHistoryMapper::toDomain) }

    override fun observeById(id: Long): Flow<ScanRecord?> =
        dao.observeById(id).map { entity -> entity?.let(ScanHistoryMapper::toDomain) }

    override suspend fun getById(id: Long): ScanRecord? =
        dao.getById(id)?.let(ScanHistoryMapper::toDomain)

    override suspend fun save(record: ScanRecord): Long =
        dao.upsert(ScanHistoryMapper.toEntity(record))

    override suspend fun setFavorite(id: Long, favorite: Boolean) = dao.setFavorite(id, favorite)

    override suspend fun delete(id: Long) = dao.deleteById(id)

    override suspend fun deleteAll() = dao.deleteAll()
}
