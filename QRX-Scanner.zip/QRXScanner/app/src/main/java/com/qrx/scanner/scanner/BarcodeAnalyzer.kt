package com.qrx.scanner.scanner

import android.os.SystemClock
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.ZoomSuggestionOptions
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.qrx.scanner.domain.model.DetectedCode
import com.qrx.scanner.domain.model.ScanMode
import kotlin.math.hypot

/**
 * CameraX analyzer that feeds frames to ML Kit. When several codes are visible, the one closest to the
 * centre of the frame wins. Accepted detections are reported through [onDetected] on the analysis thread.
 */
class BarcodeAnalyzer(
    scanMode: ScanMode,
    maxZoomRatio: Float,
    private val onZoomSuggestion: (Float) -> Boolean,
    private val onDetected: (DetectedCode) -> Unit,
) : ImageAnalysis.Analyzer {

    @Volatile
    var isEnabled: Boolean = true

    private val filter = DetectionFilter(now = SystemClock::elapsedRealtime)
    private var lastFrameAt = 0L

    private val scanner: BarcodeScanner = BarcodeScanning.getClient(buildOptions(scanMode, maxZoomRatio))

    private fun buildOptions(scanMode: ScanMode, maxZoomRatio: Float): BarcodeScannerOptions {
        val formats = BarcodeFormatMapper.formatsFor(scanMode).map(BarcodeFormatMapper::toMlKitFormat)
        val builder = BarcodeScannerOptions.Builder()
            .setBarcodeFormats(formats.first(), *formats.drop(1).toIntArray())
        if (maxZoomRatio > 1f) {
            val zoomOptions = ZoomSuggestionOptions.Builder { ratio -> onZoomSuggestion(ratio) }
                .setMaxSupportedZoomRatio(maxZoomRatio)
                .build()
            builder.setZoomSuggestionOptions(zoomOptions)
        }
        return builder.build()
    }

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val now = SystemClock.elapsedRealtime()
        val mediaImage = imageProxy.image
        if (!isEnabled || mediaImage == null || now - lastFrameAt < MIN_FRAME_INTERVAL_MS) {
            imageProxy.close()
            return
        }
        lastFrameAt = now

        val rotation = imageProxy.imageInfo.rotationDegrees
        val upright = rotation == 90 || rotation == 270
        val frameWidth = (if (upright) imageProxy.height else imageProxy.width).toFloat()
        val frameHeight = (if (upright) imageProxy.width else imageProxy.height).toFloat()

        val task: Task<List<Barcode>> = try {
            scanner.process(InputImage.fromMediaImage(mediaImage, rotation))
        } catch (error: IllegalStateException) {
            // The scanner was closed while a frame was in flight.
            imageProxy.close()
            return
        }
        task
            .addOnSuccessListener { barcodes ->
                if (isEnabled) pickBest(barcodes, frameWidth, frameHeight)?.let(::report)
            }
            .addOnCompleteListener { imageProxy.close() }
    }

    private fun report(code: DetectedCode) {
        if (filter.accept(code.rawValue, code.format)) onDetected(code)
    }

    private fun pickBest(barcodes: List<Barcode>, frameWidth: Float, frameHeight: Float): DetectedCode? {
        var best: DetectedCode? = null
        var bestDistance = Float.MAX_VALUE
        for (barcode in barcodes) {
            val format = BarcodeFormatMapper.toCodeFormat(barcode.format) ?: continue
            val value = barcode.rawValue?.takeIf { it.isNotEmpty() } ?: continue
            val box = barcode.boundingBox
            val distance = if (box == null || frameWidth <= 0f || frameHeight <= 0f) {
                0f
            } else {
                hypot(box.exactCenterX() / frameWidth - 0.5f, box.exactCenterY() / frameHeight - 0.5f)
            }
            if (distance < bestDistance) {
                bestDistance = distance
                best = DetectedCode(value, format)
            }
        }
        return best
    }

    fun close() {
        isEnabled = false
        scanner.close()
    }

    private companion object {
        const val MIN_FRAME_INTERVAL_MS = 60L
    }
}
