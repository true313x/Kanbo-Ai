package com.qrx.scanner.domain.model

/** A scan that was (or is about to be) stored in history. `id == 0L` means "not persisted yet". */
data class ScanRecord(
    val id: Long,
    val type: ContentType,
    val rawValue: String,
    val displayValue: String,
    val format: CodeFormat,
    val createdAt: Long,
    val isFavorite: Boolean,
    val metadata: Map<String, String>,
) {
    val isPersisted: Boolean get() = id > 0L
}
