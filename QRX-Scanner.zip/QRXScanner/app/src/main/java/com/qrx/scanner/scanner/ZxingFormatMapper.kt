package com.qrx.scanner.scanner

import com.google.zxing.BarcodeFormat
import com.qrx.scanner.domain.model.CodeFormat

/** Maps between ZXing symbologies and [CodeFormat]. Unsupported ZXing formats map to null. */
object ZxingFormatMapper {

    fun toCodeFormat(format: BarcodeFormat): CodeFormat? = when (format) {
        BarcodeFormat.QR_CODE -> CodeFormat.QR_CODE
        BarcodeFormat.AZTEC -> CodeFormat.AZTEC
        BarcodeFormat.CODABAR -> CodeFormat.CODABAR
        BarcodeFormat.CODE_39 -> CodeFormat.CODE_39
        BarcodeFormat.CODE_93 -> CodeFormat.CODE_93
        BarcodeFormat.CODE_128 -> CodeFormat.CODE_128
        BarcodeFormat.DATA_MATRIX -> CodeFormat.DATA_MATRIX
        BarcodeFormat.EAN_8 -> CodeFormat.EAN_8
        BarcodeFormat.EAN_13 -> CodeFormat.EAN_13
        BarcodeFormat.ITF -> CodeFormat.ITF
        BarcodeFormat.UPC_A -> CodeFormat.UPC_A
        BarcodeFormat.UPC_E -> CodeFormat.UPC_E
        BarcodeFormat.PDF_417 -> CodeFormat.PDF_417
        else -> null
    }

    fun toZxing(format: CodeFormat): BarcodeFormat = when (format) {
        CodeFormat.QR_CODE -> BarcodeFormat.QR_CODE
        CodeFormat.AZTEC -> BarcodeFormat.AZTEC
        CodeFormat.CODABAR -> BarcodeFormat.CODABAR
        CodeFormat.CODE_39 -> BarcodeFormat.CODE_39
        CodeFormat.CODE_93 -> BarcodeFormat.CODE_93
        CodeFormat.CODE_128 -> BarcodeFormat.CODE_128
        CodeFormat.DATA_MATRIX -> BarcodeFormat.DATA_MATRIX
        CodeFormat.EAN_8 -> BarcodeFormat.EAN_8
        CodeFormat.EAN_13 -> BarcodeFormat.EAN_13
        CodeFormat.ITF -> BarcodeFormat.ITF
        CodeFormat.UPC_A -> BarcodeFormat.UPC_A
        CodeFormat.UPC_E -> BarcodeFormat.UPC_E
        CodeFormat.PDF_417 -> BarcodeFormat.PDF_417
    }
}
