package com.qrx.scanner.presentation.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.qrx.scanner.domain.model.AppSettings
import com.qrx.scanner.domain.model.ScanMode
import com.qrx.scanner.domain.model.SearchEngine
import com.qrx.scanner.domain.model.ThemeMode
import com.qrx.scanner.domain.repository.HistoryRepository
import com.qrx.scanner.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val history: HistoryRepository,
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), AppSettings())

    fun setThemeMode(mode: ThemeMode) = launch { settingsRepository.setThemeMode(mode) }
    fun setScanSound(enabled: Boolean) = launch { settingsRepository.setScanSound(enabled) }
    fun setHaptics(enabled: Boolean) = launch { settingsRepository.setHaptics(enabled) }
    fun setAutoOpenLinks(enabled: Boolean) = launch { settingsRepository.setAutoOpenLinks(enabled) }
    fun setAutoSaveHistory(enabled: Boolean) = launch { settingsRepository.setAutoSaveHistory(enabled) }
    fun setScanMode(mode: ScanMode) = launch { settingsRepository.setScanMode(mode) }
    fun setSearchEngine(engine: SearchEngine) = launch { settingsRepository.setSearchEngine(engine) }
    fun clearHistory() = launch { history.deleteAll() }

    private fun launch(block: suspend () -> Unit) {
        viewModelScope.launch { block() }
    }

    private companion object {
        const val STOP_TIMEOUT_MS = 5_000L
    }
}
