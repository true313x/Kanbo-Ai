package com.qrx.scanner.generator

import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

enum class ErrorCorrection(val level: ErrorCorrectionLevel) {
    LOW(ErrorCorrectionLevel.L),
    MEDIUM(ErrorCorrectionLevel.M),
    QUARTILE(ErrorCorrectionLevel.Q),
    HIGH(ErrorCorrectionLevel.H),
}
