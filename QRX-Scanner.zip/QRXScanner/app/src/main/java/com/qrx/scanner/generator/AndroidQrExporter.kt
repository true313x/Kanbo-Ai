package com.qrx.scanner.generator

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.annotation.RequiresApi
import androidx.core.content.FileProvider
import com.qrx.scanner.core.DispatcherProvider
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.io.OutputStream
import javax.inject.Inject

class AndroidQrExporter @Inject constructor(
    @ApplicationContext private val context: Context,
    private val renderer: QrBitmapRenderer,
    private val dispatchers: DispatcherProvider,
) : QrExporter {

    override suspend fun saveToGallery(
        matrix: QrMatrix,
        style: QrStyle,
        logo: Bitmap?,
        fileName: String,
    ): ExportResult = withContext(dispatchers.io) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            writeToMediaStore(matrix, style, logo, fileName)
        } else {
            ExportResult.Failure
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun writeToMediaStore(matrix: QrMatrix, style: QrStyle, logo: Bitmap?, fileName: String): ExportResult {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, MIME_PNG)
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/QRX")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return ExportResult.Failure
        return try {
            val bitmap = renderer.render(matrix, style, logo)
            val written = resolver.openOutputStream(uri)?.use { bitmap.writePng(it) } ?: false
            if (!written) throw IOException("Could not write image")
            resolver.update(uri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
            ExportResult.Success(uri)
        } catch (error: IOException) {
            resolver.delete(uri, null, null)
            ExportResult.Failure
        }
    }

    override suspend fun saveToDocument(
        uri: Uri,
        matrix: QrMatrix,
        style: QrStyle,
        logo: Bitmap?,
    ): ExportResult = withContext(dispatchers.io) {
        try {
            val bitmap = renderer.render(matrix, style, logo)
            val written = context.contentResolver.openOutputStream(uri)?.use { bitmap.writePng(it) } ?: false
            if (written) ExportResult.Success(uri) else ExportResult.Failure
        } catch (error: IOException) {
            ExportResult.Failure
        }
    }

    override suspend fun createShareUri(matrix: QrMatrix, style: QrStyle, logo: Bitmap?): ExportResult =
        withContext(dispatchers.io) {
            try {
                val directory = File(context.cacheDir, SHARE_DIRECTORY).apply { mkdirs() }
                val file = File(directory, SHARE_FILE_NAME)
                val bitmap = renderer.render(matrix, style, logo)
                val written = file.outputStream().use { bitmap.writePng(it) }
                if (!written) return@withContext ExportResult.Failure
                ExportResult.Success(FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file))
            } catch (error: IOException) {
                ExportResult.Failure
            } catch (error: IllegalArgumentException) {
                ExportResult.Failure
            }
        }

    private fun Bitmap.writePng(stream: OutputStream): Boolean = compress(Bitmap.CompressFormat.PNG, 100, stream)

    private companion object {
        const val MIME_PNG = "image/png"
        const val SHARE_DIRECTORY = "shared_qr"
        const val SHARE_FILE_NAME = "qrx-code.png"
    }
}
