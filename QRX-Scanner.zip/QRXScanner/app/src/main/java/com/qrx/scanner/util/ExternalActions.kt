package com.qrx.scanner.util

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.wifi.WifiNetworkSuggestion
import android.os.Build
import android.os.PersistableBundle
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.net.toUri
import com.qrx.scanner.domain.model.ParsedContent
import com.qrx.scanner.domain.model.SearchEngine
import com.qrx.scanner.domain.model.WifiSecurity
import com.qrx.scanner.domain.parser.TextCodec
import java.util.Locale

enum class ActionResult { DONE, NO_APP, UNSUPPORTED }

/**
 * Hands content to other apps. Every function is called only from an explicit tap; nothing here is
 * ever triggered by scanning alone (the single exception, auto-open, is a user setting limited to clean https links).
 */
class ExternalActions(private val context: Context) {

    fun openUrl(url: String): ActionResult {
        val uri = url.trim().toUri()
        if (uri.scheme != "http" && uri.scheme != "https") return ActionResult.UNSUPPORTED
        return start(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE))
    }

    fun dial(number: String): ActionResult =
        start(Intent(Intent.ACTION_DIAL, "tel:${Uri.encode(number)}".toUri()))

    fun composeEmail(email: ParsedContent.Email): ActionResult {
        val intent = Intent(Intent.ACTION_SENDTO, "mailto:".toUri()).apply {
            putExtra(Intent.EXTRA_EMAIL, arrayOf(email.address))
            email.subject?.let { putExtra(Intent.EXTRA_SUBJECT, it) }
            email.body?.let { putExtra(Intent.EXTRA_TEXT, it) }
        }
        return start(intent)
    }

    fun composeSms(number: String, message: String?): ActionResult {
        val intent = Intent(Intent.ACTION_SENDTO, "smsto:${Uri.encode(number)}".toUri()).apply {
            message?.let { putExtra("sms_body", it) }
        }
        return start(intent)
    }

    fun openMap(geo: ParsedContent.Geo): ActionResult {
        val coordinates = String.format(Locale.US, "%.6f,%.6f", geo.latitude, geo.longitude)
        val label = geo.query?.let { "($it)" }.orEmpty()
        val uri = "geo:$coordinates?q=$coordinates${Uri.encode(label, "()")}".toUri()
        return start(Intent(Intent.ACTION_VIEW, uri))
    }

    fun addContact(contact: ParsedContent.Contact): ActionResult {
        val intent = Intent(ContactsContract.Intents.Insert.ACTION).apply {
            type = ContactsContract.RawContacts.CONTENT_TYPE
            contact.name?.let { putExtra(ContactsContract.Intents.Insert.NAME, it) }
            contact.phones.getOrNull(0)?.let { putExtra(ContactsContract.Intents.Insert.PHONE, it) }
            contact.phones.getOrNull(1)?.let { putExtra(ContactsContract.Intents.Insert.SECONDARY_PHONE, it) }
            contact.emails.getOrNull(0)?.let { putExtra(ContactsContract.Intents.Insert.EMAIL, it) }
            contact.emails.getOrNull(1)?.let { putExtra(ContactsContract.Intents.Insert.SECONDARY_EMAIL, it) }
            contact.organization?.let { putExtra(ContactsContract.Intents.Insert.COMPANY, it) }
            contact.jobTitle?.let { putExtra(ContactsContract.Intents.Insert.JOB_TITLE, it) }
            contact.address?.let { putExtra(ContactsContract.Intents.Insert.POSTAL, it) }
            val notes = listOfNotNull(contact.website, contact.note).joinToString("\n")
            if (notes.isNotEmpty()) putExtra(ContactsContract.Intents.Insert.NOTES, notes)
        }
        return start(intent)
    }

    /**
     * Android 11+ shows a system confirmation to add a WPA/WPA2/WPA3 or open network. Other cases
     * return [ActionResult.UNSUPPORTED] so the caller can fall back to copying the password.
     */
    fun connectWifi(wifi: ParsedContent.Wifi): ActionResult {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return ActionResult.UNSUPPORTED
        val builder = WifiNetworkSuggestion.Builder().setSsid(wifi.ssid).setIsHiddenSsid(wifi.hidden)
        val password = wifi.password
        when (wifi.security) {
            WifiSecurity.OPEN -> Unit
            WifiSecurity.WPA -> builder.setWpa2Passphrase(password ?: return ActionResult.UNSUPPORTED)
            WifiSecurity.WPA3 -> builder.setWpa3Passphrase(password ?: return ActionResult.UNSUPPORTED)
            WifiSecurity.WEP, WifiSecurity.EAP -> return ActionResult.UNSUPPORTED
        }
        val intent = Intent(Settings.ACTION_WIFI_ADD_NETWORKS).apply {
            putParcelableArrayListExtra(Settings.EXTRA_WIFI_NETWORK_LIST, arrayListOf(builder.build()))
        }
        return start(intent)
    }

    fun openWifiSettings(): ActionResult = start(Intent(Settings.ACTION_WIFI_SETTINGS))

    fun openAppSettings(): ActionResult = start(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, "package:${context.packageName}".toUri()),
    )

    fun shareText(text: String): ActionResult {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        return start(Intent.createChooser(send, null))
    }

    fun shareImage(uri: Uri): ActionResult {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri(null, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return start(Intent.createChooser(send, null))
    }

    fun searchWeb(query: String, engine: SearchEngine): ActionResult {
        val encoded = TextCodec.percentEncode(query.take(MAX_SEARCH_LENGTH))
        val url = when (engine) {
            SearchEngine.GOOGLE -> "https://www.google.com/search?q=$encoded"
            SearchEngine.BING -> "https://www.bing.com/search?q=$encoded"
            SearchEngine.DUCKDUCKGO -> "https://duckduckgo.com/?q=$encoded"
        }
        return start(Intent(Intent.ACTION_VIEW, url.toUri()).addCategory(Intent.CATEGORY_BROWSABLE))
    }

    /** Returns true when the system will not show its own "copied" confirmation (Android 12 and below). */
    fun copyText(label: String, text: String, sensitive: Boolean = false): Boolean {
        val clip = ClipData.newPlainText(label, text)
        if (sensitive && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            clip.description.extras = PersistableBundle().apply {
                putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true)
            }
        }
        clipboard()?.setPrimaryClip(clip)
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU
    }

    fun copyImage(label: String, uri: Uri): Boolean {
        clipboard()?.setPrimaryClip(ClipData.newUri(context.contentResolver, label, uri))
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU
    }

    private fun clipboard(): ClipboardManager? = context.getSystemService(ClipboardManager::class.java)

    private fun start(intent: Intent): ActionResult = try {
        context.startActivity(intent)
        ActionResult.DONE
    } catch (error: ActivityNotFoundException) {
        ActionResult.NO_APP
    } catch (error: SecurityException) {
        ActionResult.NO_APP
    }

    private companion object {
        const val MAX_SEARCH_LENGTH = 512
    }
}
