package com.qrx.scanner.generator

import android.graphics.Bitmap
import android.net.Uri
import com.qrx.scanner.scanner.BitmapLoader
import javax.inject.Inject

/** Loads the picture the user wants in the middle of a QR code. */
interface LogoLoader {
    suspend fun load(uri: Uri): Bitmap?
}

class BitmapLogoLoader @Inject constructor(
    private val bitmapLoader: BitmapLoader,
) : LogoLoader {
    override suspend fun load(uri: Uri): Bitmap? = bitmapLoader.load(uri, MAX_SIDE_PX)

    private companion object {
        const val MAX_SIDE_PX = 384
    }
}
