package com.qrx.scanner.generator

/**
 * Shared geometry for the optional centre logo, so the preview, the exported image and the
 * readability check all agree on how much of the code is covered.
 */
object QrLogoGeometry {
    /** Logo side as a fraction of the data area side. About 5% of the area; level H tolerates ~30%. */
    const val LOGO_FRACTION = 0.22f

    /** The logo sits on a plate of the background colour that is slightly larger than the logo. */
    const val PLATE_FACTOR = 1.14f

    const val PLATE_FRACTION = LOGO_FRACTION * PLATE_FACTOR
}
