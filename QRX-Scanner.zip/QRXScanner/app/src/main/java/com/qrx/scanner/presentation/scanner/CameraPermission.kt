package com.qrx.scanner.presentation.scanner

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.qrx.scanner.util.findActivity

class CameraPermissionState(
    val granted: Boolean,
    /** The user chose "don't ask again" (or the system blocks the dialog): only app settings can help. */
    val permanentlyDenied: Boolean,
    val request: () -> Unit,
)

/** Requests the camera permission once automatically, then only on demand. Re-checks when the app resumes. */
@Composable
fun rememberCameraPermissionState(): CameraPermissionState {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(hasCameraPermission(context)) }
    var autoRequested by rememberSaveable { mutableStateOf(false) }
    var answers by rememberSaveable { mutableIntStateOf(0) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        granted = isGranted
        answers++
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        granted = hasCameraPermission(context)
    }

    LaunchedEffect(Unit) {
        if (!granted && !autoRequested) {
            autoRequested = true
            launcher.launch(Manifest.permission.CAMERA)
        }
    }

    val activity = context.findActivity()
    val permanentlyDenied = !granted && answers > 0 && activity != null &&
        !ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.CAMERA)

    return CameraPermissionState(
        granted = granted,
        permanentlyDenied = permanentlyDenied,
        request = { launcher.launch(Manifest.permission.CAMERA) },
    )
}

private fun hasCameraPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
