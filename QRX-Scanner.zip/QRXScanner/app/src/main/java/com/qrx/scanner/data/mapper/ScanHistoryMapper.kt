package com.qrx.scanner.data.mapper

import com.qrx.scanner.database.ScanHistory
import com.qrx.scanner.domain.model.CodeFormat
import com.qrx.scanner.domain.model.ContentType
import com.qrx.scanner.domain.model.ScanRecord
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json

object ScanHistoryMapper {

    private val json = Json { ignoreUnknownKeys = true }
    private val metadataSerializer = MapSerializer(String.serializer(), String.serializer())

    fun toDomain(entity: ScanHistory): ScanRecord = ScanRecord(
        id = entity.id,
        type = ContentType.fromName(entity.type),
        rawValue = entity.rawValue,
        displayValue = entity.displayValue,
        format = CodeFormat.fromName(entity.format) ?: CodeFormat.QR_CODE,
        createdAt = entity.createdAt,
        isFavorite = entity.isFavorite,
        metadata = decodeMetadata(entity.metadata),
    )

    fun toEntity(record: ScanRecord): ScanHistory = ScanHistory(
        id = record.id,
        type = record.type.name,
        rawValue = record.rawValue,
        displayValue = record.displayValue,
        format = record.format.name,
        createdAt = record.createdAt,
        isFavorite = record.isFavorite,
        metadata = json.encodeToString(metadataSerializer, record.metadata),
    )

    private fun decodeMetadata(value: String): Map<String, String> =
        try {
            json.decodeFromString(metadataSerializer, value)
        } catch (error: IllegalArgumentException) {
            emptyMap()
        }
}
