package com.qrx.scanner.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ScanHistoryDao {

    @Query("SELECT * FROM scan_history ORDER BY createdAt DESC, id DESC")
    fun observeAll(): Flow<List<ScanHistory>>

    @Query("SELECT * FROM scan_history WHERE isFavorite = 1 ORDER BY createdAt DESC, id DESC")
    fun observeFavorites(): Flow<List<ScanHistory>>

    @Query("SELECT * FROM scan_history WHERE id = :id")
    fun observeById(id: Long): Flow<ScanHistory?>

    @Query("SELECT * FROM scan_history WHERE id = :id")
    suspend fun getById(id: Long): ScanHistory?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ScanHistory): Long

    @Query("UPDATE scan_history SET isFavorite = :favorite WHERE id = :id")
    suspend fun setFavorite(id: Long, favorite: Boolean)

    @Query("DELETE FROM scan_history WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM scan_history")
    suspend fun deleteAll()
}
