package com.qrx.scanner.domain.model

enum class ScanSource { CAMERA, GALLERY }
