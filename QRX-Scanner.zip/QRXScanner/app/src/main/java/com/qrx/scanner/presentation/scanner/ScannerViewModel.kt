package com.qrx.scanner.presentation.scanner

import android.view.View
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.qrx.scanner.core.TimeProvider
import com.qrx.scanner.core.feedback.ScanFeedback
import com.qrx.scanner.domain.model.AppSettings
import com.qrx.scanner.domain.model.DetectedCode
import com.qrx.scanner.domain.model.ScanMode
import com.qrx.scanner.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ScannerViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val feedback: ScanFeedback,
    private val time: TimeProvider,
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), AppSettings())

    private val _isScanning = MutableStateFlow(true)

    /** False between a detection and the moment the user comes back from the result screen. */
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val detectionChannel = Channel<DetectedCode>(Channel.BUFFERED)

    /** One event per accepted detection. */
    val detections: Flow<DetectedCode> = detectionChannel.receiveAsFlow()

    private var lastCode: DetectedCode? = null
    private var resumedAt = 0L

    init {
        feedback.prepare()
    }

    /**
     * Accepts a detection and pauses analysis. The code that was just handled is ignored for a short
     * moment after coming back, so it does not instantly re-trigger while it is still in front of the lens.
     */
    fun onCodeDetected(code: DetectedCode): Boolean {
        if (!_isScanning.value) return false
        if (code == lastCode && time.nowMillis() - resumedAt < RESCAN_COOLDOWN_MS) return false
        lastCode = code
        _isScanning.value = false
        return detectionChannel.trySend(code).isSuccess
    }

    fun resume() {
        resumedAt = time.nowMillis()
        _isScanning.value = true
    }

    fun playFeedback(view: View) {
        val current = settings.value
        feedback.play(sound = current.scanSound, haptics = current.haptics, view = view)
    }

    fun setScanMode(mode: ScanMode) {
        viewModelScope.launch { settingsRepository.setScanMode(mode) }
    }

    private companion object {
        const val STOP_TIMEOUT_MS = 5_000L
        const val RESCAN_COOLDOWN_MS = 2_000L
    }
}
