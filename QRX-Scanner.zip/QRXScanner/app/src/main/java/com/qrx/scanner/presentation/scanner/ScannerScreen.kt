package com.qrx.scanner.presentation.scanner

import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.TorchState
import androidx.camera.view.LifecycleCameraController
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.FlashOff
import androidx.compose.material.icons.rounded.FlashOn
import androidx.compose.material.icons.rounded.FlipCameraAndroid
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.qrx.scanner.R
import com.qrx.scanner.domain.model.DetectedCode
import com.qrx.scanner.domain.model.ScanMode
import com.qrx.scanner.ui.components.CameraButton
import com.qrx.scanner.ui.components.CameraIconButton
import com.qrx.scanner.ui.components.EmptyState
import com.qrx.scanner.ui.components.EmptyStateAction
import com.qrx.scanner.ui.components.LocalContentBottomPadding
import com.qrx.scanner.ui.components.ObserveEvents
import com.qrx.scanner.ui.components.SegmentOption
import com.qrx.scanner.ui.components.SegmentedControl
import com.qrx.scanner.ui.components.labelRes
import com.qrx.scanner.ui.components.screenInsets
import com.qrx.scanner.ui.theme.QrxTheme
import com.qrx.scanner.util.ExternalActions
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.roundToInt

private const val SUCCESS_HOLD_MILLIS = 420L
private val ZoomPresets = listOf(1f, 2f, 4f)

@Composable
fun ScannerScreen(
    onCodeDetected: (DetectedCode) -> Unit,
    onImagePicked: (Uri) -> Unit,
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: ScannerViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val view = LocalView.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val isScanning by viewModel.isScanning.collectAsStateWithLifecycle()
    val permission = rememberCameraPermissionState()
    val controller = rememberCameraController()
    val actions = remember(context) { ExternalActions(context) }
    val currentOnCodeDetected by rememberUpdatedState(onCodeDetected)

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) onImagePicked(uri)
    }
    val launchPicker = {
        pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    var successCode by remember { mutableStateOf<DetectedCode?>(null) }
    LaunchedEffect(Unit) { viewModel.resume() }
    ObserveEvents(viewModel.detections) { code -> successCode = code }
    LaunchedEffect(successCode) {
        val code = successCode ?: return@LaunchedEffect
        viewModel.playFeedback(view)
        delay(SUCCESS_HOLD_MILLIS)
        currentOnCodeDetected(code)
    }

    var useFrontCamera by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(useFrontCamera) {
        val selector = if (useFrontCamera) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        try {
            controller.cameraSelector = selector
        } catch (error: IllegalStateException) {
            // The device cannot provide that camera; stay on the current one.
            useFrontCamera = !useFrontCamera
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(if (permission.granted) Color(0xFF05060F) else MaterialTheme.colorScheme.background),
    ) {
        if (permission.granted) {
            CameraPreview(
                controller = controller,
                scanMode = settings.scanMode,
                scanning = isScanning,
                onCodeDetected = { code -> viewModel.onCodeDetected(code) },
                modifier = Modifier.fillMaxSize(),
            )
            Viewfinder(success = successCode != null)
            CameraControls(
                controller = controller,
                useFrontCamera = useFrontCamera,
                onToggleCamera = { useFrontCamera = !useFrontCamera },
                onPickImage = { launchPicker() },
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        } else {
            PermissionPrompt(
                permanentlyDenied = permission.permanentlyDenied,
                onAllow = permission.request,
                onOpenSettings = { actions.openAppSettings() },
                onPickImage = { launchPicker() },
            )
        }

        TopBar(
            onCamera = permission.granted,
            scanMode = settings.scanMode,
            onScanModeChange = viewModel::setScanMode,
            onOpenHistory = onOpenHistory,
            onOpenSettings = onOpenSettings,
            modifier = Modifier.align(Alignment.TopCenter),
        )
    }
}

@Composable
private fun Viewfinder(success: Boolean) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val frame = (minOf(maxWidth, maxHeight) * 0.66f).coerceIn(220.dp, 340.dp)
        ScanOverlay(
            frameSize = frame,
            success = success,
            successDescription = stringResource(R.string.scan_success_description),
        )
        Surface(
            shape = CircleShape,
            color = Color(0x80000000),
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = frame / 2 + 40.dp),
        ) {
            Text(
                text = stringResource(R.string.scan_hint),
                style = MaterialTheme.typography.labelLarge,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            )
        }
    }
}

@Composable
private fun TopBar(
    onCamera: Boolean,
    scanMode: ScanMode,
    onScanModeChange: (ScanMode) -> Unit,
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val brandColor = if (onCamera) Color.White else MaterialTheme.colorScheme.onBackground
    val beam = QrxTheme.colors.beam
    val brand = stringResource(R.string.brand_wordmark)

    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .fillMaxWidth()
            .then(
                if (onCamera) {
                    Modifier.background(Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent)))
                } else {
                    Modifier
                },
            )
            .screenInsets()
            .padding(horizontal = 16.dp, vertical = 10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = buildAnnotatedString {
                    append(brand.dropLast(1))
                    withStyle(SpanStyle(color = beam)) { append(brand.takeLast(1)) }
                },
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
                color = brandColor,
                modifier = Modifier.weight(1f),
            )
            val historyLabel = stringResource(R.string.nav_history)
            val settingsLabel = stringResource(R.string.nav_settings)
            if (onCamera) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CameraIconButton(
                        icon = Icons.Rounded.History,
                        contentDescription = historyLabel,
                        onClick = onOpenHistory,
                    )
                    CameraIconButton(
                        icon = Icons.Rounded.Settings,
                        contentDescription = settingsLabel,
                        onClick = onOpenSettings,
                    )
                }
            } else {
                IconButton(onClick = onOpenHistory) {
                    Icon(Icons.Rounded.History, contentDescription = historyLabel, tint = brandColor)
                }
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Rounded.Settings, contentDescription = settingsLabel, tint = brandColor)
                }
            }
        }
        if (onCamera) {
            SegmentedControl(
                options = ScanMode.entries.map { SegmentOption(it, stringResource(it.labelRes)) },
                selected = scanMode,
                onSelect = onScanModeChange,
                containerColor = Color(0x80000000),
                unselectedContentColor = Color(0xFFE6E8F5),
                modifier = Modifier.widthIn(max = 340.dp),
            )
        }
    }
}

@Composable
private fun CameraControls(
    controller: LifecycleCameraController,
    useFrontCamera: Boolean,
    onToggleCamera: () -> Unit,
    onPickImage: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val hasFlash = remember(context) {
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)
    }
    val hasFrontCamera = remember(context) {
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT)
    }
    val torchState by controller.torchState.observeAsState(TorchState.OFF)
    val zoomState by controller.zoomState.observeAsState()
    val torchOn = torchState == TorchState.ON
    val zoomRatio = zoomState?.zoomRatio ?: 1f
    val maxZoom = zoomState?.maxZoomRatio ?: 1f
    val zoomSteps = ZoomPresets.filter { it <= maxZoom + 0.01f }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xAA000000)))),
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.Top,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 40.dp, bottom = LocalContentBottomPadding.current + 12.dp),
        ) {
            LabeledControl(stringResource(R.string.scan_control_gallery)) {
                CameraIconButton(
                    icon = Icons.Rounded.PhotoLibrary,
                    contentDescription = stringResource(R.string.scan_from_image),
                    onClick = onPickImage,
                )
            }
            if (hasFlash) {
                LabeledControl(stringResource(R.string.scan_control_flash)) {
                    CameraIconButton(
                        icon = if (torchOn) Icons.Rounded.FlashOn else Icons.Rounded.FlashOff,
                        contentDescription = stringResource(
                            if (torchOn) R.string.scan_flash_turn_off else R.string.scan_flash_turn_on,
                        ),
                        onClick = { controller.enableTorch(!torchOn) },
                        active = torchOn,
                        enabled = !useFrontCamera,
                    )
                }
            }
            LabeledControl(stringResource(R.string.scan_control_zoom)) {
                val zoomText = stringResource(R.string.zoom_ratio_format, formatZoom(zoomRatio))
                CameraButton(
                    contentDescription = stringResource(R.string.scan_zoom_description, zoomText),
                    onClick = {
                        val next = zoomSteps.firstOrNull { it > zoomRatio + 0.05f } ?: zoomSteps.firstOrNull() ?: 1f
                        controller.setZoomRatio(next)
                    },
                    enabled = zoomSteps.size > 1,
                ) {
                    Text(text = zoomText, style = MaterialTheme.typography.labelLarge)
                }
            }
            if (hasFrontCamera) {
                LabeledControl(stringResource(R.string.scan_control_flip)) {
                    CameraIconButton(
                        icon = Icons.Rounded.FlipCameraAndroid,
                        contentDescription = stringResource(R.string.scan_switch_camera),
                        onClick = onToggleCamera,
                    )
                }
            }
        }
    }
}

@Composable
private fun LabeledControl(label: String, control: @Composable () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        control()
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = Color.White)
    }
}

@Composable
private fun PermissionPrompt(
    permanentlyDenied: Boolean,
    onAllow: () -> Unit,
    onOpenSettings: () -> Unit,
    onPickImage: () -> Unit,
) {
    EmptyState(
        icon = Icons.Rounded.CameraAlt,
        title = stringResource(R.string.camera_permission_title),
        message = stringResource(R.string.camera_permission_message),
        primaryAction = EmptyStateAction(
            label = stringResource(
                if (permanentlyDenied) R.string.camera_permission_open_settings else R.string.camera_permission_allow,
            ),
            onClick = if (permanentlyDenied) onOpenSettings else onAllow,
        ),
        secondaryAction = EmptyStateAction(stringResource(R.string.scan_from_image), onPickImage),
        modifier = Modifier
            .fillMaxSize()
            .screenInsets()
            .padding(top = 64.dp, bottom = LocalContentBottomPadding.current),
    )
}

private fun formatZoom(ratio: Float): String {
    val rounded = (ratio * 10f).roundToInt() / 10f
    return if (rounded % 1f == 0f) rounded.roundToInt().toString() else String.format(Locale.getDefault(), "%.1f", rounded)
}
