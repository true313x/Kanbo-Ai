package com.qrx.scanner.scanner

import com.qrx.scanner.domain.model.CodeFormat

/**
 * Debounces camera detections.
 *
 *  - The same code is not reported again within [duplicateWindowMs] of being accepted.
 *  - 2D codes carry error correction and are accepted on the first sighting; 1D codes must be seen twice
 *    in a row (within [confirmWindowMs]) because a single noisy frame can produce a wrong digit.
 *
 * Not thread-safe by design: it is only used from one thread (the one that delivers ML Kit results).
 */
class DetectionFilter(
    private val duplicateWindowMs: Long = DEFAULT_DUPLICATE_WINDOW_MS,
    private val confirmWindowMs: Long = DEFAULT_CONFIRM_WINDOW_MS,
    private val now: () -> Long,
) {
    private var lastAcceptedKey: String? = null
    private var lastAcceptedAt = 0L
    private var pendingKey: String? = null
    private var pendingCount = 0
    private var pendingSeenAt = 0L

    fun accept(rawValue: String, format: CodeFormat): Boolean {
        val time = now()
        val key = "${format.name}:$rawValue"

        if (key == lastAcceptedKey && time - lastAcceptedAt < duplicateWindowMs) {
            lastAcceptedAt = time
            return false
        }

        if (key == pendingKey && time - pendingSeenAt <= confirmWindowMs) {
            pendingCount++
        } else {
            pendingKey = key
            pendingCount = 1
        }
        pendingSeenAt = time

        val required = if (format.isTwoDimensional) 1 else 2
        if (pendingCount < required) return false

        lastAcceptedKey = key
        lastAcceptedAt = time
        pendingKey = null
        pendingCount = 0
        return true
    }

    fun reset() {
        lastAcceptedKey = null
        lastAcceptedAt = 0L
        pendingKey = null
        pendingCount = 0
        pendingSeenAt = 0L
    }

    companion object {
        const val DEFAULT_DUPLICATE_WINDOW_MS = 2_500L
        const val DEFAULT_CONFIRM_WINDOW_MS = 1_000L
    }
}
