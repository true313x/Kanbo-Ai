package com.qrx.scanner.presentation.scanner

import android.util.Size
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.qrx.scanner.domain.model.DetectedCode
import com.qrx.scanner.domain.model.ScanMode
import com.qrx.scanner.scanner.BarcodeAnalyzer
import com.qrx.scanner.ui.theme.QrxTheme
import kotlinx.coroutines.delay
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

private const val ANALYSIS_WIDTH = 1280
private const val ANALYSIS_HEIGHT = 720
private const val FOCUS_RING_MILLIS = 900L
private const val FOCUS_AUTO_CANCEL_SECONDS = 3L

@Composable
fun rememberCameraController(): LifecycleCameraController {
    val context = LocalContext.current
    return remember(context) {
        LifecycleCameraController(context).apply {
            setEnabledUseCases(CameraController.IMAGE_ANALYSIS)
            imageAnalysisBackpressureStrategy = ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST
            imageAnalysisResolutionSelector = ResolutionSelector.Builder()
                .setResolutionStrategy(
                    ResolutionStrategy(
                        Size(ANALYSIS_WIDTH, ANALYSIS_HEIGHT),
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER,
                    ),
                )
                .build()
            // Gestures are handled below so that focus feedback and pinch zoom match the app's own UI.
            isPinchToZoomEnabled = false
            isTapToFocusEnabled = false
        }
    }
}

/**
 * Live camera preview that feeds ML Kit. Binds to the current lifecycle owner, so the camera is released
 * as soon as another destination covers the scanner.
 */
@Composable
fun CameraPreview(
    controller: LifecycleCameraController,
    scanMode: ScanMode,
    scanning: Boolean,
    onCodeDetected: (DetectedCode) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val currentOnCodeDetected by rememberUpdatedState(onCodeDetected)
    val mainExecutor = remember(context) { ContextCompat.getMainExecutor(context) }

    val previewView = remember(context) {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    DisposableEffect(controller, previewView, lifecycleOwner) {
        previewView.controller = controller
        controller.bindToLifecycle(lifecycleOwner)
        onDispose {
            controller.unbind()
            previewView.controller = null
        }
    }

    val zoomState by controller.zoomState.observeAsState()
    val maxZoomRatio = zoomState?.maxZoomRatio ?: 1f

    val analysisExecutor = remember { Executors.newSingleThreadExecutor() }
    DisposableEffect(analysisExecutor) {
        onDispose { analysisExecutor.shutdown() }
    }

    val analyzer = remember(scanMode, maxZoomRatio) {
        BarcodeAnalyzer(
            scanMode = scanMode,
            maxZoomRatio = maxZoomRatio,
            onZoomSuggestion = { ratio ->
                mainExecutor.execute { controller.setZoomRatio(ratio) }
                true
            },
            onDetected = { code -> mainExecutor.execute { currentOnCodeDetected(code) } },
        )
    }
    DisposableEffect(analyzer) {
        controller.setImageAnalysisAnalyzer(analysisExecutor, analyzer)
        onDispose {
            controller.clearImageAnalysisAnalyzer()
            analyzer.close()
        }
    }
    SideEffect { analyzer.isEnabled = scanning }

    var ringPosition by remember { mutableStateOf(Offset.Zero) }
    var ringVisible by remember { mutableStateOf(false) }
    var ringTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(ringTick) {
        if (ringTick > 0) {
            ringVisible = true
            delay(FOCUS_RING_MILLIS)
            ringVisible = false
        }
    }

    Box(modifier = modifier) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())

        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(controller, previewView) {
                    detectTapGestures { position ->
                        val point = previewView.meteringPointFactory.createPoint(position.x, position.y)
                        val action = FocusMeteringAction.Builder(
                            point,
                            FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE,
                        )
                            .setAutoCancelDuration(FOCUS_AUTO_CANCEL_SECONDS, TimeUnit.SECONDS)
                            .build()
                        controller.cameraControl?.startFocusAndMetering(action)
                        ringPosition = position
                        ringTick++
                    }
                }
                .pointerInput(controller) {
                    detectTransformGestures { _, _, zoom, _ ->
                        val state = controller.zoomState.value
                        if (state != null && zoom != 1f) {
                            controller.setZoomRatio(
                                (state.zoomRatio * zoom).coerceIn(state.minZoomRatio, state.maxZoomRatio),
                            )
                        }
                    }
                },
        )

        AnimatedVisibility(
            visible = ringVisible,
            enter = scaleIn(initialScale = 1.6f) + fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.offset {
                val half = 36.dp.toPx()
                IntOffset((ringPosition.x - half).roundToInt(), (ringPosition.y - half).roundToInt())
            },
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .border(2.dp, QrxTheme.colors.beam, CircleShape),
            )
        }
    }
}
