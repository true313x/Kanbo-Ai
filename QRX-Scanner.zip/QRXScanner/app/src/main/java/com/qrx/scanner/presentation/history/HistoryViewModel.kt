package com.qrx.scanner.presentation.history

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.qrx.scanner.domain.model.HistoryFilter
import com.qrx.scanner.domain.model.ScanRecord
import com.qrx.scanner.domain.repository.HistoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HistoryUiState(
    val isLoading: Boolean = true,
    val records: List<ScanRecord> = emptyList(),
    val filter: HistoryFilter = HistoryFilter.ALL,
    val query: String = "",
)

sealed interface HistoryEvent {
    /** A record was deleted; the screen offers to undo it. */
    data object Deleted : HistoryEvent
}

@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val history: HistoryRepository,
    private val savedStateHandle: SavedStateHandle,
) : ViewModel() {

    private val filter = savedStateHandle.getStateFlow(KEY_FILTER, HistoryFilter.ALL.name)
    private val query = savedStateHandle.getStateFlow(KEY_QUERY, "")

    val state: StateFlow<HistoryUiState> = combine(history.observeAll(), filter, query) { records, filterName, text ->
        HistoryUiState(
            isLoading = false,
            records = records,
            filter = HistoryFilter.entries.firstOrNull { it.name == filterName } ?: HistoryFilter.ALL,
            query = text,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), HistoryUiState())

    private val eventChannel = Channel<HistoryEvent>(Channel.BUFFERED)
    val events: Flow<HistoryEvent> = eventChannel.receiveAsFlow()

    private var lastDeleted: ScanRecord? = null

    fun setFilter(value: HistoryFilter) {
        savedStateHandle[KEY_FILTER] = value.name
    }

    fun setQuery(value: String) {
        savedStateHandle[KEY_QUERY] = value
    }

    fun toggleFavorite(record: ScanRecord) {
        viewModelScope.launch { history.setFavorite(record.id, !record.isFavorite) }
    }

    fun delete(record: ScanRecord) {
        viewModelScope.launch {
            history.delete(record.id)
            lastDeleted = record
            eventChannel.send(HistoryEvent.Deleted)
        }
    }

    fun undoDelete() {
        val record = lastDeleted ?: return
        lastDeleted = null
        viewModelScope.launch { history.save(record) }
    }

    fun deleteAll() {
        lastDeleted = null
        viewModelScope.launch { history.deleteAll() }
    }

    private companion object {
        const val KEY_FILTER = "history_filter"
        const val KEY_QUERY = "history_query"
        const val STOP_TIMEOUT_MS = 5_000L
    }
}
