package com.qrx.scanner.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore

/** Single DataStore instance for the whole process. Must stay a top-level delegate. */
val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "qrx_settings")
