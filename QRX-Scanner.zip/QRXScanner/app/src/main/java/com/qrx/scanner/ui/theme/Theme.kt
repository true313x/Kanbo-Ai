package com.qrx.scanner.ui.theme

import android.graphics.drawable.ColorDrawable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.qrx.scanner.domain.model.ThemeMode
import com.qrx.scanner.util.findActivity

private val LightScheme = lightColorScheme(
    primary = Violet600,
    onPrimary = LightSurface,
    primaryContainer = LightPrimaryContainer,
    onPrimaryContainer = LightOnPrimaryContainer,
    inversePrimary = Violet300,
    secondary = BeamDeep,
    onSecondary = LightSurface,
    secondaryContainer = LightSurfaceHigh,
    onSecondaryContainer = Ink,
    tertiary = BeamDeep,
    onTertiary = LightSurface,
    tertiaryContainer = LightSurfaceHigh,
    onTertiaryContainer = Ink,
    background = LightBackground,
    onBackground = Ink,
    surface = LightSurface,
    onSurface = Ink,
    surfaceVariant = LightSurfaceHigh,
    onSurfaceVariant = LightOnSurfaceVariant,
    surfaceTint = Violet600,
    inverseSurface = Ink,
    inverseOnSurface = LightBackground,
    error = LightError,
    onError = LightSurface,
    errorContainer = LightErrorContainer,
    onErrorContainer = LightError,
    outline = LightOutline,
    outlineVariant = LightOutlineVariant,
    scrim = Midnight,
    surfaceBright = LightSurface,
    surfaceDim = LightSurfaceHighest,
    surfaceContainerLowest = LightSurface,
    surfaceContainerLow = LightSurfaceLow,
    surfaceContainer = LightSurface,
    surfaceContainerHigh = LightSurfaceHigh,
    surfaceContainerHighest = LightSurfaceHighest,
)

private val DarkScheme = darkColorScheme(
    primary = Violet300,
    onPrimary = DarkOnPrimary,
    primaryContainer = DarkPrimaryContainer,
    onPrimaryContainer = DarkOnPrimaryContainer,
    inversePrimary = Violet600,
    secondary = Beam,
    onSecondary = Midnight,
    secondaryContainer = DarkSurfaceHigh,
    onSecondaryContainer = DarkOnSurface,
    tertiary = Beam,
    onTertiary = Midnight,
    tertiaryContainer = DarkSurfaceHigh,
    onTertiaryContainer = DarkOnSurface,
    background = Midnight,
    onBackground = DarkOnSurface,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceHigh,
    onSurfaceVariant = DarkOnSurfaceVariant,
    surfaceTint = Violet300,
    inverseSurface = DarkOnSurface,
    inverseOnSurface = Midnight,
    error = DarkError,
    onError = Midnight,
    errorContainer = DarkErrorContainer,
    onErrorContainer = DarkError,
    outline = DarkOutline,
    outlineVariant = DarkOutlineVariant,
    scrim = Midnight,
    surfaceBright = DarkSurfaceHighest,
    surfaceDim = Midnight,
    surfaceContainerLowest = Midnight,
    surfaceContainerLow = DarkSurfaceLow,
    surfaceContainer = DarkSurface,
    surfaceContainerHigh = DarkSurfaceHigh,
    surfaceContainerHighest = DarkSurfaceHighest,
)

object QrxTheme {
    val colors: QrxColors
        @Composable
        @ReadOnlyComposable
        get() = LocalQrxColors.current
}

@Composable
fun QrxTheme(themeMode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val scheme = if (dark) DarkScheme else LightScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = view.context.findActivity()?.window ?: return@SideEffect
            window.setBackgroundDrawable(ColorDrawable(scheme.background.toArgb()))
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }

    CompositionLocalProvider(LocalQrxColors provides if (dark) DarkQrxColors else LightQrxColors) {
        MaterialTheme(
            colorScheme = scheme,
            typography = QrxTypography,
            shapes = QrxShapes,
            content = content,
        )
    }
}
