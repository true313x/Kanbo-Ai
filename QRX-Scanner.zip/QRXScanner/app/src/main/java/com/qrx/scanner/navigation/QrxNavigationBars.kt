package com.qrx.scanner.navigation

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.qrx.scanner.ui.components.pressScale
import com.qrx.scanner.ui.components.rememberPressScale

val BottomBarHeight: Dp = 64.dp
val BottomBarMargin: Dp = 12.dp

/** Floating pill. The Scan tab is deliberately the loudest element: it is the reason the app exists. */
@Composable
fun QrxBottomBar(
    selected: TopLevelDestination?,
    onSelect: (TopLevelDestination) -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        shape = RoundedCornerShape(32.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 6.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = modifier.fillMaxWidth(),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier
                .selectableGroup()
                .height(BottomBarHeight)
                .padding(horizontal = 8.dp),
        ) {
            for (destination in TopLevelDestination.entries) {
                NavItem(
                    destination = destination,
                    selected = destination == selected,
                    onClick = { onSelect(destination) },
                    modifier = Modifier
                        .weight(if (destination == TopLevelDestination.SCAN) 1.5f else 1f)
                        .fillMaxHeight()
                        .padding(vertical = 6.dp),
                )
            }
        }
    }
}

/** Vertical variant for tablets, foldables and landscape. */
@Composable
fun QrxNavigationRail(
    selected: TopLevelDestination?,
    onSelect: (TopLevelDestination) -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = modifier.fillMaxHeight(),
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .selectableGroup()
                .padding(horizontal = 10.dp, vertical = 16.dp),
        ) {
            for (destination in TopLevelDestination.entries) {
                NavItem(
                    destination = destination,
                    selected = destination == selected,
                    onClick = { onSelect(destination) },
                    modifier = Modifier
                        .width(84.dp)
                        .heightIn(min = if (destination == TopLevelDestination.SCAN) 76.dp else 64.dp),
                )
            }
        }
    }
}

@Composable
private fun NavItem(
    destination: TopLevelDestination,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressAnimation = rememberPressScale(interaction)
    val isScan = destination == TopLevelDestination.SCAN
    val scheme = MaterialTheme.colorScheme
    val label = stringResource(destination.labelRes)

    val background by animateColorAsState(
        targetValue = when {
            isScan && selected -> scheme.primary
            isScan -> scheme.primaryContainer
            selected -> scheme.primaryContainer
            else -> scheme.surface
        },
        label = "navItemBackground",
    )
    val content by animateColorAsState(
        targetValue = when {
            isScan && selected -> scheme.onPrimary
            isScan -> scheme.onPrimaryContainer
            selected -> scheme.onPrimaryContainer
            else -> scheme.onSurfaceVariant
        },
        label = "navItemContent",
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .pressScale(pressAnimation)
            .clip(RoundedCornerShape(24.dp))
            .background(background)
            .selectable(
                selected = selected,
                interactionSource = interaction,
                indication = null,
                role = Role.Tab,
                onClick = onClick,
            ),
    ) {
        if (isScan) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = destination.icon, contentDescription = null, tint = content, modifier = Modifier.size(26.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelLarge,
                    color = content,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Icon(imageVector = destination.icon, contentDescription = null, tint = content, modifier = Modifier.size(22.dp))
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = content,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}
