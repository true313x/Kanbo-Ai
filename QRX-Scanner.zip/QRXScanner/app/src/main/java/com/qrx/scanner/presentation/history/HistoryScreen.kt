package com.qrx.scanner.presentation.history

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.qrx.scanner.R
import com.qrx.scanner.domain.model.ContentType
import com.qrx.scanner.domain.model.HistoryFilter
import com.qrx.scanner.domain.usecase.HistoryFilterer
import com.qrx.scanner.ui.components.ConfirmDialog
import com.qrx.scanner.ui.components.ContentMaxWidth
import com.qrx.scanner.ui.components.EmptyState
import com.qrx.scanner.ui.components.LocalContentBottomPadding
import com.qrx.scanner.ui.components.ObserveEvents
import com.qrx.scanner.ui.components.ScreenHeader
import com.qrx.scanner.ui.components.labelRes
import com.qrx.scanner.ui.components.screenInsets
import kotlinx.coroutines.launch

@Composable
fun HistoryScreen(
    onOpenRecord: (Long) -> Unit,
    onOpenFavorites: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: HistoryViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var confirmDeleteAll by rememberSaveable { mutableStateOf(false) }

    val deletedMessage = stringResource(R.string.history_deleted)
    val undoLabel = stringResource(R.string.action_undo)
    ObserveEvents(viewModel.events) { event ->
        when (event) {
            HistoryEvent.Deleted -> scope.launch {
                snackbar.currentSnackbarData?.dismiss()
                val result = snackbar.showSnackbar(
                    message = deletedMessage,
                    actionLabel = undoLabel,
                    duration = SnackbarDuration.Short,
                )
                if (result == SnackbarResult.ActionPerformed) viewModel.undoDelete()
            }
        }
    }

    val typeLabels = ContentType.entries.associateWith { stringResource(it.labelRes) }
    val visible = remember(state.records, state.filter, state.query, typeLabels) {
        HistoryFilterer.apply(state.records, state.filter, state.query) { typeLabels.getValue(it) }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().screenInsets()) {
            ScreenHeader(
                title = stringResource(R.string.history_title),
                actions = {
                    IconButton(onClick = onOpenFavorites) {
                        Icon(Icons.Rounded.Star, contentDescription = stringResource(R.string.favorites_title))
                    }
                    IconButton(onClick = { confirmDeleteAll = true }, enabled = state.records.isNotEmpty()) {
                        Icon(Icons.Rounded.DeleteSweep, contentDescription = stringResource(R.string.history_delete_all))
                    }
                },
            )
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                Column(modifier = Modifier.widthIn(max = ContentMaxWidth).fillMaxSize()) {
                    if (state.records.isNotEmpty() || state.query.isNotEmpty()) {
                        SearchField(
                            query = state.query,
                            onQueryChange = viewModel::setQuery,
                            modifier = Modifier.padding(horizontal = 20.dp),
                        )
                        FilterRow(
                            selected = state.filter,
                            onSelect = viewModel::setFilter,
                            modifier = Modifier.padding(top = 12.dp, bottom = 8.dp),
                        )
                    }
                    when {
                        state.isLoading -> Box(Modifier.weight(1f))
                        state.records.isEmpty() -> EmptyState(
                            icon = Icons.Rounded.History,
                            title = stringResource(R.string.history_empty_title),
                            message = stringResource(R.string.history_empty_message),
                            modifier = Modifier.weight(1f).padding(bottom = LocalContentBottomPadding.current),
                        )
                        visible.isEmpty() -> EmptyState(
                            icon = Icons.Rounded.SearchOff,
                            title = stringResource(R.string.history_no_matches_title),
                            message = stringResource(R.string.history_no_matches_message),
                            modifier = Modifier.weight(1f).padding(bottom = LocalContentBottomPadding.current),
                        )
                        else -> LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(
                                start = 20.dp,
                                end = 20.dp,
                                top = 4.dp,
                                bottom = LocalContentBottomPadding.current + 16.dp,
                            ),
                            modifier = Modifier.weight(1f),
                        ) {
                            items(visible, key = { it.id }) { record ->
                                SwipeableHistoryItem(
                                    record = record,
                                    onClick = { onOpenRecord(record.id) },
                                    onToggleFavorite = { viewModel.toggleFavorite(record) },
                                    onDelete = { viewModel.delete(record) },
                                    modifier = Modifier.animateItem(),
                                )
                            }
                        }
                    }
                }
            }
        }
        SnackbarHost(
            hostState = snackbar,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = LocalContentBottomPadding.current)
                .padding(horizontal = 16.dp),
        )
    }

    if (confirmDeleteAll) {
        ConfirmDialog(
            title = stringResource(R.string.history_delete_all_title),
            message = stringResource(R.string.history_delete_all_message),
            confirmLabel = stringResource(R.string.history_delete_all_confirm),
            dismissLabel = stringResource(R.string.action_cancel),
            onConfirm = {
                confirmDeleteAll = false
                viewModel.deleteAll()
            },
            onDismiss = { confirmDeleteAll = false },
            destructive = true,
        )
    }
}

@Composable
private fun SearchField(query: String, onQueryChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        singleLine = true,
        shape = MaterialTheme.shapes.medium,
        placeholder = { Text(stringResource(R.string.history_search_hint)) },
        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQueryChange("") }) {
                    Icon(Icons.Rounded.Close, contentDescription = stringResource(R.string.action_clear))
                }
            }
        },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        modifier = modifier.fillMaxWidth(),
    )
}

@Composable
private fun FilterRow(selected: HistoryFilter, onSelect: (HistoryFilter) -> Unit, modifier: Modifier = Modifier) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(horizontal = 20.dp),
        modifier = modifier.fillMaxWidth(),
    ) {
        items(HistoryFilter.entries, key = { it.name }) { filter ->
            FilterChip(
                selected = filter == selected,
                onClick = { onSelect(filter) },
                label = { Text(stringResource(filter.labelRes)) },
            )
        }
    }
}
