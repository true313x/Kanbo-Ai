package com.qrx.scanner.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Semantic colours that Material 3's scheme has no slot for. */
@Immutable
data class QrxColors(
    val success: Color,
    val onSuccess: Color,
    val successContainer: Color,
    val warning: Color,
    val onWarning: Color,
    val warningContainer: Color,
    val danger: Color,
    val dangerContainer: Color,
    /** The cyan scan beam. */
    val beam: Color,
    /** Ink used on top of the camera preview. */
    val onCamera: Color,
    val cameraScrim: Color,
)

internal val LightQrxColors = QrxColors(
    success = Color(0xFF12805A),
    onSuccess = Color(0xFFFFFFFF),
    successContainer = Color(0xFFDDF5EA),
    warning = Color(0xFF9A5B00),
    onWarning = Color(0xFFFFFFFF),
    warningContainer = Color(0xFFFFEFCF),
    danger = LightError,
    dangerContainer = LightErrorContainer,
    beam = BeamDeep,
    onCamera = Color(0xFFFFFFFF),
    cameraScrim = Color(0x99080A18),
)

internal val DarkQrxColors = QrxColors(
    success = Color(0xFF3DDC97),
    onSuccess = Color(0xFF05241A),
    successContainer = Color(0xFF123A2C),
    warning = Color(0xFFFFC247),
    onWarning = Color(0xFF2E1F00),
    warningContainer = Color(0xFF3D2E0B),
    danger = DarkError,
    dangerContainer = DarkErrorContainer,
    beam = Beam,
    onCamera = Color(0xFFFFFFFF),
    cameraScrim = Color(0xB3050714),
)

val LocalQrxColors = staticCompositionLocalOf { LightQrxColors }
