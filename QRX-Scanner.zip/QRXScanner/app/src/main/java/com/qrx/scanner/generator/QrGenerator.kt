package com.qrx.scanner.generator

enum class GenerationFailure { EMPTY, TOO_MUCH_DATA }

sealed interface QrGenerationResult {
    data class Success(val matrix: QrMatrix) : QrGenerationResult
    data class Failure(val reason: GenerationFailure) : QrGenerationResult
}

/** Turns a payload into a QR module matrix. */
interface QrGenerator {
    fun generate(payload: String, errorCorrection: ErrorCorrection): QrGenerationResult
}
