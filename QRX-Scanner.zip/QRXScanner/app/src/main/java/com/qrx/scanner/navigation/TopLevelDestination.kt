package com.qrx.scanner.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddCircle
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination
import androidx.navigation.NavDestination.Companion.hasRoute
import com.qrx.scanner.R

/** The four tabs of the bottom bar (or navigation rail on wide screens). */
enum class TopLevelDestination(
    val route: Any,
    @StringRes val labelRes: Int,
    val icon: ImageVector,
    val matches: (NavDestination) -> Boolean,
) {
    SCAN(ScannerRoute, R.string.nav_scan, Icons.Rounded.QrCodeScanner, { it.hasRoute<ScannerRoute>() }),
    HISTORY(HistoryRoute, R.string.nav_history, Icons.Rounded.History, { it.hasRoute<HistoryRoute>() }),
    CREATE(CreateRoute, R.string.nav_create, Icons.Rounded.AddCircle, { it.hasRoute<CreateRoute>() }),
    SETTINGS(SettingsRoute, R.string.nav_settings, Icons.Rounded.Settings, { it.hasRoute<SettingsRoute>() }),
    ;

    companion object {
        fun from(destination: NavDestination?): TopLevelDestination? =
            destination?.let { current -> entries.firstOrNull { it.matches(current) } }
    }
}
