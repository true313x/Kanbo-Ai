package com.qrx.scanner.database

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "scan_history",
    indices = [Index(value = ["createdAt"]), Index(value = ["isFavorite"])],
)
data class ScanHistory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val type: String,
    val rawValue: String,
    val displayValue: String,
    val format: String,
    val createdAt: Long,
    val isFavorite: Boolean,
    /** JSON object (string to string) with parser-derived details. */
    val metadata: String,
)
