package com.qrx.scanner.generator

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import javax.inject.Inject
import kotlin.math.max
import kotlin.math.min

/** Draws a [QrMatrix] into a crisp bitmap, optionally with a logo plate in the middle. */
class QrBitmapRenderer @Inject constructor() {

    fun render(matrix: QrMatrix, style: QrStyle, logo: Bitmap?): Bitmap {
        val modules = matrix.size
        val scale = max(1, (style.sizePx + modules - 1) / modules)
        val side = scale * modules

        val pixels = IntArray(side * side) { style.background }
        for (y in 0 until modules) {
            for (x in 0 until modules) {
                if (!matrix[x, y]) continue
                for (dy in 0 until scale) {
                    val row = (y * scale + dy) * side + x * scale
                    for (dx in 0 until scale) pixels[row + dx] = style.foreground
                }
            }
        }
        val bitmap = Bitmap.createBitmap(pixels, side, side, Bitmap.Config.ARGB_8888)
        if (logo != null) drawLogo(bitmap, matrix, scale, style, logo)
        return bitmap
    }

    private fun drawLogo(bitmap: Bitmap, matrix: QrMatrix, scale: Int, style: QrStyle, logo: Bitmap) {
        val canvas = Canvas(bitmap)
        val center = bitmap.width / 2f
        val dataSide = matrix.dataSize * scale.toFloat()
        val logoSide = dataSide * QrLogoGeometry.LOGO_FRACTION
        val plateHalf = dataSide * QrLogoGeometry.PLATE_FRACTION / 2f

        val platePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = style.background }
        val radius = plateHalf * 0.22f
        canvas.drawRoundRect(
            RectF(center - plateHalf, center - plateHalf, center + plateHalf, center + plateHalf),
            radius,
            radius,
            platePaint,
        )

        val fit = min(logoSide / logo.width, logoSide / logo.height)
        val halfWidth = logo.width * fit / 2f
        val halfHeight = logo.height * fit / 2f
        val destination = RectF(center - halfWidth, center - halfHeight, center + halfWidth, center + halfHeight)
        canvas.drawBitmap(logo, null, destination, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
    }
}
