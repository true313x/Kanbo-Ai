package com.qrx.scanner.generator

import com.qrx.scanner.domain.model.WifiSecurity

/** Raw, user-typed form values for each kind of QR code that can be created. */
sealed interface CreateInput {
    data class Website(val url: String) : CreateInput
    data class Text(val text: String) : CreateInput
    data class Wifi(
        val ssid: String,
        val password: String,
        val security: WifiSecurity,
        val hidden: Boolean,
    ) : CreateInput

    data class Contact(
        val name: String,
        val phone: String,
        val email: String,
        val organization: String,
        val jobTitle: String,
        val address: String,
        val website: String,
        val note: String,
    ) : CreateInput

    data class Phone(val number: String) : CreateInput
    data class Email(val address: String, val subject: String, val body: String) : CreateInput
    data class Sms(val number: String, val message: String) : CreateInput
    data class Location(val latitude: String, val longitude: String, val label: String) : CreateInput
}

enum class InputError {
    EMPTY,
    INVALID_URL,
    INVALID_PHONE,
    INVALID_EMAIL,
    INVALID_COORDINATES,
    MISSING_SSID,
    MISSING_PASSWORD,
    MISSING_NAME,
    TOO_LONG,
}

sealed interface PayloadResult {
    data class Success(val payload: String) : PayloadResult
    data class Error(val error: InputError) : PayloadResult
}
