package com.qrx.scanner.domain.model

/** The semantic type of a scanned value, detected automatically by the parser. */
enum class ContentType {
    URL,
    TEXT,
    WIFI,
    CONTACT,
    PHONE,
    EMAIL,
    SMS,
    GEO,
    BARCODE;

    companion object {
        fun fromName(name: String): ContentType = entries.firstOrNull { it.name == name } ?: TEXT
    }
}
