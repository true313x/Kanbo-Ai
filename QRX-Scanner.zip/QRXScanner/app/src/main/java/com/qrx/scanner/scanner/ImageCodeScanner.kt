package com.qrx.scanner.scanner

import android.net.Uri
import com.qrx.scanner.domain.model.DetectedCode

sealed interface ImageScanResult {
    data class Found(val codes: List<DetectedCode>) : ImageScanResult
    data object NoCode : ImageScanResult
    data object Unreadable : ImageScanResult
}

/** Finds every supported code inside a still image. */
interface ImageCodeScanner {
    suspend fun scan(uri: Uri): ImageScanResult
}
