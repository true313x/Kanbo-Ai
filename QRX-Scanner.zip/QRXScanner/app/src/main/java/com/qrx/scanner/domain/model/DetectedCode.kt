package com.qrx.scanner.domain.model

/** A raw code reported by a scanner engine before it is interpreted. */
data class DetectedCode(
    val rawValue: String,
    val format: CodeFormat,
)
