package com.qrx.scanner.domain.model

enum class WifiSecurity { OPEN, WEP, WPA, WPA3, EAP }
