package com.qrx.scanner.generator

/** Immutable square bit matrix. The quiet zone (white border) is part of the matrix. */
class QrMatrix(
    val size: Int,
    val quietZone: Int,
    private val modules: BooleanArray,
) {
    init {
        require(size > 0 && modules.size == size * size) { "Matrix size does not match its data." }
    }

    operator fun get(x: Int, y: Int): Boolean = modules[y * size + x]

    /** Number of modules that carry data, i.e. without the quiet zone. */
    val dataSize: Int get() = size - 2 * quietZone
}
