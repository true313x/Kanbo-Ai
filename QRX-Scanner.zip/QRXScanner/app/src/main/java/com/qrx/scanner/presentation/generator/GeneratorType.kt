package com.qrx.scanner.presentation.generator

import androidx.annotation.StringRes
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContactPage
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.input.KeyboardType
import com.qrx.scanner.R

/** Every text box a create form can contain. */
enum class GeneratorField(
    @StringRes val labelRes: Int,
    val keyboardType: KeyboardType = KeyboardType.Text,
    val multiline: Boolean = false,
    val isSecret: Boolean = false,
) {
    WEBSITE_URL(R.string.field_website_address, KeyboardType.Uri),
    TEXT(R.string.field_text, multiline = true),
    SSID(R.string.field_network_name),
    PASSWORD(R.string.field_password, KeyboardType.Password, isSecret = true),
    NAME(R.string.field_name),
    PHONE(R.string.field_phone, KeyboardType.Phone),
    EMAIL(R.string.field_email, KeyboardType.Email),
    ORGANIZATION(R.string.field_organization),
    JOB_TITLE(R.string.field_job_title),
    ADDRESS(R.string.field_address),
    CONTACT_WEBSITE(R.string.field_website, KeyboardType.Uri),
    NOTE(R.string.field_note, multiline = true),
    SUBJECT(R.string.field_subject),
    BODY(R.string.field_message, multiline = true),
    LATITUDE(R.string.field_latitude, KeyboardType.Decimal),
    LONGITUDE(R.string.field_longitude, KeyboardType.Decimal),
    LABEL(R.string.field_label),
    ;

    val keyboardOptions: KeyboardOptions get() = KeyboardOptions(keyboardType = keyboardType)
}

enum class GeneratorType(
    @StringRes val labelRes: Int,
    val icon: ImageVector,
    val fields: List<GeneratorField>,
) {
    WEBSITE(R.string.type_url, Icons.Rounded.Language, listOf(GeneratorField.WEBSITE_URL)),
    TEXT(R.string.type_text, Icons.Rounded.TextFields, listOf(GeneratorField.TEXT)),
    WIFI(R.string.type_wifi, Icons.Rounded.Wifi, listOf(GeneratorField.SSID, GeneratorField.PASSWORD)),
    CONTACT(
        R.string.type_contact,
        Icons.Rounded.ContactPage,
        listOf(
            GeneratorField.NAME,
            GeneratorField.PHONE,
            GeneratorField.EMAIL,
            GeneratorField.ORGANIZATION,
            GeneratorField.JOB_TITLE,
            GeneratorField.ADDRESS,
            GeneratorField.CONTACT_WEBSITE,
            GeneratorField.NOTE,
        ),
    ),
    PHONE(R.string.type_phone, Icons.Rounded.Phone, listOf(GeneratorField.PHONE)),
    EMAIL(
        R.string.type_email,
        Icons.Rounded.Email,
        listOf(GeneratorField.EMAIL, GeneratorField.SUBJECT, GeneratorField.BODY),
    ),
    SMS(R.string.type_sms, Icons.Rounded.Sms, listOf(GeneratorField.PHONE, GeneratorField.BODY)),
    LOCATION(
        R.string.type_location,
        Icons.Rounded.LocationOn,
        listOf(GeneratorField.LATITUDE, GeneratorField.LONGITUDE, GeneratorField.LABEL),
    ),
    ;

    companion object {
        fun fromName(name: String): GeneratorType = entries.firstOrNull { it.name == name } ?: WEBSITE
    }
}
