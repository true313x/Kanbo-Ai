package com.qrx.scanner.domain.usecase

import com.qrx.scanner.core.TimeProvider
import com.qrx.scanner.domain.model.CodeFormat
import com.qrx.scanner.domain.model.ParsedContent
import com.qrx.scanner.domain.model.ScanRecord
import com.qrx.scanner.domain.model.ScanSource
import com.qrx.scanner.domain.parser.ContentParser
import com.qrx.scanner.domain.parser.toMetadata
import com.qrx.scanner.domain.repository.HistoryRepository
import com.qrx.scanner.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.first
import javax.inject.Inject

data class ScanOutcome(
    val record: ScanRecord,
    val content: ParsedContent,
)

/** Interprets a detected code and stores it in history when "auto save" is enabled. */
class ProcessScanUseCase @Inject constructor(
    private val history: HistoryRepository,
    private val settings: SettingsRepository,
    private val time: TimeProvider,
) {
    suspend operator fun invoke(rawValue: String, format: CodeFormat, source: ScanSource): ScanOutcome {
        val content = ContentParser.parse(rawValue, format)
        val draft = ScanRecord(
            id = 0L,
            type = content.type,
            rawValue = rawValue,
            displayValue = content.displayValue.ifBlank { rawValue },
            format = format,
            createdAt = time.nowMillis(),
            isFavorite = false,
            metadata = content.toMetadata() + ("source" to source.name.lowercase()),
        )
        val autoSave = settings.settings.first().autoSaveHistory
        val record = if (autoSave) draft.copy(id = history.save(draft)) else draft
        return ScanOutcome(record, content)
    }
}
