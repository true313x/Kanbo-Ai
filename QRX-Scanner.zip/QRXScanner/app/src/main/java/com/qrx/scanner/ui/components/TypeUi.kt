package com.qrx.scanner.ui.components

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContactPage
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.ui.graphics.vector.ImageVector
import com.qrx.scanner.R
import com.qrx.scanner.domain.model.ContentType
import com.qrx.scanner.domain.model.HistoryFilter
import com.qrx.scanner.domain.model.ScanMode
import com.qrx.scanner.domain.model.SearchEngine
import com.qrx.scanner.domain.model.ThemeMode
import com.qrx.scanner.domain.model.WifiSecurity
import com.qrx.scanner.ui.icons.BarcodeIcon

@get:StringRes
val ContentType.labelRes: Int
    get() = when (this) {
        ContentType.URL -> R.string.type_url
        ContentType.TEXT -> R.string.type_text
        ContentType.WIFI -> R.string.type_wifi
        ContentType.CONTACT -> R.string.type_contact
        ContentType.PHONE -> R.string.type_phone
        ContentType.EMAIL -> R.string.type_email
        ContentType.SMS -> R.string.type_sms
        ContentType.GEO -> R.string.type_location
        ContentType.BARCODE -> R.string.type_barcode
    }

val ContentType.icon: ImageVector
    get() = when (this) {
        ContentType.URL -> Icons.Rounded.Language
        ContentType.TEXT -> Icons.Rounded.TextFields
        ContentType.WIFI -> Icons.Rounded.Wifi
        ContentType.CONTACT -> Icons.Rounded.ContactPage
        ContentType.PHONE -> Icons.Rounded.Phone
        ContentType.EMAIL -> Icons.Rounded.Email
        ContentType.SMS -> Icons.Rounded.Sms
        ContentType.GEO -> Icons.Rounded.LocationOn
        ContentType.BARCODE -> BarcodeIcon
    }

@get:StringRes
val HistoryFilter.labelRes: Int
    get() = when (this) {
        HistoryFilter.ALL -> R.string.filter_all
        HistoryFilter.QR -> R.string.filter_qr
        HistoryFilter.BARCODE -> R.string.filter_barcode
        HistoryFilter.URLS -> R.string.filter_urls
        HistoryFilter.TEXT -> R.string.filter_text
        HistoryFilter.WIFI -> R.string.filter_wifi
        HistoryFilter.CONTACTS -> R.string.filter_contacts
        HistoryFilter.OTHER -> R.string.filter_other
    }

@get:StringRes
val ScanMode.labelRes: Int
    get() = when (this) {
        ScanMode.AUTO -> R.string.scan_mode_auto
        ScanMode.QR_ONLY -> R.string.scan_mode_qr_only
        ScanMode.BARCODE_ONLY -> R.string.scan_mode_barcode_only
    }

@get:StringRes
val ThemeMode.labelRes: Int
    get() = when (this) {
        ThemeMode.SYSTEM -> R.string.theme_system
        ThemeMode.LIGHT -> R.string.theme_light
        ThemeMode.DARK -> R.string.theme_dark
    }

@get:StringRes
val SearchEngine.labelRes: Int
    get() = when (this) {
        SearchEngine.GOOGLE -> R.string.search_engine_google
        SearchEngine.BING -> R.string.search_engine_bing
        SearchEngine.DUCKDUCKGO -> R.string.search_engine_duckduckgo
    }

@get:StringRes
val WifiSecurity.labelRes: Int
    get() = when (this) {
        WifiSecurity.OPEN -> R.string.wifi_security_open
        WifiSecurity.WEP -> R.string.wifi_security_wep
        WifiSecurity.WPA -> R.string.wifi_security_wpa
        WifiSecurity.WPA3 -> R.string.wifi_security_wpa3
        WifiSecurity.EAP -> R.string.wifi_security_eap
    }
