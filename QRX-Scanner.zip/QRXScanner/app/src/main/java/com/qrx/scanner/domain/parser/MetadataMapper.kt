package com.qrx.scanner.domain.parser

import com.qrx.scanner.domain.model.ParsedContent

/** Extracts a small, searchable key/value summary that is stored next to the raw value. */
fun ParsedContent.toMetadata(): Map<String, String> = when (this) {
    is ParsedContent.Url -> buildMap {
        UrlParser.parse(url)?.host?.takeIf { it.isNotEmpty() }?.let { put("host", it) }
    }
    is ParsedContent.Wifi -> buildMap {
        put("ssid", ssid)
        put("security", security.name)
        if (hidden) put("hidden", "true")
    }
    is ParsedContent.Contact -> buildMap {
        name?.let { put("name", it) }
        phones.firstOrNull()?.let { put("phone", it) }
        emails.firstOrNull()?.let { put("email", it) }
        organization?.let { put("organization", it) }
    }
    is ParsedContent.Phone -> mapOf("number" to number)
    is ParsedContent.Email -> buildMap {
        put("address", address)
        subject?.let { put("subject", it) }
    }
    is ParsedContent.Sms -> mapOf("number" to number)
    is ParsedContent.Geo -> mapOf("latitude" to latitude.toString(), "longitude" to longitude.toString())
    is ParsedContent.Barcode -> emptyMap()
    is ParsedContent.Text -> emptyMap()
}
