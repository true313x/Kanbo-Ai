package com.qrx.scanner.presentation.favorites

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.qrx.scanner.domain.model.ScanRecord
import com.qrx.scanner.domain.repository.HistoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class FavoritesUiState(
    val isLoading: Boolean = true,
    val records: List<ScanRecord> = emptyList(),
)

sealed interface FavoritesEvent {
    data object Deleted : FavoritesEvent
}

@HiltViewModel
class FavoritesViewModel @Inject constructor(
    private val history: HistoryRepository,
) : ViewModel() {

    val state: StateFlow<FavoritesUiState> = history.observeFavorites()
        .map { FavoritesUiState(isLoading = false, records = it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), FavoritesUiState())

    private val eventChannel = Channel<FavoritesEvent>(Channel.BUFFERED)
    val events: Flow<FavoritesEvent> = eventChannel.receiveAsFlow()

    private var lastDeleted: ScanRecord? = null

    fun toggleFavorite(record: ScanRecord) {
        viewModelScope.launch { history.setFavorite(record.id, !record.isFavorite) }
    }

    fun delete(record: ScanRecord) {
        viewModelScope.launch {
            history.delete(record.id)
            lastDeleted = record
            eventChannel.send(FavoritesEvent.Deleted)
        }
    }

    fun undoDelete() {
        val record = lastDeleted ?: return
        lastDeleted = null
        viewModelScope.launch { history.save(record) }
    }

    private companion object {
        const val STOP_TIMEOUT_MS = 5_000L
    }
}
