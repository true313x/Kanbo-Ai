package com.qrx.scanner.presentation.result

import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.qrx.scanner.R
import com.qrx.scanner.domain.security.Severity
import com.qrx.scanner.domain.security.UrlIssue
import com.qrx.scanner.domain.security.UrlSecurityReport
import com.qrx.scanner.ui.theme.QrxTheme

@get:StringRes
val UrlIssue.messageRes: Int
    get() = when (this) {
        UrlIssue.UNREADABLE -> R.string.issue_unreadable
        UrlIssue.DANGEROUS_SCHEME -> R.string.issue_dangerous_scheme
        UrlIssue.INSECURE_HTTP -> R.string.issue_insecure_http
        UrlIssue.USER_INFO -> R.string.issue_user_info
        UrlIssue.IP_ADDRESS -> R.string.issue_ip_address
        UrlIssue.PUNYCODE -> R.string.issue_punycode
        UrlIssue.NON_ASCII_HOST -> R.string.issue_non_ascii_host
        UrlIssue.VERY_LONG -> R.string.issue_very_long
        UrlIssue.SUSPICIOUS_TLD -> R.string.issue_suspicious_tld
        UrlIssue.URL_SHORTENER -> R.string.issue_url_shortener
        UrlIssue.SUSPICIOUS_REDIRECT -> R.string.issue_suspicious_redirect
        UrlIssue.MANY_SUBDOMAINS -> R.string.issue_many_subdomains
        UrlIssue.NON_STANDARD_PORT -> R.string.issue_non_standard_port
    }

/** Plain-language verdict for a link. A clean verdict is worded as "no warning signs", never as "safe". */
@Composable
fun UrlSecurityBanner(report: UrlSecurityReport, modifier: Modifier = Modifier) {
    val colors = QrxTheme.colors
    val level = report.level
    val container = when (level) {
        Severity.DANGER -> colors.dangerContainer
        Severity.WARNING -> colors.warningContainer
        else -> colors.successContainer
    }
    val accent = when (level) {
        Severity.DANGER -> colors.danger
        Severity.WARNING -> colors.warning
        else -> colors.success
    }
    val icon: ImageVector = when (level) {
        Severity.DANGER -> Icons.Rounded.Error
        Severity.WARNING -> Icons.Rounded.Warning
        else -> Icons.Rounded.CheckCircle
    }
    val title = when (level) {
        Severity.DANGER -> R.string.security_title_danger
        Severity.WARNING -> R.string.security_title_warning
        else -> R.string.security_title_ok
    }

    Row(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.large)
            .background(container)
            .padding(16.dp),
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = accent, modifier = Modifier.size(24.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = stringResource(title),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
            )
            for (finding in report.findings) {
                Text(
                    text = "• " + stringResource(finding.issue.messageRes),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }
            if (level == null || level == Severity.INFO) {
                Text(
                    text = stringResource(R.string.security_ok_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
