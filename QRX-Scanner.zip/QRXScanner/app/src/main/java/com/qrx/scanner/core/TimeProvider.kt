package com.qrx.scanner.core

/** Abstraction over the wall clock so time-dependent logic stays testable. */
fun interface TimeProvider {
    fun nowMillis(): Long
}

object SystemTimeProvider : TimeProvider {
    override fun nowMillis(): Long = System.currentTimeMillis()
}
