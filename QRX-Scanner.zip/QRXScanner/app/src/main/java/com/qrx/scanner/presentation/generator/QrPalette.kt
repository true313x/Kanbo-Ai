package com.qrx.scanner.presentation.generator

import androidx.annotation.StringRes
import com.qrx.scanner.R

class QrColorOption(val argb: Int, @StringRes val nameRes: Int)

/** Curated swatches. Free colour pickers make it too easy to produce a code nobody can scan. */
object QrPalette {
    val foregrounds = listOf(
        QrColorOption(0xFF12152B.toInt(), R.string.color_ink),
        QrColorOption(0xFF5A3DF0.toInt(), R.string.color_violet),
        QrColorOption(0xFF0B6E4F.toInt(), R.string.color_green),
        QrColorOption(0xFFB3261E.toInt(), R.string.color_red),
        QrColorOption(0xFF0B57D0.toInt(), R.string.color_blue),
        QrColorOption(0xFF000000.toInt(), R.string.color_black),
    )

    val backgrounds = listOf(
        QrColorOption(0xFFFFFFFF.toInt(), R.string.color_white),
        QrColorOption(0xFFF1F3FA.toInt(), R.string.color_mist),
        QrColorOption(0xFFFFF4D6.toInt(), R.string.color_cream),
        QrColorOption(0xFFE0F7FA.toInt(), R.string.color_ice),
        QrColorOption(0xFFE8F5E9.toInt(), R.string.color_mint),
        QrColorOption(0xFF12152B.toInt(), R.string.color_ink),
    )
}
