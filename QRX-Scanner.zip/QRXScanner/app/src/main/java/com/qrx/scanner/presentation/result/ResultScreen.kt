package com.qrx.scanner.presentation.result

import android.content.Context
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AddCircle
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.qrx.scanner.R
import com.qrx.scanner.domain.model.ParsedContent
import com.qrx.scanner.domain.model.ScanRecord
import com.qrx.scanner.domain.model.WifiSecurity
import com.qrx.scanner.ui.components.ActionTile
import com.qrx.scanner.ui.components.ConfirmDialog
import com.qrx.scanner.ui.components.ContentMaxWidth
import com.qrx.scanner.ui.components.EmptyState
import com.qrx.scanner.ui.components.LocalContentBottomPadding
import com.qrx.scanner.ui.components.ObserveEvents
import com.qrx.scanner.ui.components.PrimaryButton
import com.qrx.scanner.ui.components.ScreenHeader
import com.qrx.scanner.ui.components.TicketCard
import com.qrx.scanner.ui.components.labelRes
import com.qrx.scanner.ui.components.screenInsets
import com.qrx.scanner.util.ActionResult
import com.qrx.scanner.util.ExternalActions
import kotlinx.coroutines.launch

private class ActionSpec(
    val icon: ImageVector,
    val label: String,
    val enabled: Boolean = true,
    val highlighted: Boolean = false,
    val onClick: () -> Unit,
)

@Composable
fun ResultScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: ResultViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsStateWithLifecycle()
    val actions = remember(context) { ExternalActions(context) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var confirmOpenUrl by rememberSaveable { mutableStateOf(false) }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }

    fun say(@StringRes message: Int) {
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(context.getString(message))
        }
    }

    fun report(result: ActionResult) {
        if (result == ActionResult.NO_APP) say(R.string.result_no_app)
    }

    fun copy(text: String, label: String, sensitive: Boolean = false) {
        if (actions.copyText(label, text, sensitive)) say(R.string.result_copied)
    }

    ObserveEvents(viewModel.events) { event ->
        when (event) {
            is ResultEvent.AutoOpenUrl -> report(actions.openUrl(event.url))
            ResultEvent.Deleted -> onBack()
        }
    }

    val record = state.record
    val content = state.content

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().screenInsets()) {
            ScreenHeader(
                title = content?.let { stringResource(it.type.labelRes) } ?: stringResource(R.string.result_title),
                onBack = onBack,
                actions = {
                    if (record != null && record.isPersisted) {
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(Icons.Rounded.Delete, contentDescription = stringResource(R.string.action_delete))
                        }
                    }
                },
            )
            when {
                record != null && content != null -> {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier
                                .widthIn(max = ContentMaxWidth)
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 20.dp)
                                .padding(top = 4.dp, bottom = LocalContentBottomPadding.current + 16.dp),
                        ) {
                            TicketCard(
                                top = { TicketTop(state, record) },
                                bottom = { TicketBottom(content) },
                            )
                            val urlReport = state.urlReport
                            if (urlReport != null) UrlSecurityBanner(urlReport)

                            val specs = buildActions(
                                context = context,
                                content = content,
                                record = record,
                                state = state,
                                actions = actions,
                                onOpenUrl = {
                                    val verdict = state.urlReport
                                    when {
                                        verdict == null -> report(actions.openUrl((content as ParsedContent.Url).url))
                                        verdict.isBlocked -> Unit
                                        verdict.requiresConfirmation -> confirmOpenUrl = true
                                        else -> report(actions.openUrl(verdict.url))
                                    }
                                },
                                onCopy = ::copy,
                                onReport = ::report,
                                onMessage = ::say,
                                onToggleFavorite = viewModel::toggleFavorite,
                            )
                            specs.primary?.let { primary ->
                                PrimaryButton(
                                    text = primary.label,
                                    icon = primary.icon,
                                    enabled = primary.enabled,
                                    onClick = primary.onClick,
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                for (spec in specs.secondary) {
                                    ActionTile(
                                        icon = spec.icon,
                                        label = spec.label,
                                        enabled = spec.enabled,
                                        highlighted = spec.highlighted,
                                        onClick = spec.onClick,
                                        modifier = Modifier.weight(1f),
                                    )
                                }
                            }
                            ScanDetailsCard(record)
                        }
                    }
                }
                state.notFound -> EmptyState(
                    icon = Icons.Rounded.History,
                    title = stringResource(R.string.result_not_found_title),
                    message = stringResource(R.string.result_not_found_message),
                    modifier = Modifier.weight(1f),
                )
                else -> Box(Modifier.weight(1f))
            }
        }

        SnackbarHost(
            hostState = snackbar,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = LocalContentBottomPadding.current)
                .padding(horizontal = 16.dp),
        )
    }

    val urlContent = content as? ParsedContent.Url
    if (confirmOpenUrl && urlContent != null) {
        ConfirmDialog(
            title = stringResource(R.string.open_link_confirm_title),
            message = stringResource(R.string.open_link_confirm_message, urlContent.url),
            confirmLabel = stringResource(R.string.open_link_confirm_action),
            dismissLabel = stringResource(R.string.action_cancel),
            onConfirm = {
                confirmOpenUrl = false
                report(actions.openUrl(urlContent.url))
            },
            onDismiss = { confirmOpenUrl = false },
            destructive = true,
        )
    }
    if (confirmDelete) {
        ConfirmDialog(
            title = stringResource(R.string.delete_scan_title),
            message = stringResource(R.string.delete_scan_message),
            confirmLabel = stringResource(R.string.action_delete),
            dismissLabel = stringResource(R.string.action_cancel),
            onConfirm = {
                confirmDelete = false
                viewModel.delete()
            },
            onDismiss = { confirmDelete = false },
            destructive = true,
        )
    }
}

private class ActionSet(val primary: ActionSpec?, val secondary: List<ActionSpec>)

private fun buildActions(
    context: Context,
    content: ParsedContent,
    record: ScanRecord,
    state: ResultUiState,
    actions: ExternalActions,
    onOpenUrl: () -> Unit,
    onCopy: (text: String, label: String, sensitive: Boolean) -> Unit,
    onReport: (ActionResult) -> Unit,
    onMessage: (Int) -> Unit,
    onToggleFavorite: () -> Unit,
): ActionSet {
    fun text(@StringRes id: Int): String = context.getString(id)

    val copyLabel = text(R.string.action_copy)
    val copyAction = ActionSpec(Icons.Rounded.ContentCopy, copyLabel) {
        onCopy(copyableText(content, record), copyLabel, false)
    }
    val shareAction = ActionSpec(Icons.Rounded.Share, text(R.string.action_share)) {
        onReport(actions.shareText(shareableText(context, content, record)))
    }
    val searchAction = ActionSpec(Icons.Rounded.Search, text(R.string.action_search_web)) {
        onReport(actions.searchWeb(copyableText(content, record), state.settings.searchEngine))
    }
    val saveAction = ActionSpec(
        icon = if (record.isFavorite) Icons.Rounded.Star else Icons.Rounded.StarBorder,
        label = text(if (record.isFavorite) R.string.action_saved else R.string.action_save),
        highlighted = record.isFavorite,
        onClick = onToggleFavorite,
    )

    return when (content) {
        is ParsedContent.Url -> ActionSet(
            primary = ActionSpec(
                icon = Icons.AutoMirrored.Rounded.OpenInNew,
                label = text(R.string.result_open_link),
                enabled = state.urlReport?.isBlocked != true,
                onClick = onOpenUrl,
            ),
            secondary = listOf(copyAction, shareAction, saveAction),
        )
        is ParsedContent.Text -> ActionSet(
            primary = ActionSpec(Icons.Rounded.ContentCopy, copyLabel) {
                onCopy(content.text, copyLabel, false)
            },
            secondary = listOf(shareAction, searchAction, saveAction),
        )
        is ParsedContent.Wifi -> {
            val password = content.password
            val passwordLabel = text(R.string.result_copy_password)
            ActionSet(
                primary = ActionSpec(Icons.Rounded.Wifi, text(R.string.result_connect_wifi)) {
                    val result = actions.connectWifi(content)
                    if (result == ActionResult.UNSUPPORTED) {
                        if (password != null) {
                            onCopy(password, passwordLabel, true)
                            onMessage(R.string.result_wifi_manual)
                        }
                        onReport(actions.openWifiSettings())
                    } else {
                        onReport(result)
                    }
                },
                secondary = listOfNotNull(
                    password?.let { ActionSpec(Icons.Rounded.Lock, passwordLabel) { onCopy(it, passwordLabel, true) } },
                    shareAction,
                    saveAction,
                ),
            )
        }
        is ParsedContent.Contact -> ActionSet(
            primary = ActionSpec(Icons.Rounded.AddCircle, text(R.string.result_add_contact)) {
                onReport(actions.addContact(content))
            },
            secondary = listOfNotNull(
                content.phones.firstOrNull()?.let { number ->
                    ActionSpec(Icons.Rounded.Call, text(R.string.result_call)) { onReport(actions.dial(number)) }
                },
                copyAction,
                shareAction,
                saveAction,
            ),
        )
        is ParsedContent.Phone -> ActionSet(
            primary = ActionSpec(Icons.Rounded.Call, text(R.string.result_call)) { onReport(actions.dial(content.number)) },
            secondary = listOf(
                ActionSpec(Icons.Rounded.Sms, text(R.string.result_send_sms)) {
                    onReport(actions.composeSms(content.number, null))
                },
                copyAction,
                shareAction,
                saveAction,
            ),
        )
        is ParsedContent.Email -> ActionSet(
            primary = ActionSpec(Icons.AutoMirrored.Rounded.Send, text(R.string.result_send_email)) {
                onReport(actions.composeEmail(content))
            },
            secondary = listOf(copyAction, shareAction, saveAction),
        )
        is ParsedContent.Sms -> ActionSet(
            primary = ActionSpec(Icons.Rounded.Sms, text(R.string.result_send_sms)) {
                onReport(actions.composeSms(content.number, content.message))
            },
            secondary = listOf(copyAction, shareAction, saveAction),
        )
        is ParsedContent.Geo -> ActionSet(
            primary = ActionSpec(Icons.Rounded.LocationOn, text(R.string.result_open_maps)) {
                onReport(actions.openMap(content))
            },
            secondary = listOf(copyAction, shareAction, saveAction),
        )
        is ParsedContent.Barcode -> ActionSet(
            primary = ActionSpec(Icons.Rounded.Search, text(R.string.action_search_web)) {
                onReport(actions.searchWeb(content.value, state.settings.searchEngine))
            },
            secondary = listOf(copyAction, shareAction, saveAction),
        )
    }
}

/** What the "Copy" action puts on the clipboard for each kind of content. */
internal fun copyableText(content: ParsedContent, record: ScanRecord): String = when (content) {
    is ParsedContent.Url -> content.url
    is ParsedContent.Phone -> content.number
    is ParsedContent.Email -> content.address
    is ParsedContent.Geo -> content.displayValue
    is ParsedContent.Contact -> listOfNotNull(content.name, content.organization)
        .plus(content.phones)
        .plus(content.emails)
        .joinToString("\n")
        .ifBlank { record.rawValue }
    is ParsedContent.Sms -> content.message ?: content.number
    is ParsedContent.Barcode -> content.value
    is ParsedContent.Text, is ParsedContent.Wifi -> record.rawValue
}

private fun shareableText(context: Context, content: ParsedContent, record: ScanRecord): String = when (content) {
    is ParsedContent.Wifi -> {
        val password = content.password
        if (password != null && content.security != WifiSecurity.OPEN) {
            context.getString(R.string.share_wifi_with_password, content.ssid, password)
        } else {
            context.getString(R.string.share_wifi_open, content.ssid)
        }
    }
    else -> copyableText(content, record)
}
