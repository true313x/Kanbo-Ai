package com.qrx.scanner.navigation

import com.qrx.scanner.domain.model.CodeFormat
import com.qrx.scanner.domain.model.ScanSource
import kotlinx.serialization.Serializable

@Serializable
data object ScannerRoute

@Serializable
data object HistoryRoute

@Serializable
data object CreateRoute

@Serializable
data object SettingsRoute

@Serializable
data object FavoritesRoute

/**
 * Shows a scanned (or stored) code. It doubles as the "Scan details" screen.
 * With [historyId] > 0 the record is loaded from the database, otherwise [rawValue] is interpreted.
 */
@Serializable
data class ResultRoute(
    val historyId: Long = 0L,
    val rawValue: String = "",
    val format: String = CodeFormat.QR_CODE.name,
    val source: String = ScanSource.CAMERA.name,
    val fresh: Boolean = false,
)

@Serializable
data class ImageScanRoute(val uri: String)

@Serializable
data class GeneratorRoute(val type: String)

@Serializable
data class DocumentRoute(val kind: String)
