package com.qrx.scanner.scanner

import android.graphics.Bitmap
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import com.google.zxing.WriterException
import com.google.zxing.common.BitMatrix
import com.qrx.scanner.core.DispatcherProvider
import com.qrx.scanner.domain.model.CodeFormat
import kotlinx.coroutines.withContext
import javax.inject.Inject

/** Re-draws a scanned code (black on white) so the result screen can show what was read. */
class CodePreviewRenderer @Inject constructor(
    private val dispatchers: DispatcherProvider,
) {
    /** Returns null when the value cannot be encoded again in the given symbology. */
    suspend fun render(rawValue: String, format: CodeFormat): Bitmap? = withContext(dispatchers.default) {
        try {
            val (width, height) = when {
                format == CodeFormat.PDF_417 -> 720 to 270
                format.isTwoDimensional -> 560 to 560
                else -> 720 to 220
            }
            val hints = HashMap<EncodeHintType, Any>()
            if (format.isTwoDimensional && rawValue.any { it.code > 127 }) {
                hints[EncodeHintType.CHARACTER_SET] = "UTF-8"
            }
            val matrix = MultiFormatWriter().encode(rawValue, ZxingFormatMapper.toZxing(format), width, height, hints)
            matrix.toBitmap()
        } catch (error: WriterException) {
            null
        } catch (error: IllegalArgumentException) {
            null
        }
    }

    private fun BitMatrix.toBitmap(): Bitmap {
        val pixels = IntArray(width * height)
        for (y in 0 until height) {
            val row = y * width
            for (x in 0 until width) {
                pixels[row + x] = if (get(x, y)) BLACK else WHITE
            }
        }
        return Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
    }

    private companion object {
        const val BLACK = 0xFF000000.toInt()
        const val WHITE = 0xFFFFFFFF.toInt()
    }
}
