package com.qrx.scanner.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

private val NotchRadius = 11.dp
private val CornerRadiusDp = 24.dp

/** A rounded card with a semicircular notch cut out of both sides at [notchCenterY]; looks like a torn ticket. */
private class TicketShape(
    private val notchCenterY: Float,
    private val notchRadius: Float,
    private val cornerRadius: Float,
) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val body = Path().apply {
            addRoundRect(RoundRect(Rect(Offset.Zero, size), CornerRadius(cornerRadius, cornerRadius)))
        }
        if (notchCenterY <= notchRadius || notchCenterY >= size.height - notchRadius) return Outline.Generic(body)

        val notches = Path().apply {
            addOval(Rect(Offset(-notchRadius, notchCenterY - notchRadius), Size(notchRadius * 2, notchRadius * 2)))
            addOval(Rect(Offset(size.width - notchRadius, notchCenterY - notchRadius), Size(notchRadius * 2, notchRadius * 2)))
        }
        return Outline.Generic(Path.combine(PathOperation.Difference, body, notches))
    }
}

/**
 * The signature element of the app: a code "ticket". [top] holds the code preview, [bottom] the details,
 * and a dashed tear line with side notches separates them.
 */
@Composable
fun TicketCard(
    modifier: Modifier = Modifier,
    top: @Composable ColumnScope.() -> Unit,
    bottom: @Composable ColumnScope.() -> Unit,
) {
    val density = LocalDensity.current
    val notchRadiusPx = with(density) { NotchRadius.toPx() }
    val cornerPx = with(density) { CornerRadiusDp.toPx() }
    var topHeightPx by remember { mutableFloatStateOf(0f) }
    val shape = TicketShape(
        notchCenterY = topHeightPx + notchRadiusPx,
        notchRadius = notchRadiusPx,
        cornerRadius = cornerPx,
    )
    val tearColor = MaterialTheme.colorScheme.outline

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape),
    ) {
        Column(modifier = Modifier.onSizeChanged { topHeightPx = it.height.toFloat() }, content = top)
        TearLine(color = tearColor, height = NotchRadius * 2, inset = NotchRadius + 8.dp)
        Column(content = bottom)
    }
}

@Composable
private fun TearLine(color: Color, height: Dp, inset: Dp) {
    Box(modifier = Modifier
        .fillMaxWidth()
        .height(height)
        .padding(horizontal = inset),
    ) {
        Canvas(modifier = Modifier.fillMaxWidth().height(height)) {
            val y = size.height / 2f
            drawLine(
                color = color,
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = 1.5.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(7.dp.toPx(), 6.dp.toPx())),
            )
        }
    }
}
