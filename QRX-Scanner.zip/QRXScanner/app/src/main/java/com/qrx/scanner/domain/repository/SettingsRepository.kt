package com.qrx.scanner.domain.repository

import com.qrx.scanner.domain.model.AppSettings
import com.qrx.scanner.domain.model.ScanMode
import com.qrx.scanner.domain.model.SearchEngine
import com.qrx.scanner.domain.model.ThemeMode
import kotlinx.coroutines.flow.Flow

interface SettingsRepository {
    val settings: Flow<AppSettings>
    suspend fun setThemeMode(mode: ThemeMode)
    suspend fun setScanSound(enabled: Boolean)
    suspend fun setHaptics(enabled: Boolean)
    suspend fun setAutoOpenLinks(enabled: Boolean)
    suspend fun setAutoSaveHistory(enabled: Boolean)
    suspend fun setScanMode(mode: ScanMode)
    suspend fun setSearchEngine(engine: SearchEngine)
}
