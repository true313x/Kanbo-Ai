package com.qrx.scanner.ui.theme

import androidx.compose.ui.graphics.Color

// Brand: a midnight-indigo surface family with a single ultraviolet primary and a cyan "scan beam".
internal val Ink = Color(0xFF12152B)
internal val Midnight = Color(0xFF0D1024)
internal val Violet600 = Color(0xFF5A3DF0)
internal val Violet300 = Color(0xFFA596FF)
internal val Beam = Color(0xFF29D3F5)
internal val BeamDeep = Color(0xFF0097B8)

// Light
internal val LightBackground = Color(0xFFF1F3FA)
internal val LightSurface = Color(0xFFFFFFFF)
internal val LightSurfaceLow = Color(0xFFF7F8FD)
internal val LightSurfaceHigh = Color(0xFFE9ECF7)
internal val LightSurfaceHighest = Color(0xFFE1E5F3)
internal val LightOnSurfaceVariant = Color(0xFF565B7D)
internal val LightOutline = Color(0xFFB9BED8)
internal val LightOutlineVariant = Color(0xFFDADDEE)
internal val LightPrimaryContainer = Color(0xFFE4DEFF)
internal val LightOnPrimaryContainer = Color(0xFF20107A)
internal val LightError = Color(0xFFD1272D)
internal val LightErrorContainer = Color(0xFFFFE3E4)

// Dark
internal val DarkSurface = Color(0xFF151A36)
internal val DarkSurfaceLow = Color(0xFF111530)
internal val DarkSurfaceHigh = Color(0xFF1C2245)
internal val DarkSurfaceHighest = Color(0xFF242B55)
internal val DarkOnSurface = Color(0xFFECEEFB)
internal val DarkOnSurfaceVariant = Color(0xFFA3A9CF)
internal val DarkOutline = Color(0xFF4A5290)
internal val DarkOutlineVariant = Color(0xFF2A3160)
internal val DarkPrimaryContainer = Color(0xFF33288F)
internal val DarkOnPrimaryContainer = Color(0xFFE4DEFF)
internal val DarkOnPrimary = Color(0xFF1B0F6B)
internal val DarkError = Color(0xFFFF7A80)
internal val DarkErrorContainer = Color(0xFF4A1B1F)
