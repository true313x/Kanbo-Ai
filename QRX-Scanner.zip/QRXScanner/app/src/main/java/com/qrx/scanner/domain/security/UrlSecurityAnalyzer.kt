package com.qrx.scanner.domain.security

import com.qrx.scanner.domain.parser.TextCodec
import com.qrx.scanner.domain.parser.UrlParser
import com.qrx.scanner.domain.parser.UrlParts
import javax.inject.Inject

enum class Severity { INFO, WARNING, DANGER }

enum class UrlIssue {
    UNREADABLE,
    DANGEROUS_SCHEME,
    INSECURE_HTTP,
    USER_INFO,
    IP_ADDRESS,
    PUNYCODE,
    NON_ASCII_HOST,
    VERY_LONG,
    SUSPICIOUS_TLD,
    URL_SHORTENER,
    SUSPICIOUS_REDIRECT,
    MANY_SUBDOMAINS,
    NON_STANDARD_PORT,
}

data class UrlFinding(val issue: UrlIssue, val severity: Severity)

data class UrlSecurityReport(
    val url: String,
    val scheme: String?,
    val host: String?,
    val findings: List<UrlFinding>,
) {
    val level: Severity?
        get() = findings.maxByOrNull { it.severity.ordinal }?.severity

    /** The "Open" action must be disabled. */
    val isBlocked: Boolean get() = findings.any { it.severity == Severity.DANGER }

    /** The user has to confirm before the link is opened. */
    val requiresConfirmation: Boolean
        get() = !isBlocked && findings.any { it.severity == Severity.WARNING }

    /** Only plain https links without any warning may be opened automatically (and only if the user enabled it). */
    val canAutoOpen: Boolean
        get() = scheme == "https" && findings.none { it.severity != Severity.INFO }

    val isClean: Boolean get() = findings.none { it.severity != Severity.INFO }
}

/** Static, offline heuristics. A "clean" report is not a guarantee that a site is safe. */
class UrlSecurityAnalyzer @Inject constructor() {

    fun analyze(url: String): UrlSecurityReport {
        val trimmed = url.trim()
        val parts = UrlParser.parse(trimmed)
            ?: return UrlSecurityReport(trimmed, null, null, listOf(UrlFinding(UrlIssue.UNREADABLE, Severity.DANGER)))

        val findings = LinkedHashMap<UrlIssue, Severity>()
        fun flag(issue: UrlIssue, severity: Severity) {
            findings.putIfAbsent(issue, severity)
        }

        if (parts.scheme != "http" && parts.scheme != "https") {
            flag(UrlIssue.DANGEROUS_SCHEME, Severity.DANGER)
        } else {
            if (parts.scheme == "http") flag(UrlIssue.INSECURE_HTTP, Severity.WARNING)
            if (!parts.hasAuthority || parts.host.isEmpty()) {
                flag(UrlIssue.UNREADABLE, Severity.DANGER)
            } else {
                analyzeHost(parts, flag = ::flag)
            }
            if (!parts.userInfo.isNullOrEmpty()) flag(UrlIssue.USER_INFO, Severity.WARNING)
            if (trimmed.length > VERY_LONG_URL_LENGTH) flag(UrlIssue.VERY_LONG, Severity.WARNING)
            if (hasRedirect(parts)) flag(UrlIssue.SUSPICIOUS_REDIRECT, Severity.WARNING)
            val port = parts.port
            if (port != null && port != 80 && port != 443) flag(UrlIssue.NON_STANDARD_PORT, Severity.INFO)
        }

        return UrlSecurityReport(
            url = trimmed,
            scheme = parts.scheme,
            host = parts.host.takeIf { it.isNotEmpty() },
            findings = findings.map { UrlFinding(it.key, it.value) },
        )
    }

    private fun analyzeHost(parts: UrlParts, flag: (UrlIssue, Severity) -> Unit) {
        val host = parts.host
        if (host.startsWith("[") || NUMERIC_HOST.matches(host)) flag(UrlIssue.IP_ADDRESS, Severity.WARNING)
        if (host.split('.').any { it.startsWith("xn--") }) flag(UrlIssue.PUNYCODE, Severity.WARNING)
        if (host.any { it.code > 127 }) flag(UrlIssue.NON_ASCII_HOST, Severity.WARNING)

        val labels = host.split('.').filter { it.isNotEmpty() }
        val tld = labels.lastOrNull().orEmpty()
        if (labels.size > 1 && tld in SUSPICIOUS_TLDS) flag(UrlIssue.SUSPICIOUS_TLD, Severity.WARNING)
        if (labels.size >= MANY_SUBDOMAIN_LABELS) flag(UrlIssue.MANY_SUBDOMAINS, Severity.WARNING)
        if (SHORTENERS.any { host == it || host.endsWith(".$it") }) flag(UrlIssue.URL_SHORTENER, Severity.WARNING)
    }

    private fun hasRedirect(parts: UrlParts): Boolean {
        if (parts.path.contains("://") || parts.path.contains("%3a%2f%2f", ignoreCase = true)) return true
        val query = TextCodec.parseQuery(parts.query)
        return query.any { (key, value) ->
            key in REDIRECT_KEYS && REDIRECT_TARGET.containsMatchIn(value.trimStart().lowercase())
        }
    }

    private companion object {
        const val VERY_LONG_URL_LENGTH = 300
        const val MANY_SUBDOMAIN_LABELS = 5

        val NUMERIC_HOST = Regex("^((0x[0-9a-f]+|\\d+)\\.){0,3}(0x[0-9a-f]+|\\d+)$")
        val REDIRECT_TARGET = Regex("^(https?:)?//")

        val REDIRECT_KEYS = setOf(
            "url", "redirect", "redirect_url", "redirect_uri", "redirecturl", "return", "returnurl", "return_url",
            "next", "goto", "dest", "destination", "continue", "target", "link", "u", "r", "to", "out",
        )

        val SUSPICIOUS_TLDS = setOf(
            "zip", "mov", "tk", "ml", "ga", "cf", "gq", "top", "click", "country", "kim", "loan", "work",
            "men", "gdn", "stream", "download", "racing", "accountant", "science", "party", "cricket",
            "win", "bid", "trade", "webcam", "icu", "cyou", "buzz", "rest", "monster",
        )

        val SHORTENERS = setOf(
            "bit.ly", "t.co", "tinyurl.com", "goo.gl", "ow.ly", "is.gd", "buff.ly", "rebrand.ly", "cutt.ly",
            "tiny.cc", "shorturl.at", "rb.gy", "lnkd.in", "s.id", "t.ly", "v.gd",
        )
    }
}
