package com.qrx.scanner.domain.model

enum class HistoryFilter { ALL, QR, BARCODE, URLS, TEXT, WIFI, CONTACTS, OTHER }
