package com.qrx.scanner.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper

/** Walks the wrapper chain (Compose hands out themed wrappers) to find the hosting activity. */
fun Context.findActivity(): Activity? {
    var current: Context = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return null
}
