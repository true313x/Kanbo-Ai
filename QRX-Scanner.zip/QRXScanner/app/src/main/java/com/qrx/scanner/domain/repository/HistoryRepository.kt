package com.qrx.scanner.domain.repository

import com.qrx.scanner.domain.model.ScanRecord
import kotlinx.coroutines.flow.Flow

interface HistoryRepository {
    fun observeAll(): Flow<List<ScanRecord>>
    fun observeFavorites(): Flow<List<ScanRecord>>
    fun observeById(id: Long): Flow<ScanRecord?>
    suspend fun getById(id: Long): ScanRecord?

    /** Inserts a new record (id == 0) or replaces an existing one. Returns the row id. */
    suspend fun save(record: ScanRecord): Long
    suspend fun setFavorite(id: Long, favorite: Boolean)
    suspend fun delete(id: Long)
    suspend fun deleteAll()
}
