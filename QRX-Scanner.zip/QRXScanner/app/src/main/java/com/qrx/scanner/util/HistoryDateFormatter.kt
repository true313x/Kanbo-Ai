package com.qrx.scanner.util

import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

/** Formats scan timestamps as "Today • 10:32 PM", "Yesterday • 9:05 AM" or "Oct 3 • 8:15 PM". */
object HistoryDateFormatter {

    fun format(
        timestampMillis: Long,
        nowMillis: Long,
        locale: Locale,
        todayLabel: String,
        yesterdayLabel: String,
        zone: ZoneId = ZoneId.systemDefault(),
    ): String {
        val moment = Instant.ofEpochMilli(timestampMillis).atZone(zone)
        val today = Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate()
        val date = moment.toLocalDate()
        val time = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).withLocale(locale).format(moment)
        val day = when (date) {
            today -> todayLabel
            today.minusDays(1) -> yesterdayLabel
            else -> {
                val pattern = if (date.year == today.year) "d MMM" else "d MMM yyyy"
                DateTimeFormatter.ofPattern(pattern, locale).format(date)
            }
        }
        return "$day • $time"
    }

    /** Full date and time, used on the details card. */
    fun formatFull(timestampMillis: Long, locale: Locale, zone: ZoneId = ZoneId.systemDefault()): String {
        val moment = Instant.ofEpochMilli(timestampMillis).atZone(zone)
        return DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.SHORT)
            .withLocale(locale)
            .format(moment)
    }
}
