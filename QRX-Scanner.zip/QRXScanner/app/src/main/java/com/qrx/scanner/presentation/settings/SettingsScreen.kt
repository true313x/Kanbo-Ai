package com.qrx.scanner.presentation.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.PrivacyTip
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.qrx.scanner.BuildConfig
import com.qrx.scanner.R
import com.qrx.scanner.core.locale.AppLanguage
import com.qrx.scanner.core.locale.LanguageManager
import com.qrx.scanner.domain.model.ScanMode
import com.qrx.scanner.domain.model.SearchEngine
import com.qrx.scanner.domain.model.ThemeMode
import com.qrx.scanner.presentation.document.DocumentKind
import com.qrx.scanner.ui.components.ConfirmDialog
import com.qrx.scanner.ui.components.ContentMaxWidth
import com.qrx.scanner.ui.components.LocalContentBottomPadding
import com.qrx.scanner.ui.components.ScreenHeader
import com.qrx.scanner.ui.components.SegmentOption
import com.qrx.scanner.ui.components.SegmentedControl
import com.qrx.scanner.ui.components.SettingsClickRow
import com.qrx.scanner.ui.components.SettingsControlRow
import com.qrx.scanner.ui.components.SettingsDivider
import com.qrx.scanner.ui.components.SettingsSection
import com.qrx.scanner.ui.components.SettingsSwitchRow
import com.qrx.scanner.ui.components.labelRes
import com.qrx.scanner.ui.components.screenInsets
import com.qrx.scanner.util.ActionResult
import com.qrx.scanner.util.ExternalActions
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    onOpenDocument: (DocumentKind) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: SettingsViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val actions = remember(context) { ExternalActions(context) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var confirmClear by rememberSaveable { mutableStateOf(false) }
    var language by remember { mutableStateOf(LanguageManager.current()) }

    val historyClearedMessage = stringResource(R.string.settings_history_cleared)
    val noAppMessage = stringResource(R.string.result_no_app)

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().screenInsets()) {
            ScreenHeader(title = stringResource(R.string.settings_title))
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(24.dp),
                    modifier = Modifier
                        .widthIn(max = ContentMaxWidth)
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp)
                        .padding(top = 4.dp, bottom = LocalContentBottomPadding.current + 16.dp),
                ) {
                    SettingsSection(title = stringResource(R.string.settings_section_appearance)) {
                        SettingsControlRow(icon = Icons.Rounded.DarkMode, title = stringResource(R.string.settings_theme)) {
                            SegmentedControl(
                                options = ThemeMode.entries.map { SegmentOption(it, stringResource(it.labelRes)) },
                                selected = settings.themeMode,
                                onSelect = viewModel::setThemeMode,
                            )
                        }
                        SettingsDivider()
                        SettingsControlRow(icon = Icons.Rounded.Translate, title = stringResource(R.string.settings_language)) {
                            SegmentedControl(
                                options = listOf(
                                    SegmentOption(AppLanguage.ENGLISH, stringResource(R.string.language_english)),
                                    SegmentOption(AppLanguage.ARABIC, stringResource(R.string.language_arabic)),
                                ),
                                selected = language,
                                onSelect = {
                                    language = it
                                    LanguageManager.apply(it)
                                },
                            )
                        }
                    }

                    SettingsSection(title = stringResource(R.string.settings_section_scanner)) {
                        SettingsSwitchRow(
                            icon = Icons.Rounded.VolumeUp,
                            title = stringResource(R.string.settings_scan_sound),
                            checked = settings.scanSound,
                            onCheckedChange = viewModel::setScanSound,
                        )
                        SettingsDivider()
                        SettingsSwitchRow(
                            icon = Icons.Rounded.Vibration,
                            title = stringResource(R.string.settings_haptics),
                            checked = settings.haptics,
                            onCheckedChange = viewModel::setHaptics,
                        )
                        SettingsDivider()
                        SettingsSwitchRow(
                            icon = Icons.Rounded.Link,
                            title = stringResource(R.string.settings_auto_open_links),
                            subtitle = stringResource(R.string.settings_auto_open_links_hint),
                            checked = settings.autoOpenLinks,
                            onCheckedChange = viewModel::setAutoOpenLinks,
                        )
                        SettingsDivider()
                        SettingsSwitchRow(
                            icon = Icons.Rounded.History,
                            title = stringResource(R.string.settings_auto_save),
                            checked = settings.autoSaveHistory,
                            onCheckedChange = viewModel::setAutoSaveHistory,
                        )
                        SettingsDivider()
                        SettingsControlRow(icon = Icons.Rounded.QrCodeScanner, title = stringResource(R.string.settings_scan_mode)) {
                            SegmentedControl(
                                options = ScanMode.entries.map { SegmentOption(it, stringResource(it.labelRes)) },
                                selected = settings.scanMode,
                                onSelect = viewModel::setScanMode,
                            )
                        }
                        SettingsDivider()
                        SettingsControlRow(
                            icon = Icons.Rounded.Search,
                            title = stringResource(R.string.settings_search_engine),
                            subtitle = stringResource(R.string.settings_search_engine_hint),
                        ) {
                            SegmentedControl(
                                options = SearchEngine.entries.map { SegmentOption(it, stringResource(it.labelRes)) },
                                selected = settings.searchEngine,
                                onSelect = viewModel::setSearchEngine,
                            )
                        }
                    }

                    SettingsSection(title = stringResource(R.string.settings_section_privacy)) {
                        SettingsClickRow(
                            icon = Icons.Rounded.DeleteSweep,
                            title = stringResource(R.string.settings_clear_history),
                            onClick = { confirmClear = true },
                            showChevron = false,
                        )
                        SettingsDivider()
                        SettingsClickRow(
                            icon = Icons.Rounded.CameraAlt,
                            title = stringResource(R.string.settings_camera_permission),
                            subtitle = stringResource(R.string.settings_camera_permission_hint),
                            onClick = {
                                if (actions.openAppSettings() == ActionResult.NO_APP) {
                                    scope.launch { snackbar.showSnackbar(noAppMessage) }
                                }
                            },
                        )
                        SettingsDivider()
                        SettingsClickRow(
                            icon = Icons.Rounded.Shield,
                            title = stringResource(R.string.settings_privacy_info),
                            onClick = { onOpenDocument(DocumentKind.PRIVACY_INFO) },
                        )
                    }

                    SettingsSection(title = stringResource(R.string.settings_section_about)) {
                        SettingsClickRow(
                            icon = Icons.Rounded.Info,
                            title = stringResource(R.string.settings_version),
                            value = BuildConfig.VERSION_NAME,
                            onClick = {},
                            showChevron = false,
                        )
                        SettingsDivider()
                        SettingsClickRow(
                            icon = Icons.Rounded.QrCodeScanner,
                            title = stringResource(R.string.settings_about),
                            onClick = { onOpenDocument(DocumentKind.ABOUT) },
                        )
                        SettingsDivider()
                        SettingsClickRow(
                            icon = Icons.Rounded.Description,
                            title = stringResource(R.string.settings_licenses),
                            onClick = { onOpenDocument(DocumentKind.LICENSES) },
                        )
                        SettingsDivider()
                        SettingsClickRow(
                            icon = Icons.Rounded.PrivacyTip,
                            title = stringResource(R.string.settings_privacy_policy),
                            onClick = { onOpenDocument(DocumentKind.PRIVACY_POLICY) },
                        )
                    }
                }
            }
        }
        SnackbarHost(
            hostState = snackbar,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = LocalContentBottomPadding.current)
                .padding(horizontal = 16.dp),
        )
    }

    if (confirmClear) {
        ConfirmDialog(
            title = stringResource(R.string.history_delete_all_title),
            message = stringResource(R.string.history_delete_all_message),
            confirmLabel = stringResource(R.string.history_delete_all_confirm),
            dismissLabel = stringResource(R.string.action_cancel),
            onConfirm = {
                confirmClear = false
                viewModel.clearHistory()
                scope.launch { snackbar.showSnackbar(historyClearedMessage) }
            },
            onDismiss = { confirmClear = false },
            destructive = true,
        )
    }
}
