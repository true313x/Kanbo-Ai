package com.qrx.scanner.presentation.scanner

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.qrx.scanner.ui.theme.QrxTheme

/**
 * Dimmed viewfinder with corner brackets, a travelling beam, and a success state
 * (brackets turn green and a check mark pops in). Purely decorative: it does not intercept touches.
 */
@Composable
fun ScanOverlay(
    frameSize: Dp,
    success: Boolean,
    successDescription: String,
    modifier: Modifier = Modifier,
) {
    val colors = QrxTheme.colors
    val bracketColor by animateColorAsState(
        targetValue = if (success) colors.success else Color.White,
        animationSpec = tween(180),
        label = "bracketColor",
    )
    val glowColor by animateColorAsState(
        targetValue = if (success) colors.success else colors.beam,
        animationSpec = tween(180),
        label = "glowColor",
    )
    val beamProgress by rememberInfiniteTransition(label = "beam").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "beamProgress",
    )
    val checkScale by animateFloatAsState(
        targetValue = if (success) 1f else 0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "checkScale",
    )
    val scrim = colors.cameraScrim

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val side = frameSize.toPx()
            val left = (size.width - side) / 2f
            val top = (size.height - side) / 2f
            val radius = 28.dp.toPx()

            val hole = Path().apply {
                addRoundRect(RoundRect(left, top, left + side, top + side, CornerRadius(radius)))
            }
            clipPath(hole, clipOp = ClipOp.Difference) { drawRect(scrim) }

            val arm = 40.dp.toPx()
            val brackets = Path()
            for (right in listOf(false, true)) {
                for (bottom in listOf(false, true)) {
                    val x = if (right) left + side else left
                    val y = if (bottom) top + side else top
                    val dx = if (right) -1f else 1f
                    val dy = if (bottom) -1f else 1f
                    brackets.moveTo(x, y + dy * arm)
                    brackets.lineTo(x, y + dy * radius)
                    brackets.quadraticTo(x, y, x + dx * radius, y)
                    brackets.lineTo(x + dx * arm, y)
                }
            }
            drawPath(
                path = brackets,
                color = glowColor.copy(alpha = 0.28f),
                style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
            )
            drawPath(
                path = brackets,
                color = bracketColor,
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
            )

            if (!success) {
                val inset = 18.dp.toPx()
                val y = top + inset + beamProgress * (side - 2 * inset)
                val trail = 56.dp.toPx()
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color.Transparent, glowColor.copy(alpha = 0.22f)),
                        startY = y - trail,
                        endY = y,
                    ),
                    topLeft = Offset(left + inset, y - trail),
                    size = Size(side - 2 * inset, trail),
                )
                drawLine(
                    brush = Brush.horizontalGradient(
                        colors = listOf(Color.Transparent, glowColor, Color.Transparent),
                        startX = left,
                        endX = left + side,
                    ),
                    start = Offset(left + inset, y),
                    end = Offset(left + side - inset, y),
                    strokeWidth = 3.dp.toPx(),
                    cap = StrokeCap.Round,
                )
            }
        }
        Icon(
            imageVector = Icons.Rounded.CheckCircle,
            contentDescription = if (success) successDescription else null,
            tint = colors.success,
            modifier = Modifier
                .size(76.dp)
                .graphicsLayer {
                    scaleX = checkScale
                    scaleY = checkScale
                    alpha = checkScale.coerceIn(0f, 1f)
                },
        )
    }
}
