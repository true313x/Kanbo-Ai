package com.qrx.scanner.data.settings

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import com.qrx.scanner.domain.model.AppSettings
import com.qrx.scanner.domain.model.ScanMode
import com.qrx.scanner.domain.model.SearchEngine
import com.qrx.scanner.domain.model.ThemeMode
import com.qrx.scanner.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject

class SettingsRepositoryImpl @Inject constructor(
    private val dataStore: DataStore<Preferences>,
) : SettingsRepository {

    override val settings: Flow<AppSettings> = dataStore.data
        .catch { error ->
            if (error is IOException) emit(emptyPreferences()) else throw error
        }
        .map { prefs ->
            val defaults = AppSettings()
            AppSettings(
                themeMode = prefs[THEME].toEnum(defaults.themeMode),
                scanSound = prefs[SOUND] ?: defaults.scanSound,
                haptics = prefs[HAPTICS] ?: defaults.haptics,
                autoOpenLinks = prefs[AUTO_OPEN] ?: defaults.autoOpenLinks,
                autoSaveHistory = prefs[AUTO_SAVE] ?: defaults.autoSaveHistory,
                scanMode = prefs[SCAN_MODE].toEnum(defaults.scanMode),
                searchEngine = prefs[SEARCH_ENGINE].toEnum(defaults.searchEngine),
            )
        }

    override suspend fun setThemeMode(mode: ThemeMode) = write { it[THEME] = mode.name }
    override suspend fun setScanSound(enabled: Boolean) = write { it[SOUND] = enabled }
    override suspend fun setHaptics(enabled: Boolean) = write { it[HAPTICS] = enabled }
    override suspend fun setAutoOpenLinks(enabled: Boolean) = write { it[AUTO_OPEN] = enabled }
    override suspend fun setAutoSaveHistory(enabled: Boolean) = write { it[AUTO_SAVE] = enabled }
    override suspend fun setScanMode(mode: ScanMode) = write { it[SCAN_MODE] = mode.name }
    override suspend fun setSearchEngine(engine: SearchEngine) = write { it[SEARCH_ENGINE] = engine.name }

    private suspend fun write(block: (MutablePreferences) -> Unit) {
        dataStore.edit { block(it) }
    }

    private inline fun <reified E : Enum<E>> String?.toEnum(default: E): E =
        enumValues<E>().firstOrNull { it.name == this } ?: default

    private companion object {
        val THEME = stringPreferencesKey("theme_mode")
        val SOUND = booleanPreferencesKey("scan_sound")
        val HAPTICS = booleanPreferencesKey("haptics")
        val AUTO_OPEN = booleanPreferencesKey("auto_open_links")
        val AUTO_SAVE = booleanPreferencesKey("auto_save_history")
        val SCAN_MODE = stringPreferencesKey("scan_mode")
        val SEARCH_ENGINE = stringPreferencesKey("search_engine")
    }
}
