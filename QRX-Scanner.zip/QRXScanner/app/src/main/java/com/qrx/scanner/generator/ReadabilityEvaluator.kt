package com.qrx.scanner.generator

import com.google.zxing.BinaryBitmap
import com.google.zxing.LuminanceSource
import com.google.zxing.DecodeHintType
import com.google.zxing.ReaderException
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeReader
import javax.inject.Inject
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Decides whether a styled QR code can still be scanned, by actually decoding a rendering of it with ZXing.
 * Pure Kotlin so it can be unit tested on the JVM.
 */
class ReadabilityEvaluator @Inject constructor() {

    fun evaluate(
        matrix: QrMatrix,
        foreground: Int,
        background: Int,
        hasLogo: Boolean,
    ): Readability {
        val contrast = contrastRatio(foreground, background)
        if (contrast < POOR_CONTRAST) return Readability.POOR

        val pixels = render(matrix, foreground, background, hasLogo)
        val side = matrix.size * PROBE_SCALE
        val source = RGBLuminanceSource(side, side, pixels)

        val readsNormally = decodes(source)
        val readsInverted = !readsNormally && decodes(source.invert())
        return when {
            !readsNormally && !readsInverted -> Readability.POOR
            readsInverted -> Readability.RISKY
            contrast < GOOD_CONTRAST -> Readability.RISKY
            else -> Readability.GOOD
        }
    }

    private fun decodes(source: LuminanceSource): Boolean {
        val hints = mapOf<DecodeHintType, Any>(DecodeHintType.TRY_HARDER to true)
        return try {
            QRCodeReader().decode(BinaryBitmap(HybridBinarizer(source)), hints).text.isNotEmpty()
        } catch (error: ReaderException) {
            false
        }
    }

    private fun render(matrix: QrMatrix, foreground: Int, background: Int, hasLogo: Boolean): IntArray {
        val side = matrix.size * PROBE_SCALE
        val pixels = IntArray(side * side) { background }
        for (y in 0 until matrix.size) {
            for (x in 0 until matrix.size) {
                if (!matrix[x, y]) continue
                for (dy in 0 until PROBE_SCALE) {
                    val row = (y * PROBE_SCALE + dy) * side + x * PROBE_SCALE
                    for (dx in 0 until PROBE_SCALE) pixels[row + dx] = foreground
                }
            }
        }
        if (hasLogo) {
            val half = (matrix.dataSize * QrLogoGeometry.PLATE_FRACTION * PROBE_SCALE / 2f).roundToInt()
            val center = side / 2
            for (y in max(0, center - half) until min(side, center + half)) {
                for (x in max(0, center - half) until min(side, center + half)) {
                    pixels[y * side + x] = background
                }
            }
        }
        return pixels
    }

    companion object {
        private const val PROBE_SCALE = 5
        private const val POOR_CONTRAST = 2.0
        private const val GOOD_CONTRAST = 3.0

        /** WCAG contrast ratio between two ARGB colours (alpha is ignored). */
        fun contrastRatio(first: Int, second: Int): Double {
            val a = luminance(first)
            val b = luminance(second)
            return (max(a, b) + 0.05) / (min(a, b) + 0.05)
        }

        fun luminance(color: Int): Double {
            fun channel(value: Int): Double {
                val srgb = value / 255.0
                return if (srgb <= 0.03928) srgb / 12.92 else ((srgb + 0.055) / 1.055).pow(2.4)
            }
            val red = channel((color shr 16) and 0xFF)
            val green = channel((color shr 8) and 0xFF)
            val blue = channel(color and 0xFF)
            return 0.2126 * red + 0.7152 * green + 0.0722 * blue
        }
    }
}
