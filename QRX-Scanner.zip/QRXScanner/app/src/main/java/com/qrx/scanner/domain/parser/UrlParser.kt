package com.qrx.scanner.domain.parser

/** Minimal RFC 3986 style split of a URL into the pieces the security analyzer cares about. */
data class UrlParts(
    val scheme: String,
    val userInfo: String?,
    val host: String,
    val port: Int?,
    val path: String,
    val query: String?,
    val fragment: String?,
    val hasAuthority: Boolean,
)

object UrlParser {

    private val SCHEME = Regex("^[a-z][a-z0-9+.-]*$")

    fun parse(url: String): UrlParts? {
        val trimmed = url.trim()
        val schemeEnd = trimmed.indexOf(':')
        if (schemeEnd <= 0) return null
        val scheme = trimmed.substring(0, schemeEnd).lowercase()
        if (!SCHEME.matches(scheme)) return null

        var rest = trimmed.substring(schemeEnd + 1)
        var fragment: String? = null
        val fragmentIndex = rest.indexOf('#')
        if (fragmentIndex >= 0) {
            fragment = rest.substring(fragmentIndex + 1)
            rest = rest.substring(0, fragmentIndex)
        }
        var query: String? = null
        val queryIndex = rest.indexOf('?')
        if (queryIndex >= 0) {
            query = rest.substring(queryIndex + 1)
            rest = rest.substring(0, queryIndex)
        }

        if (!rest.startsWith("//")) {
            return UrlParts(scheme, null, "", null, rest, query, fragment, hasAuthority = false)
        }

        val authorityEnd = rest.indexOf('/', 2).let { if (it < 0) rest.length else it }
        val authority = rest.substring(2, authorityEnd)
        val path = rest.substring(authorityEnd)

        val at = authority.lastIndexOf('@')
        val userInfo = if (at >= 0) authority.substring(0, at) else null
        val hostAndPort = authority.substring(at + 1)

        val host: String
        var port: Int? = null
        if (hostAndPort.startsWith("[")) {
            val close = hostAndPort.indexOf(']')
            if (close < 0) {
                host = hostAndPort
            } else {
                host = hostAndPort.substring(0, close + 1)
                port = hostAndPort.substring(close + 1).removePrefix(":").toIntOrNull()
            }
        } else {
            val colon = hostAndPort.lastIndexOf(':')
            if (colon >= 0) {
                host = hostAndPort.substring(0, colon)
                port = hostAndPort.substring(colon + 1).toIntOrNull()
            } else {
                host = hostAndPort
            }
        }
        return UrlParts(scheme, userInfo, host.lowercase(), port, path, query, fragment, hasAuthority = true)
    }
}
