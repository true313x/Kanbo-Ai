package com.qrx.scanner.core.locale

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import java.util.Locale

enum class AppLanguage(val tag: String) {
    ENGLISH("en"),
    ARABIC("ar"),
}

/**
 * Per-app language through AppCompat. AppCompat persists the choice itself
 * (AppLocalesMetadataHolderService on Android 12 and below, the system on 13+), so it is not stored in DataStore.
 */
object LanguageManager {

    fun current(): AppLanguage {
        val locales = AppCompatDelegate.getApplicationLocales()
        val language = if (locales.isEmpty) Locale.getDefault().language else locales[0]?.language
        return if (language == AppLanguage.ARABIC.tag) AppLanguage.ARABIC else AppLanguage.ENGLISH
    }

    /** Recreates the activity so every string and the layout direction switch immediately. */
    fun apply(language: AppLanguage) {
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(language.tag))
    }
}
