package com.qrx.scanner.presentation.document

import androidx.annotation.StringRes
import com.qrx.scanner.R

class DocumentSection(@StringRes val title: Int, @StringRes val body: Int)

enum class DocumentKind(
    @StringRes val titleRes: Int,
    val sections: List<DocumentSection>,
) {
    PRIVACY_INFO(
        R.string.settings_privacy_info,
        listOf(
            DocumentSection(R.string.privacy_info_local_title, R.string.privacy_info_local_body),
            DocumentSection(R.string.privacy_info_permissions_title, R.string.privacy_info_permissions_body),
            DocumentSection(R.string.privacy_info_untrusted_title, R.string.privacy_info_untrusted_body),
            DocumentSection(R.string.privacy_info_network_title, R.string.privacy_info_network_body),
        ),
    ),
    PRIVACY_POLICY(
        R.string.settings_privacy_policy,
        listOf(
            DocumentSection(R.string.policy_collect_title, R.string.policy_collect_body),
            DocumentSection(R.string.policy_storage_title, R.string.policy_storage_body),
            DocumentSection(R.string.policy_permissions_title, R.string.policy_permissions_body),
            DocumentSection(R.string.policy_sharing_title, R.string.policy_sharing_body),
            DocumentSection(R.string.policy_control_title, R.string.policy_control_body),
            DocumentSection(R.string.policy_changes_title, R.string.policy_changes_body),
        ),
    ),
    ABOUT(
        R.string.settings_about,
        listOf(
            DocumentSection(R.string.about_what_title, R.string.about_what_body),
            DocumentSection(R.string.about_how_title, R.string.about_how_body),
            DocumentSection(R.string.about_formats_title, R.string.about_formats_body),
        ),
    ),
    LICENSES(R.string.settings_licenses, emptyList()),
    ;

    companion object {
        fun fromName(name: String): DocumentKind = entries.firstOrNull { it.name == name } ?: ABOUT
    }
}
