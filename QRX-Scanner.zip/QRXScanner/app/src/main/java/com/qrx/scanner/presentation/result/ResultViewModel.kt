package com.qrx.scanner.presentation.result

import android.graphics.Bitmap
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.toRoute
import com.qrx.scanner.domain.model.AppSettings
import com.qrx.scanner.domain.model.CodeFormat
import com.qrx.scanner.domain.model.ParsedContent
import com.qrx.scanner.domain.model.ScanRecord
import com.qrx.scanner.domain.model.ScanSource
import com.qrx.scanner.domain.parser.ContentParser
import com.qrx.scanner.domain.repository.HistoryRepository
import com.qrx.scanner.domain.repository.SettingsRepository
import com.qrx.scanner.domain.security.UrlSecurityAnalyzer
import com.qrx.scanner.domain.security.UrlSecurityReport
import com.qrx.scanner.domain.usecase.ProcessScanUseCase
import com.qrx.scanner.domain.usecase.SetFavoriteUseCase
import com.qrx.scanner.navigation.ResultRoute
import com.qrx.scanner.scanner.CodePreviewRenderer
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ResultUiState(
    val isLoading: Boolean = true,
    val notFound: Boolean = false,
    val record: ScanRecord? = null,
    val content: ParsedContent? = null,
    val urlReport: UrlSecurityReport? = null,
    val preview: Bitmap? = null,
    val settings: AppSettings = AppSettings(),
)

sealed interface ResultEvent {
    /** The user enabled "auto-open links" and this fresh scan is a clean https link. */
    data class AutoOpenUrl(val url: String) : ResultEvent
    data object Deleted : ResultEvent
}

@HiltViewModel
class ResultViewModel @Inject constructor(
    private val savedStateHandle: SavedStateHandle,
    private val history: HistoryRepository,
    private val settingsRepository: SettingsRepository,
    private val processScan: ProcessScanUseCase,
    private val setFavorite: SetFavoriteUseCase,
    private val urlAnalyzer: UrlSecurityAnalyzer,
    private val previewRenderer: CodePreviewRenderer,
) : ViewModel() {

    private val route: ResultRoute = savedStateHandle.toRoute<ResultRoute>()

    private val _state = MutableStateFlow(ResultUiState())
    val state: StateFlow<ResultUiState> = _state.asStateFlow()

    private val eventChannel = Channel<ResultEvent>(Channel.BUFFERED)
    val events: Flow<ResultEvent> = eventChannel.receiveAsFlow()

    private var observeJob: Job? = null

    init {
        viewModelScope.launch {
            settingsRepository.settings.collect { settings -> _state.update { it.copy(settings = settings) } }
        }
        viewModelScope.launch { load() }
    }

    private suspend fun load() {
        val knownId = savedStateHandle.get<Long>(KEY_PERSISTED_ID) ?: route.historyId.takeIf { it > 0L }
        if (knownId != null) {
            val record = history.getById(knownId)
            if (record == null) {
                _state.update { it.copy(isLoading = false, notFound = true) }
                return
            }
            show(record, ContentParser.parse(record.rawValue, record.format))
            observe(knownId)
            return
        }

        val format = CodeFormat.fromName(route.format) ?: CodeFormat.QR_CODE
        val source = ScanSource.entries.firstOrNull { it.name == route.source } ?: ScanSource.CAMERA
        val outcome = processScan(route.rawValue, format, source)
        if (outcome.record.isPersisted) {
            savedStateHandle[KEY_PERSISTED_ID] = outcome.record.id
            observe(outcome.record.id)
        }
        show(outcome.record, outcome.content)
        maybeAutoOpen(outcome.content)
    }

    private suspend fun show(record: ScanRecord, content: ParsedContent) {
        val report = (content as? ParsedContent.Url)?.let { urlAnalyzer.analyze(it.url) }
        _state.update {
            it.copy(isLoading = false, notFound = false, record = record, content = content, urlReport = report)
        }
        val preview = previewRenderer.render(record.rawValue, record.format)
        _state.update { it.copy(preview = preview) }
    }

    private fun observe(id: Long) {
        observeJob?.cancel()
        observeJob = viewModelScope.launch {
            history.observeById(id).collect { stored ->
                if (stored != null) _state.update { it.copy(record = stored) }
            }
        }
    }

    private suspend fun maybeAutoOpen(content: ParsedContent) {
        if (!route.fresh || savedStateHandle.get<Boolean>(KEY_AUTO_OPEN_HANDLED) == true) return
        savedStateHandle[KEY_AUTO_OPEN_HANDLED] = true
        if (content !is ParsedContent.Url) return
        if (!settingsRepository.settings.first().autoOpenLinks) return
        if (urlAnalyzer.analyze(content.url).canAutoOpen) {
            eventChannel.send(ResultEvent.AutoOpenUrl(content.url))
        }
    }

    fun toggleFavorite() {
        val record = _state.value.record ?: return
        viewModelScope.launch {
            val updated = setFavorite(record, !record.isFavorite)
            if (updated.isPersisted && !record.isPersisted) {
                savedStateHandle[KEY_PERSISTED_ID] = updated.id
                observe(updated.id)
            }
            _state.update { it.copy(record = updated) }
        }
    }

    fun delete() {
        val record = _state.value.record ?: return
        viewModelScope.launch {
            if (record.isPersisted) history.delete(record.id)
            eventChannel.send(ResultEvent.Deleted)
        }
    }

    private companion object {
        const val KEY_PERSISTED_ID = "persisted_id"
        const val KEY_AUTO_OPEN_HANDLED = "auto_open_handled"
    }
}
