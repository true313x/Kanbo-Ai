package com.qrx.scanner.core.di

import com.qrx.scanner.data.repository.HistoryRepositoryImpl
import com.qrx.scanner.data.settings.SettingsRepositoryImpl
import com.qrx.scanner.domain.repository.HistoryRepository
import com.qrx.scanner.domain.repository.SettingsRepository
import com.qrx.scanner.generator.AndroidQrExporter
import com.qrx.scanner.generator.BitmapLogoLoader
import com.qrx.scanner.generator.LogoLoader
import com.qrx.scanner.generator.QrCodeEncoder
import com.qrx.scanner.generator.QrExporter
import com.qrx.scanner.generator.QrGenerator
import com.qrx.scanner.scanner.ImageCodeScanner
import com.qrx.scanner.scanner.MlKitImageCodeScanner
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
abstract class BindingsModule {

    @Binds
    abstract fun bindHistoryRepository(impl: HistoryRepositoryImpl): HistoryRepository

    @Binds
    abstract fun bindSettingsRepository(impl: SettingsRepositoryImpl): SettingsRepository

    @Binds
    abstract fun bindQrGenerator(impl: QrCodeEncoder): QrGenerator

    @Binds
    abstract fun bindQrExporter(impl: AndroidQrExporter): QrExporter

    @Binds
    abstract fun bindLogoLoader(impl: BitmapLogoLoader): LogoLoader

    @Binds
    abstract fun bindImageCodeScanner(impl: MlKitImageCodeScanner): ImageCodeScanner
}
