package com.qrx.scanner.domain.model

enum class ThemeMode { SYSTEM, LIGHT, DARK }

enum class ScanMode { AUTO, QR_ONLY, BARCODE_ONLY }

enum class SearchEngine { GOOGLE, BING, DUCKDUCKGO }

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val scanSound: Boolean = true,
    val haptics: Boolean = true,
    val autoOpenLinks: Boolean = false,
    val autoSaveHistory: Boolean = true,
    val scanMode: ScanMode = ScanMode.AUTO,
    val searchEngine: SearchEngine = SearchEngine.GOOGLE,
)
