package com.qrx.scanner.presentation.generator

import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SaveAlt
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.qrx.scanner.R
import com.qrx.scanner.domain.model.WifiSecurity
import com.qrx.scanner.generator.ErrorCorrection
import com.qrx.scanner.generator.InputError
import com.qrx.scanner.generator.QrStyle
import com.qrx.scanner.generator.Readability
import com.qrx.scanner.ui.components.ActionTile
import com.qrx.scanner.ui.components.ContentMaxWidth
import com.qrx.scanner.ui.components.LocalContentBottomPadding
import com.qrx.scanner.ui.components.ObserveEvents
import com.qrx.scanner.ui.components.PrimaryButton
import com.qrx.scanner.ui.components.ScreenHeader
import com.qrx.scanner.ui.components.SecondaryButton
import com.qrx.scanner.ui.components.SegmentOption
import com.qrx.scanner.ui.components.SegmentedControl
import com.qrx.scanner.ui.components.labelRes
import com.qrx.scanner.ui.components.screenInsets
import com.qrx.scanner.ui.theme.QrxTheme
import com.qrx.scanner.util.ActionResult
import com.qrx.scanner.util.ExternalActions
import kotlinx.coroutines.launch

private val SelectableWifiSecurity = listOf(WifiSecurity.WPA, WifiSecurity.WPA3, WifiSecurity.WEP, WifiSecurity.OPEN)

@Composable
fun GeneratorScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: GeneratorViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsStateWithLifecycle()
    val actions = remember(context) { ExternalActions(context) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    fun say(message: Int) {
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(context.getString(message))
        }
    }

    val pickLogo = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.setLogo(uri)
    }
    val createDocument = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) viewModel.saveToDocument(uri)
    }

    ObserveEvents(viewModel.events) { event ->
        when (event) {
            GeneratorEvent.Saved -> say(R.string.generator_saved)
            GeneratorEvent.ExportFailed -> say(R.string.generator_export_failed)
            GeneratorEvent.LogoFailed -> say(R.string.generator_logo_failed)
            is GeneratorEvent.ShareReady -> if (actions.shareImage(event.uri) == ActionResult.NO_APP) say(R.string.result_no_app)
            is GeneratorEvent.CopyReady -> if (actions.copyImage(context.getString(R.string.generator_clipboard_label), event.uri)) {
                say(R.string.generator_image_copied)
            }
        }
    }

    val hasCode = state.matrix != null
    val save = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            viewModel.saveToGallery()
        } else {
            createDocument.launch(viewModel.suggestedFileName())
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().screenInsets()) {
            ScreenHeader(title = stringResource(state.type.labelRes), onBack = onBack)
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                    modifier = Modifier
                        .widthIn(max = ContentMaxWidth)
                        .fillMaxSize()
                        .imePadding()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp)
                        .padding(top = 4.dp, bottom = LocalContentBottomPadding.current + 16.dp),
                ) {
                    FormSection(state, viewModel)
                    PreviewSection(state)
                    CustomizeSection(
                        state = state,
                        viewModel = viewModel,
                        onPickLogo = {
                            pickLogo.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                    )
                    PrimaryButton(
                        text = stringResource(R.string.generator_save_image),
                        icon = Icons.Rounded.SaveAlt,
                        enabled = hasCode,
                        onClick = save,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        ActionTile(
                            icon = Icons.Rounded.Share,
                            label = stringResource(R.string.action_share),
                            enabled = hasCode,
                            onClick = viewModel::share,
                            modifier = Modifier.weight(1f),
                        )
                        ActionTile(
                            icon = Icons.Rounded.ContentCopy,
                            label = stringResource(R.string.action_copy),
                            enabled = hasCode,
                            onClick = viewModel::copyImage,
                            modifier = Modifier.weight(1f),
                        )
                        ActionTile(
                            icon = Icons.Rounded.Refresh,
                            label = stringResource(R.string.generator_regenerate),
                            enabled = hasCode,
                            onClick = viewModel::regenerateWithAnimation,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }
        }
        SnackbarHost(
            hostState = snackbar,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = LocalContentBottomPadding.current)
                .padding(horizontal = 16.dp),
        )
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(18.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
            content()
        }
    }
}

@Composable
private fun FormSection(state: GeneratorUiState, viewModel: GeneratorViewModel) {
    SectionCard(title = stringResource(R.string.generator_section_details)) {
        for (field in state.type.fields) {
            OutlinedTextField(
                value = state.fields[field].orEmpty(),
                onValueChange = { viewModel.setField(field, it) },
                label = { Text(stringResource(field.labelRes)) },
                singleLine = !field.multiline,
                minLines = if (field.multiline) 3 else 1,
                shape = MaterialTheme.shapes.medium,
                visualTransformation = if (field.isSecret) PasswordVisualTransformation() else VisualTransformation.None,
                keyboardOptions = field.keyboardOptions.let { options ->
                    if (field.multiline) options else options.copy(imeAction = ImeAction.Next)
                },
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (state.type == GeneratorType.WIFI) {
            Text(
                text = stringResource(R.string.field_security),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            SegmentedControl(
                options = SelectableWifiSecurity.map { SegmentOption(it, stringResource(it.labelRes)) },
                selected = state.wifiSecurity,
                onSelect = viewModel::setWifiSecurity,
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.medium)
                    .selectable(
                        selected = state.wifiHidden,
                        role = Role.Switch,
                        onClick = { viewModel.setWifiHidden(!state.wifiHidden) },
                    ),
            ) {
                Text(
                    text = stringResource(R.string.field_hidden_network),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.weight(1f),
                )
                Switch(checked = state.wifiHidden, onCheckedChange = null)
            }
        }
    }
}

@Composable
private fun PreviewSection(state: GeneratorUiState) {
    SectionCard(title = stringResource(R.string.generator_section_preview)) {
        val matrix = state.matrix
        if (matrix != null) {
            val scale = remember { Animatable(1f) }
            LaunchedEffect(state.generation) {
                scale.snapTo(0.9f)
                scale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow))
            }
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                QrCodeView(
                    matrix = matrix,
                    foreground = Color(state.foreground),
                    background = Color(state.background),
                    logo = state.logo,
                    description = stringResource(R.string.generator_preview_description),
                    modifier = Modifier
                        .widthIn(max = 280.dp)
                        .graphicsLayer {
                            scaleX = scale.value
                            scaleY = scale.value
                        }
                        .clip(MaterialTheme.shapes.medium)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium),
                )
            }
            state.readability?.let { ReadabilityBadge(it) }
        } else {
            PreviewPlaceholder(state.error)
        }
    }
}

@Composable
private fun PreviewPlaceholder(error: InputError?) {
    val colors = QrxTheme.colors
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp),
    ) {
        Icon(
            imageVector = if (error == null) Icons.Rounded.QrCode2 else Icons.Rounded.Error,
            contentDescription = null,
            tint = if (error == null) MaterialTheme.colorScheme.onSurfaceVariant else colors.danger,
            modifier = Modifier.size(48.dp),
        )
        Text(
            text = stringResource(error?.messageRes ?: R.string.generator_placeholder),
            style = MaterialTheme.typography.bodyMedium,
            color = if (error == null) MaterialTheme.colorScheme.onSurfaceVariant else colors.danger,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun ReadabilityBadge(readability: Readability) {
    val colors = QrxTheme.colors
    val (icon, tint, container, label, hint) = when (readability) {
        Readability.GOOD -> BadgeSpec(Icons.Rounded.CheckCircle, colors.success, colors.successContainer, R.string.readability_good, R.string.readability_good_hint)
        Readability.RISKY -> BadgeSpec(Icons.Rounded.Warning, colors.warning, colors.warningContainer, R.string.readability_risky, R.string.readability_risky_hint)
        Readability.POOR -> BadgeSpec(Icons.Rounded.Error, colors.danger, colors.dangerContainer, R.string.readability_poor, R.string.readability_poor_hint)
    }
    Row(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .background(container)
            .padding(12.dp),
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(text = stringResource(label), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
            Text(text = stringResource(hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

private data class BadgeSpec(
    val icon: ImageVector,
    val tint: Color,
    val container: Color,
    val label: Int,
    val hint: Int,
)

@Composable
private fun CustomizeSection(state: GeneratorUiState, viewModel: GeneratorViewModel, onPickLogo: () -> Unit) {
    SectionCard(title = stringResource(R.string.generator_section_style)) {
        SwatchRow(
            title = stringResource(R.string.generator_color_foreground),
            options = QrPalette.foregrounds,
            selectedIndex = state.foregroundIndex,
            onSelect = viewModel::setForeground,
        )
        SwatchRow(
            title = stringResource(R.string.generator_color_background),
            options = QrPalette.backgrounds,
            selectedIndex = state.backgroundIndex,
            onSelect = viewModel::setBackground,
        )
        Text(
            text = stringResource(R.string.generator_size),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        SegmentedControl(
            options = QrStyle.SIZES_PX.map { SegmentOption(it, stringResource(R.string.size_px_format, it)) },
            selected = state.sizePx,
            onSelect = viewModel::setSize,
        )
        Text(
            text = stringResource(R.string.generator_error_correction),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        SegmentedControl(
            options = ErrorCorrection.entries.map { SegmentOption(it, stringResource(it.labelRes)) },
            selected = state.effectiveErrorCorrection,
            onSelect = { if (state.logo == null) viewModel.setErrorCorrection(it) },
        )
        if (state.logo != null) {
            Text(
                text = stringResource(R.string.generator_logo_forces_high),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (state.logo == null) {
            SecondaryButton(
                text = stringResource(R.string.generator_add_logo),
                icon = Icons.Rounded.AddPhotoAlternate,
                onClick = onPickLogo,
            )
        } else {
            SecondaryButton(
                text = stringResource(R.string.generator_remove_logo),
                icon = Icons.Rounded.Delete,
                onClick = viewModel::removeLogo,
            )
        }
    }
}

@Composable
private fun SwatchRow(
    title: String,
    options: List<QrColorOption>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(text = title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.selectableGroup()) {
            options.forEachIndexed { index, option ->
                val selected = index == selectedIndex
                val name = stringResource(option.nameRes)
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .border(
                            width = if (selected) 3.dp else 1.dp,
                            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                            shape = CircleShape,
                        )
                        .padding(5.dp)
                        .clip(CircleShape)
                        .background(Color(option.argb))
                        .selectable(selected = selected, role = Role.RadioButton, onClick = { onSelect(index) })
                        .semantics { contentDescription = name },
                )
            }
        }
    }
}

private val ErrorCorrection.labelRes: Int
    get() = when (this) {
        ErrorCorrection.LOW -> R.string.ec_low
        ErrorCorrection.MEDIUM -> R.string.ec_medium
        ErrorCorrection.QUARTILE -> R.string.ec_quartile
        ErrorCorrection.HIGH -> R.string.ec_high
    }

private val InputError.messageRes: Int
    get() = when (this) {
        InputError.EMPTY -> R.string.generator_placeholder
        InputError.INVALID_URL -> R.string.error_invalid_url
        InputError.INVALID_PHONE -> R.string.error_invalid_phone
        InputError.INVALID_EMAIL -> R.string.error_invalid_email
        InputError.INVALID_COORDINATES -> R.string.error_invalid_coordinates
        InputError.MISSING_SSID -> R.string.error_missing_ssid
        InputError.MISSING_PASSWORD -> R.string.error_missing_password
        InputError.MISSING_NAME -> R.string.error_missing_name
        InputError.TOO_LONG -> R.string.error_too_long
    }
