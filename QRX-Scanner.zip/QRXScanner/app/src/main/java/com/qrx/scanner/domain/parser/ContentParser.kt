package com.qrx.scanner.domain.parser

import com.qrx.scanner.domain.model.CodeFormat
import com.qrx.scanner.domain.model.ParsedContent
import com.qrx.scanner.domain.model.WifiSecurity

/**
 * Detects what a raw scanned string represents. Pure Kotlin: no Android types, no side effects.
 * The result is only a description; the app never acts on it without the user's explicit request.
 */
object ContentParser {

    private val DANGEROUS_SCHEMES = listOf(
        "javascript:", "intent:", "data:", "file:", "vbscript:", "content:", "blob:", "about:",
    )
    private val SCHEME_WITH_SLASHES = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://\\S+$")

    fun parse(rawValue: String, format: CodeFormat): ParsedContent {
        val value = rawValue.trim()
        if (value.isEmpty()) return ParsedContent.Text(rawValue)
        if (format.isOneDimensional) return ParsedContent.Barcode(value)
        return parseStructured(value) ?: ParsedContent.Text(rawValue)
    }

    private fun parseStructured(value: String): ParsedContent? = when {
        value.startsWith("WIFI:", ignoreCase = true) -> parseWifi(value)
        value.startsWith("BEGIN:VCARD", ignoreCase = true) -> parseVCard(value)
        value.startsWith("MECARD:", ignoreCase = true) -> parseMeCard(value)
        value.startsWith("tel:", ignoreCase = true) -> parsePhone(value)
        value.startsWith("mailto:", ignoreCase = true) -> parseMailto(value)
        value.startsWith("MATMSG:", ignoreCase = true) -> parseMatmsg(value)
        value.startsWith("smsto:", ignoreCase = true) || value.startsWith("mmsto:", ignoreCase = true) ->
            parseSmsTo(value)
        value.startsWith("sms:", ignoreCase = true) || value.startsWith("mms:", ignoreCase = true) ->
            parseSms(value)
        value.startsWith("geo:", ignoreCase = true) -> parseGeo(value)
        else -> parseUrl(value)
    }

    // region URL

    private fun parseUrl(value: String): ParsedContent? {
        val lower = value.lowercase()
        val hasWhitespace = value.any { it.isWhitespace() }
        return when {
            DANGEROUS_SCHEMES.any { lower.startsWith(it) } -> ParsedContent.Url(value)
            hasWhitespace -> null
            lower.startsWith("http://") || lower.startsWith("https://") -> ParsedContent.Url(value)
            lower.startsWith("www.") && lower.indexOf('.', 4) > 4 -> ParsedContent.Url("https://$value")
            SCHEME_WITH_SLASHES.matches(value) -> ParsedContent.Url(value)
            else -> null
        }
    }

    // endregion

    // region Wi-Fi

    private fun parseWifi(value: String): ParsedContent? {
        val fields = parseDelimited(value.substring("WIFI:".length))
        val ssid = fields.firstValue("S")?.takeIf { it.isNotEmpty() } ?: return null
        val password = fields.firstValue("P")?.takeIf { it.isNotEmpty() }
        val type = fields.firstValue("T")?.trim()?.uppercase().orEmpty()
        val security = when {
            type.isEmpty() -> if (password == null) WifiSecurity.OPEN else WifiSecurity.WPA
            type == "NOPASS" -> WifiSecurity.OPEN
            type == "WEP" -> WifiSecurity.WEP
            type == "SAE" || type == "WPA3" -> WifiSecurity.WPA3
            type.contains("EAP") -> WifiSecurity.EAP
            else -> WifiSecurity.WPA
        }
        val hidden = fields.firstValue("H")?.equals("true", ignoreCase = true) == true
        return ParsedContent.Wifi(
            ssid = ssid,
            password = if (security == WifiSecurity.OPEN) null else password,
            security = security,
            hidden = hidden,
        )
    }

    // endregion

    // region Contacts

    private fun parseVCard(value: String): ParsedContent? {
        val unfolded = value
            .replace("\r\n", "\n")
            .replace('\r', '\n')
            .replace(Regex("\n[ \t]"), "")
        var name: String? = null
        var structuredName: String? = null
        var organization: String? = null
        var title: String? = null
        var address: String? = null
        var website: String? = null
        var note: String? = null
        val phones = mutableListOf<String>()
        val emails = mutableListOf<String>()

        for (line in unfolded.lineSequence()) {
            val separator = line.indexOf(':')
            if (separator <= 0) continue
            val property = line.substring(0, separator).substringBefore(';').substringAfterLast('.').uppercase()
            val raw = line.substring(separator + 1)
            val text = unescapeVCard(raw).trim()
            if (text.isEmpty()) continue
            when (property) {
                "FN" -> if (name == null) name = text
                "N" -> if (structuredName == null) {
                    val parts = splitUnescaped(raw, ';').map { unescapeVCard(it).trim() }
                    val given = parts.getOrNull(1).orEmpty()
                    val family = parts.getOrNull(0).orEmpty()
                    structuredName = listOf(given, family).filter { it.isNotEmpty() }.joinToString(" ").ifEmpty { null }
                }
                "ORG" -> if (organization == null) {
                    organization = splitUnescaped(raw, ';').map { unescapeVCard(it).trim() }.filter { it.isNotEmpty() }
                        .joinToString(", ").ifEmpty { null }
                }
                "TITLE" -> if (title == null) title = text
                "TEL" -> phones += text
                "EMAIL" -> emails += text
                "URL" -> if (website == null) website = text
                "NOTE" -> if (note == null) note = text
                "ADR" -> if (address == null) {
                    address = splitUnescaped(raw, ';').map { unescapeVCard(it).trim() }.filter { it.isNotEmpty() }
                        .joinToString(", ").ifEmpty { null }
                }
            }
        }
        val contact = ParsedContent.Contact(
            name = name ?: structuredName,
            phones = phones,
            emails = emails,
            organization = organization,
            jobTitle = title,
            address = address,
            website = website,
            note = note,
        )
        return contact.takeIf { it.displayValue.isNotEmpty() }
    }

    private fun parseMeCard(value: String): ParsedContent? {
        val fields = parseDelimited(value.substring("MECARD:".length))
        val rawName = fields.firstValue("N")?.trim()?.takeIf { it.isNotEmpty() }
        val name = rawName?.let {
            if (it.contains(',')) "${it.substringAfter(',').trim()} ${it.substringBefore(',').trim()}".trim() else it
        }
        val contact = ParsedContent.Contact(
            name = name,
            phones = fields.allValues("TEL").filter { it.isNotBlank() },
            emails = fields.allValues("EMAIL").filter { it.isNotBlank() },
            organization = fields.firstValue("ORG")?.takeIf { it.isNotBlank() },
            jobTitle = null,
            address = fields.firstValue("ADR")?.takeIf { it.isNotBlank() },
            website = fields.firstValue("URL")?.takeIf { it.isNotBlank() },
            note = fields.firstValue("NOTE")?.takeIf { it.isNotBlank() },
        )
        return contact.takeIf { it.displayValue.isNotEmpty() }
    }

    /** Splits on [separator] but not on backslash-escaped occurrences; escapes are kept for [unescapeVCard]. */
    private fun splitUnescaped(value: String, separator: Char): List<String> {
        val parts = mutableListOf<String>()
        val current = StringBuilder()
        var index = 0
        while (index < value.length) {
            val char = value[index]
            if (char == '\\' && index + 1 < value.length) {
                current.append(char).append(value[index + 1])
                index += 2
            } else if (char == separator) {
                parts += current.toString()
                current.clear()
                index++
            } else {
                current.append(char)
                index++
            }
        }
        parts += current.toString()
        return parts
    }

    private fun unescapeVCard(value: String): String {
        if (value.indexOf('\\') < 0) return value
        val out = StringBuilder(value.length)
        var index = 0
        while (index < value.length) {
            val char = value[index]
            if (char == '\\' && index + 1 < value.length) {
                val next = value[index + 1]
                out.append(if (next == 'n' || next == 'N') '\n' else next)
                index += 2
            } else {
                out.append(char)
                index++
            }
        }
        return out.toString()
    }

    // endregion

    // region tel / mail / sms / geo

    private fun parsePhone(value: String): ParsedContent? {
        val number = TextCodec.percentDecode(value.substring("tel:".length)).trim()
        return if (number.isEmpty()) null else ParsedContent.Phone(number)
    }

    private fun parseMailto(value: String): ParsedContent? {
        val rest = value.substring("mailto:".length)
        val address = TextCodec.percentDecode(rest.substringBefore('?')).trim()
        if (address.isEmpty()) return null
        val query = TextCodec.parseQuery(if (rest.contains('?')) rest.substringAfter('?') else null)
        return ParsedContent.Email(
            address = address,
            subject = query["subject"]?.takeIf { it.isNotEmpty() },
            body = query["body"]?.takeIf { it.isNotEmpty() },
        )
    }

    private fun parseMatmsg(value: String): ParsedContent? {
        val fields = parseDelimited(value.substring("MATMSG:".length))
        val address = fields.firstValue("TO")?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        return ParsedContent.Email(
            address = address,
            subject = fields.firstValue("SUB")?.takeIf { it.isNotEmpty() },
            body = fields.firstValue("BODY")?.takeIf { it.isNotEmpty() },
        )
    }

    private fun parseSms(value: String): ParsedContent? {
        val rest = value.substringAfter(':')
        val number = TextCodec.percentDecode(rest.substringBefore('?').substringBefore(';')).trim()
        if (number.isEmpty()) return null
        val query = TextCodec.parseQuery(if (rest.contains('?')) rest.substringAfter('?') else null)
        return ParsedContent.Sms(number, query["body"]?.takeIf { it.isNotEmpty() })
    }

    private fun parseSmsTo(value: String): ParsedContent? {
        val rest = value.substringAfter(':')
        val number = TextCodec.percentDecode(rest.substringBefore(':')).trim()
        if (number.isEmpty()) return null
        val message = if (rest.contains(':')) rest.substringAfter(':') else null
        return ParsedContent.Sms(number, message?.takeIf { it.isNotEmpty() })
    }

    private fun parseGeo(value: String): ParsedContent? {
        val rest = value.substring("geo:".length)
        val coordinates = rest.substringBefore('?').substringBefore(';').split(',')
        val latitude = coordinates.getOrNull(0)?.trim()?.toDoubleOrNull() ?: return null
        val longitude = coordinates.getOrNull(1)?.trim()?.toDoubleOrNull() ?: return null
        if (latitude !in -90.0..90.0 || longitude !in -180.0..180.0) return null
        val query = TextCodec.parseQuery(if (rest.contains('?')) rest.substringAfter('?') else null)
        return ParsedContent.Geo(latitude, longitude, query["q"]?.takeIf { it.isNotEmpty() })
    }

    // endregion

    // region `KEY:value;KEY:value;;` payloads (Wi-Fi, MECARD, MATMSG)

    private fun parseDelimited(body: String): List<Pair<String, String>> {
        val result = mutableListOf<Pair<String, String>>()
        val key = StringBuilder()
        val value = StringBuilder()
        var inValue = false
        var escaped = false

        fun flush() {
            if (key.isNotEmpty() || value.isNotEmpty()) {
                result += key.toString().trim().uppercase() to value.toString()
            }
            key.clear()
            value.clear()
            inValue = false
        }

        for (char in body) {
            when {
                escaped -> {
                    (if (inValue) value else key).append(char)
                    escaped = false
                }
                char == '\\' -> escaped = true
                char == ';' -> flush()
                char == ':' && !inValue -> inValue = true
                else -> (if (inValue) value else key).append(char)
            }
        }
        flush()
        return result
    }

    private fun List<Pair<String, String>>.firstValue(key: String): String? =
        firstOrNull { it.first == key }?.second

    private fun List<Pair<String, String>>.allValues(key: String): List<String> =
        filter { it.first == key }.map { it.second }

    // endregion
}
