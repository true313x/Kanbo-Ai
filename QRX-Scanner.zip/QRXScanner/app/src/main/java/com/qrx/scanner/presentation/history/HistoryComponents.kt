package com.qrx.scanner.presentation.history

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.qrx.scanner.R
import com.qrx.scanner.core.SystemTimeProvider
import com.qrx.scanner.domain.model.ScanRecord
import com.qrx.scanner.ui.components.SwipeableRow
import com.qrx.scanner.ui.components.icon
import com.qrx.scanner.ui.components.labelRes
import com.qrx.scanner.ui.theme.QrxTheme
import com.qrx.scanner.util.HistoryDateFormatter
import java.util.Locale

/** A history row with the two swipe actions: right = favorite toggle, left = delete. */
@Composable
fun SwipeableHistoryItem(
    record: ScanRecord,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = QrxTheme.colors
    val favoriteLabel = stringResource(if (record.isFavorite) R.string.action_unfavorite else R.string.action_favorite)
    val deleteLabel = stringResource(R.string.action_delete)
    SwipeableRow(
        rightActionLabel = favoriteLabel,
        leftActionLabel = deleteLabel,
        onSwipeRight = onToggleFavorite,
        onSwipeLeft = onDelete,
        rightBackground = {
            SwipeBackground(
                color = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                alignment = Alignment.CenterStart,
                icon = if (record.isFavorite) Icons.Rounded.StarBorder else Icons.Rounded.Star,
                label = favoriteLabel,
            )
        },
        leftBackground = {
            SwipeBackground(
                color = colors.dangerContainer,
                contentColor = colors.danger,
                alignment = Alignment.CenterEnd,
                icon = Icons.Rounded.Delete,
                label = deleteLabel,
            )
        },
        modifier = modifier,
    ) {
        HistoryItemCard(record = record, onClick = onClick)
    }
}

@Composable
private fun SwipeBackground(
    color: Color,
    contentColor: Color,
    alignment: Alignment,
    icon: ImageVector,
    label: String,
) {
    Box(
        contentAlignment = alignment,
        modifier = Modifier
            .fillMaxSize()
            .background(color)
            .padding(horizontal = 24.dp),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Icon(imageVector = icon, contentDescription = null, tint = contentColor)
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = contentColor)
        }
    }
}

@Composable
fun HistoryItemCard(record: ScanRecord, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val locale = LocalConfiguration.current.locales[0] ?: Locale.getDefault()
    val today = stringResource(R.string.date_today)
    val yesterday = stringResource(R.string.date_yesterday)
    val date = remember(record.createdAt, locale, today, yesterday) {
        HistoryDateFormatter.format(
            timestampMillis = record.createdAt,
            nowMillis = SystemTimeProvider.nowMillis(),
            locale = locale,
            todayLabel = today,
            yesterdayLabel = yesterday,
        )
    }
    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.large)
            .clickable(role = Role.Button, onClick = onClick),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.padding(14.dp),
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
            ) {
                Icon(
                    imageVector = record.type.icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(22.dp),
                )
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = record.displayValue,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = stringResource(R.string.type_and_format, stringResource(record.type.labelRes), record.format.displayName),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = date,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (record.isFavorite) {
                Icon(
                    imageVector = Icons.Rounded.Star,
                    contentDescription = stringResource(R.string.action_saved),
                    tint = QrxTheme.colors.warning,
                    modifier = Modifier.size(20.dp),
                )
            }
        }
    }
}
