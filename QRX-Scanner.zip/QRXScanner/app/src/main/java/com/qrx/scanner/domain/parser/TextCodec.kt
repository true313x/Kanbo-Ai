package com.qrx.scanner.domain.parser

import java.io.ByteArrayOutputStream

/** Small, dependency-free text helpers shared by the parser and the payload builder. */
object TextCodec {

    private const val UNRESERVED = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.~"

    fun percentEncode(value: String): String {
        val out = StringBuilder()
        for (byte in value.toByteArray(Charsets.UTF_8)) {
            val unsigned = byte.toInt() and 0xFF
            val char = unsigned.toChar()
            if (unsigned < 0x80 && UNRESERVED.indexOf(char) >= 0) {
                out.append(char)
            } else {
                out.append('%')
                out.append("0123456789ABCDEF"[unsigned shr 4])
                out.append("0123456789ABCDEF"[unsigned and 0x0F])
            }
        }
        return out.toString()
    }

    /** Decodes %XX sequences as UTF-8. A '+' is kept as is. Malformed sequences are kept literally. */
    fun percentDecode(value: String): String {
        if (value.indexOf('%') < 0) return value
        val bytes = ByteArrayOutputStream()
        var index = 0
        while (index < value.length) {
            val char = value[index]
            if (char == '%' && index + 2 < value.length && isHex(value[index + 1]) && isHex(value[index + 2])) {
                bytes.write(value.substring(index + 1, index + 3).toInt(16))
                index += 3
            } else {
                val codePoint = value.codePointAt(index)
                val chars = Character.toChars(codePoint)
                bytes.write(String(chars).toByteArray(Charsets.UTF_8))
                index += chars.size
            }
        }
        return String(bytes.toByteArray(), Charsets.UTF_8)
    }

    private fun isHex(char: Char): Boolean =
        char in '0'..'9' || char in 'a'..'f' || char in 'A'..'F'

    /** Parses `a=b&c=d` into a map with lower-cased keys and decoded values. */
    fun parseQuery(query: String?): Map<String, String> {
        if (query.isNullOrEmpty()) return emptyMap()
        val result = LinkedHashMap<String, String>()
        for (pair in query.split('&')) {
            if (pair.isEmpty()) continue
            val separator = pair.indexOf('=')
            val key = if (separator >= 0) pair.substring(0, separator) else pair
            val value = if (separator >= 0) pair.substring(separator + 1) else ""
            result.putIfAbsent(percentDecode(key).lowercase(), percentDecode(value))
        }
        return result
    }

    /** Converts Arabic-Indic and Persian digits (and decimal separators) to ASCII. */
    fun normalizeDigits(value: String): String {
        val out = StringBuilder(value.length)
        for (char in value) {
            out.append(
                when (char) {
                    in '\u0660'..'\u0669' -> '0' + (char - '\u0660')
                    in '\u06F0'..'\u06F9' -> '0' + (char - '\u06F0')
                    '\u066B' -> '.'
                    '\u066C' -> ','
                    else -> char
                },
            )
        }
        return out.toString()
    }
}
