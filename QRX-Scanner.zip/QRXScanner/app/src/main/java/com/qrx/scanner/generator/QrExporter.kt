package com.qrx.scanner.generator

import android.graphics.Bitmap
import android.net.Uri

sealed interface ExportResult {
    data class Success(val uri: Uri) : ExportResult
    data object Failure : ExportResult
}

/** Writes generated QR images to the gallery, to a user-chosen document, or to a shareable cache file. */
interface QrExporter {
    /** Android 10+ only: stores the image under Pictures/QRX without needing any permission. */
    suspend fun saveToGallery(matrix: QrMatrix, style: QrStyle, logo: Bitmap?, fileName: String): ExportResult

    /** Writes the image to a document the user picked (used before Android 10). */
    suspend fun saveToDocument(uri: Uri, matrix: QrMatrix, style: QrStyle, logo: Bitmap?): ExportResult

    /** Creates a content:// URI that other apps may read, for sharing. */
    suspend fun createShareUri(matrix: QrMatrix, style: QrStyle, logo: Bitmap?): ExportResult
}
