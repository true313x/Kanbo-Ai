package com.qrx.scanner.domain.usecase

import com.qrx.scanner.domain.model.ScanRecord
import com.qrx.scanner.domain.repository.HistoryRepository
import javax.inject.Inject

/** Marks a record as favorite. A record that was never persisted (auto-save off) is stored first. */
class SetFavoriteUseCase @Inject constructor(
    private val history: HistoryRepository,
) {
    suspend operator fun invoke(record: ScanRecord, favorite: Boolean): ScanRecord {
        if (record.isPersisted) {
            history.setFavorite(record.id, favorite)
            return record.copy(isFavorite = favorite)
        }
        val saved = record.copy(isFavorite = favorite)
        return saved.copy(id = history.save(saved))
    }
}
