package com.qrx.scanner.presentation.imagescan

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.qrx.scanner.domain.model.DetectedCode
import com.qrx.scanner.domain.model.ParsedContent
import com.qrx.scanner.domain.parser.ContentParser
import com.qrx.scanner.scanner.ImageCodeScanner
import com.qrx.scanner.scanner.ImageScanResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class FoundCode(val code: DetectedCode, val content: ParsedContent)

sealed interface ImageScanState {
    data object Loading : ImageScanState
    data class Found(val codes: List<FoundCode>) : ImageScanState
    data object NoCode : ImageScanState
    data object Unreadable : ImageScanState
}

@HiltViewModel
class ImageScanViewModel @Inject constructor(
    private val scanner: ImageCodeScanner,
) : ViewModel() {

    private val _state = MutableStateFlow<ImageScanState>(ImageScanState.Loading)
    val state: StateFlow<ImageScanState> = _state.asStateFlow()

    private val singleCodeChannel = Channel<DetectedCode>(Channel.BUFFERED)

    /** Fires when the image holds exactly one code, so the screen can skip the list. */
    val singleCode: Flow<DetectedCode> = singleCodeChannel.receiveAsFlow()

    private var currentUri: Uri? = null
    private var job: Job? = null

    /** Scans [uri] unless it is the image that is already being (or has been) scanned. */
    fun load(uri: Uri, force: Boolean = false) {
        if (!force && uri == currentUri) return
        currentUri = uri
        job?.cancel()
        _state.value = ImageScanState.Loading
        job = viewModelScope.launch {
            when (val result = scanner.scan(uri)) {
                is ImageScanResult.Found -> {
                    val found = result.codes.map { FoundCode(it, ContentParser.parse(it.rawValue, it.format)) }
                    if (found.size == 1) {
                        singleCodeChannel.send(found.first().code)
                    } else {
                        _state.value = ImageScanState.Found(found)
                    }
                }
                ImageScanResult.NoCode -> _state.value = ImageScanState.NoCode
                ImageScanResult.Unreadable -> _state.value = ImageScanState.Unreadable
            }
        }
    }

    fun retry() {
        currentUri?.let { load(it, force = true) }
    }
}
