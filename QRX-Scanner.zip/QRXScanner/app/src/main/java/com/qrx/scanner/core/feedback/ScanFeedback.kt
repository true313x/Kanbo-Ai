package com.qrx.scanner.core.feedback

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.View
import com.qrx.scanner.R
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/** Plays the success beep and haptic tick when a code is detected. */
@Singleton
class ScanFeedback @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private var soundPool: SoundPool? = null
    private var soundId = 0

    @Volatile
    private var soundReady = false

    /** Loads the sound ahead of the first scan so there is no delay when it matters. */
    @Synchronized
    fun prepare() {
        if (soundPool != null) return
        val pool = SoundPool.Builder()
            .setMaxStreams(1)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
            )
            .build()
        pool.setOnLoadCompleteListener { _, _, status -> soundReady = status == 0 }
        soundId = pool.load(context, R.raw.scan_beep, 1)
        soundPool = pool
    }

    fun play(sound: Boolean, haptics: Boolean, view: View) {
        if (sound && soundReady) soundPool?.play(soundId, 1f, 1f, 1, 0, 1f)
        if (haptics) {
            val constant = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                HapticFeedbackConstants.CONFIRM
            } else {
                HapticFeedbackConstants.LONG_PRESS
            }
            view.performHapticFeedback(constant)
        }
    }
}
