package com.qrx.scanner.generator

import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.WriterException
import com.google.zxing.qrcode.QRCodeWriter
import javax.inject.Inject

/** ZXing-backed [QrGenerator]. */
class QrCodeEncoder @Inject constructor() : QrGenerator {

    override fun generate(payload: String, errorCorrection: ErrorCorrection): QrGenerationResult {
        if (payload.isEmpty()) return QrGenerationResult.Failure(GenerationFailure.EMPTY)

        val hints = HashMap<EncodeHintType, Any>()
        hints[EncodeHintType.ERROR_CORRECTION] = errorCorrection.level
        hints[EncodeHintType.MARGIN] = QUIET_ZONE_MODULES
        if (payload.any { it.code > 127 }) hints[EncodeHintType.CHARACTER_SET] = "UTF-8"

        return try {
            // Width/height 0 asks ZXing for the smallest matrix: exactly one pixel per module.
            val bits = QRCodeWriter().encode(payload, BarcodeFormat.QR_CODE, 0, 0, hints)
            val size = bits.width
            val modules = BooleanArray(size * size)
            for (y in 0 until size) {
                for (x in 0 until size) {
                    modules[y * size + x] = bits.get(x, y)
                }
            }
            QrGenerationResult.Success(QrMatrix(size, QUIET_ZONE_MODULES, modules))
        } catch (error: WriterException) {
            QrGenerationResult.Failure(GenerationFailure.TOO_MUCH_DATA)
        } catch (error: IllegalArgumentException) {
            QrGenerationResult.Failure(GenerationFailure.TOO_MUCH_DATA)
        }
    }

    companion object {
        const val QUIET_ZONE_MODULES = 4
    }
}
