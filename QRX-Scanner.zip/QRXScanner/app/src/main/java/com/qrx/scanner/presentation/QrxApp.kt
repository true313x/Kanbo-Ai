package com.qrx.scanner.presentation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.qrx.scanner.domain.model.ThemeMode
import com.qrx.scanner.navigation.BottomBarHeight
import com.qrx.scanner.navigation.BottomBarMargin
import com.qrx.scanner.navigation.QrxBottomBar
import com.qrx.scanner.navigation.QrxNavHost
import com.qrx.scanner.navigation.QrxNavigationRail
import com.qrx.scanner.navigation.TopLevelDestination
import com.qrx.scanner.navigation.navigateTopLevel
import com.qrx.scanner.ui.components.LocalContentBottomPadding
import com.qrx.scanner.ui.theme.QrxTheme

private val WideLayoutThreshold = 600.dp

@Composable
fun QrxApp(themeMode: ThemeMode) {
    QrxTheme(themeMode = themeMode) {
        val navController = rememberNavController()
        val backStackEntry by navController.currentBackStackEntryAsState()
        val selected = TopLevelDestination.from(backStackEntry?.destination)
        val navigationInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
        ) {
            val wide = maxWidth >= WideLayoutThreshold
            val barVisible = selected != null && !wide

            Row(modifier = Modifier.fillMaxSize()) {
                if (wide && selected != null) {
                    QrxNavigationRail(
                        selected = selected,
                        onSelect = navController::navigateTopLevel,
                        modifier = Modifier.windowInsetsPadding(
                            WindowInsets.safeDrawing.only(WindowInsetsSides.Start + WindowInsetsSides.Vertical),
                        ),
                    )
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                ) {
                    val bottomPadding = if (barVisible) {
                        BottomBarHeight + BottomBarMargin * 2 + navigationInset
                    } else {
                        navigationInset
                    }
                    CompositionLocalProvider(LocalContentBottomPadding provides bottomPadding) {
                        QrxNavHost(navController = navController, modifier = Modifier.fillMaxSize())
                    }
                    BottomBarOverlay(
                        visible = barVisible,
                        selected = selected,
                        navController = navController,
                    )
                }
            }
        }
    }
}

@Composable
private fun BoxScope.BottomBarOverlay(
    visible: Boolean,
    selected: TopLevelDestination?,
    navController: NavController,
) {
    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically { it } + fadeIn(),
        exit = slideOutVertically { it } + fadeOut(),
        modifier = Modifier.align(Alignment.BottomCenter),
    ) {
        QrxBottomBar(
            selected = selected,
            onSelect = navController::navigateTopLevel,
            modifier = Modifier
                .windowInsetsPadding(
                    WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal),
                )
                .padding(horizontal = 16.dp, vertical = BottomBarMargin),
        )
    }
}
