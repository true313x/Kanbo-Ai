package com.qrx.scanner.generator

enum class Readability { GOOD, RISKY, POOR }
