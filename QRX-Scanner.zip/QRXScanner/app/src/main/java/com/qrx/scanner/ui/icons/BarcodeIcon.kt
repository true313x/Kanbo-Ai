package com.qrx.scanner.ui.icons

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/** A 1D barcode glyph; the Material icon set has no suitable equivalent. */
val BarcodeIcon: ImageVector by lazy {
    ImageVector.Builder(
        name = "Barcode",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f,
    ).apply {
        val bars = listOf(
            2.5f to 1.5f, 5.5f to 1f, 8f to 2.5f, 12f to 1f, 14.5f to 1.5f, 17.5f to 1f, 19.5f to 2f,
        )
        for ((x, width) in bars) {
            path(fill = SolidColor(Color.Black)) {
                moveTo(x, 5f)
                horizontalLineTo(x + width)
                verticalLineTo(19f)
                horizontalLineTo(x)
                close()
            }
        }
    }.build()
}
