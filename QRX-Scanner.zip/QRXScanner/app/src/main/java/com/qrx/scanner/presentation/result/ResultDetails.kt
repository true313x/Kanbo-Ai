package com.qrx.scanner.presentation.result

import androidx.annotation.StringRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.qrx.scanner.R
import com.qrx.scanner.domain.model.ParsedContent
import com.qrx.scanner.domain.model.ScanRecord
import com.qrx.scanner.domain.model.ScanSource
import com.qrx.scanner.domain.parser.UrlParser
import com.qrx.scanner.ui.components.icon
import com.qrx.scanner.ui.components.labelRes
import com.qrx.scanner.ui.theme.QrxMono
import com.qrx.scanner.util.HistoryDateFormatter
import java.util.Locale

@Composable
fun TicketTop(state: ResultUiState, record: ScanRecord) {
    Column(
        verticalArrangement = Arrangement.spacedBy(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 14.dp),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Chip(text = stringResource(record.type.labelRes), icon = record.type.icon, emphasized = true)
            Chip(text = record.format.displayName, icon = null, emphasized = false)
        }
        val bitmap = state.preview
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .widthIn(max = 280.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(Color.White)
                .padding(14.dp),
        ) {
            if (bitmap != null) {
                val image = remember(bitmap) { bitmap.asImageBitmap() }
                Image(
                    bitmap = image,
                    contentDescription = stringResource(R.string.result_preview_description, record.format.displayName),
                    filterQuality = FilterQuality.None,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(bitmap.width.toFloat() / bitmap.height.toFloat()),
                )
            } else {
                Icon(
                    imageVector = record.type.icon,
                    contentDescription = null,
                    tint = Color(0xFF12152B),
                    modifier = Modifier
                        .padding(36.dp)
                        .size(72.dp),
                )
            }
        }
    }
}

@Composable
private fun Chip(text: String, icon: ImageVector?, emphasized: Boolean) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (emphasized) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        contentColor = if (emphasized) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
        ) {
            if (icon != null) Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(16.dp))
            Text(text = text, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** The lower half of the ticket: the interpreted content of the code. */
@Composable
fun TicketBottom(content: ParsedContent) {
    Column(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 22.dp),
    ) {
        when (content) {
            is ParsedContent.Url -> UrlFields(content)
            is ParsedContent.Text -> Field(R.string.field_text, content.text)
            is ParsedContent.Wifi -> WifiFields(content)
            is ParsedContent.Contact -> ContactFields(content)
            is ParsedContent.Phone -> Field(R.string.field_number, content.number, headline = true)
            is ParsedContent.Email -> {
                Field(R.string.field_email, content.address, headline = true)
                content.subject?.let { Field(R.string.field_subject, it) }
                content.body?.let { Field(R.string.field_message, it) }
            }
            is ParsedContent.Sms -> {
                Field(R.string.field_number, content.number, headline = true)
                content.message?.let { Field(R.string.field_message, it) }
            }
            is ParsedContent.Geo -> {
                content.query?.let { Field(R.string.field_label, it, headline = true) }
                Field(R.string.field_coordinates, String.format(Locale.US, "%.6f, %.6f", content.latitude, content.longitude))
            }
            is ParsedContent.Barcode -> Field(R.string.field_value, content.value, headline = true, monospace = true)
        }
    }
}

@Composable
private fun ColumnScope.UrlFields(content: ParsedContent.Url) {
    val host = remember(content.url) { UrlParser.parse(content.url)?.host?.takeIf { it.isNotEmpty() } }
    if (host != null) Field(R.string.field_website, host, headline = true)
    Field(R.string.field_url, content.url, monospace = true)
}

@Composable
private fun ColumnScope.WifiFields(content: ParsedContent.Wifi) {
    Field(R.string.field_network_name, content.ssid, headline = true)
    Field(R.string.field_security, stringResource(content.security.labelRes))
    if (content.hidden) Field(R.string.field_hidden_network, stringResource(R.string.yes))
    val password = content.password
    if (password != null) {
        var revealed by rememberSaveable { mutableStateOf(false) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                FieldLabel(R.string.field_password)
                SelectionContainer {
                    Text(
                        text = if (revealed) password else "•".repeat(minOf(password.length, 16)),
                        style = QrxMono.copy(fontSize = MaterialTheme.typography.bodyLarge.fontSize),
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
            IconButton(onClick = { revealed = !revealed }) {
                Icon(
                    imageVector = if (revealed) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                    contentDescription = stringResource(
                        if (revealed) R.string.action_hide_password else R.string.action_show_password,
                    ),
                )
            }
        }
    }
}

@Composable
private fun ColumnScope.ContactFields(content: ParsedContent.Contact) {
    content.name?.let { Field(R.string.field_name, it, headline = true) }
    content.organization?.let { Field(R.string.field_organization, it) }
    content.jobTitle?.let { Field(R.string.field_job_title, it) }
    for (phone in content.phones) Field(R.string.field_phone, phone)
    for (email in content.emails) Field(R.string.field_email, email)
    content.address?.let { Field(R.string.field_address, it) }
    content.website?.let { Field(R.string.field_website, it) }
    content.note?.let { Field(R.string.field_note, it) }
}

@Composable
private fun FieldLabel(@StringRes labelRes: Int) {
    Text(
        text = stringResource(labelRes),
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun Field(
    @StringRes labelRes: Int,
    value: String,
    headline: Boolean = false,
    monospace: Boolean = false,
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp), modifier = Modifier.fillMaxWidth()) {
        FieldLabel(labelRes)
        SelectionContainer {
            Text(
                text = value,
                style = when {
                    monospace -> QrxMono.copy(fontSize = MaterialTheme.typography.bodyMedium.fontSize)
                    headline -> MaterialTheme.typography.titleLarge
                    else -> MaterialTheme.typography.bodyLarge
                },
                color = MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}

/** Technical details; this is what makes the screen double as "Scan details". */
@Composable
fun ScanDetailsCard(record: ScanRecord, modifier: Modifier = Modifier) {
    val locale = LocalConfiguration.current.locales[0] ?: Locale.getDefault()
    val source = when (record.metadata["source"]) {
        ScanSource.GALLERY.name.lowercase() -> R.string.source_gallery
        else -> R.string.source_camera
    }
    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = modifier.fillMaxWidth(),
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(18.dp),
        ) {
            Text(
                text = stringResource(R.string.details_title),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Field(R.string.details_format, record.format.displayName)
            Field(R.string.details_type, stringResource(record.type.labelRes))
            Field(R.string.details_scanned_at, HistoryDateFormatter.formatFull(record.createdAt, locale))
            Field(R.string.details_source, stringResource(source))
            Field(R.string.details_raw_value, record.rawValue, monospace = true)
        }
    }
}
