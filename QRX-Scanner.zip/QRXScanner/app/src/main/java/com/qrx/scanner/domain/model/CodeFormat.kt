package com.qrx.scanner.domain.model

/** The 13 symbologies supported by QRX Scanner. */
enum class CodeFormat(val isTwoDimensional: Boolean) {
    QR_CODE(true),
    AZTEC(true),
    DATA_MATRIX(true),
    PDF_417(true),
    CODABAR(false),
    CODE_39(false),
    CODE_93(false),
    CODE_128(false),
    EAN_8(false),
    EAN_13(false),
    ITF(false),
    UPC_A(false),
    UPC_E(false);

    val isOneDimensional: Boolean get() = !isTwoDimensional

    /** Human readable name that is the same in every language, e.g. "Code 128". */
    val displayName: String
        get() = when (this) {
            QR_CODE -> "QR Code"
            AZTEC -> "Aztec"
            DATA_MATRIX -> "Data Matrix"
            PDF_417 -> "PDF417"
            CODABAR -> "Codabar"
            CODE_39 -> "Code 39"
            CODE_93 -> "Code 93"
            CODE_128 -> "Code 128"
            EAN_8 -> "EAN-8"
            EAN_13 -> "EAN-13"
            ITF -> "ITF"
            UPC_A -> "UPC-A"
            UPC_E -> "UPC-E"
        }

    companion object {
        fun fromName(name: String): CodeFormat? = entries.firstOrNull { it.name == name }
    }
}
