package com.qrx.scanner.presentation.generator

import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.qrx.scanner.core.DispatcherProvider
import com.qrx.scanner.core.TimeProvider
import com.qrx.scanner.domain.model.WifiSecurity
import com.qrx.scanner.generator.CreateInput
import com.qrx.scanner.generator.ErrorCorrection
import com.qrx.scanner.generator.ExportResult
import com.qrx.scanner.generator.InputError
import com.qrx.scanner.generator.LogoLoader
import com.qrx.scanner.generator.PayloadResult
import com.qrx.scanner.generator.QrExporter
import com.qrx.scanner.generator.QrGenerationResult
import com.qrx.scanner.generator.QrGenerator
import com.qrx.scanner.generator.QrMatrix
import com.qrx.scanner.generator.QrPayloadBuilder
import com.qrx.scanner.generator.QrStyle
import com.qrx.scanner.generator.Readability
import com.qrx.scanner.generator.ReadabilityEvaluator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

data class GeneratorUiState(
    val type: GeneratorType,
    val fields: Map<GeneratorField, String> = emptyMap(),
    val wifiSecurity: WifiSecurity = WifiSecurity.WPA,
    val wifiHidden: Boolean = false,
    val foregroundIndex: Int = 0,
    val backgroundIndex: Int = 0,
    val sizePx: Int = QrStyle.DEFAULT_SIZE_PX,
    val errorCorrection: ErrorCorrection = ErrorCorrection.MEDIUM,
    val logo: Bitmap? = null,
    val matrix: QrMatrix? = null,
    val error: InputError? = null,
    val readability: Readability? = null,
    /** Bumped by "Regenerate" so the preview can replay its entrance animation. */
    val generation: Int = 0,
) {
    val foreground: Int get() = QrPalette.foregrounds[foregroundIndex].argb
    val background: Int get() = QrPalette.backgrounds[backgroundIndex].argb

    /** A logo hides modules, so the strongest error correction is forced to keep the code readable. */
    val effectiveErrorCorrection: ErrorCorrection
        get() = if (logo != null) ErrorCorrection.HIGH else errorCorrection

    val style: QrStyle
        get() = QrStyle(foreground, background, sizePx, effectiveErrorCorrection)
}

sealed interface GeneratorEvent {
    data object Saved : GeneratorEvent
    data class ShareReady(val uri: Uri) : GeneratorEvent
    data class CopyReady(val uri: Uri) : GeneratorEvent
    data object ExportFailed : GeneratorEvent
    data object LogoFailed : GeneratorEvent
}

@HiltViewModel
class GeneratorViewModel @Inject constructor(
    private val savedStateHandle: SavedStateHandle,
    private val payloadBuilder: QrPayloadBuilder,
    private val generator: QrGenerator,
    private val evaluator: ReadabilityEvaluator,
    private val exporter: QrExporter,
    private val logoLoader: LogoLoader,
    private val dispatchers: DispatcherProvider,
    private val time: TimeProvider,
) : ViewModel() {

    private val _state = MutableStateFlow(restoreState())
    val state: StateFlow<GeneratorUiState> = _state.asStateFlow()

    private val eventChannel = Channel<GeneratorEvent>(Channel.BUFFERED)
    val events: Flow<GeneratorEvent> = eventChannel.receiveAsFlow()

    private var generationJob: Job? = null

    init {
        regenerate()
    }

    // region Form

    fun setField(field: GeneratorField, value: String) {
        change {
            copy(fields = fields + (field to value))
        }
        savedStateHandle[KEY_FIELDS] = HashMap(_state.value.fields.mapKeys { it.key.name })
    }

    fun setWifiSecurity(security: WifiSecurity) {
        savedStateHandle[KEY_SECURITY] = security.name
        change { copy(wifiSecurity = security) }
    }

    fun setWifiHidden(hidden: Boolean) {
        savedStateHandle[KEY_HIDDEN] = hidden
        change { copy(wifiHidden = hidden) }
    }

    // endregion

    // region Style

    fun setForeground(index: Int) {
        if (index !in QrPalette.foregrounds.indices) return
        savedStateHandle[KEY_FOREGROUND] = index
        change { copy(foregroundIndex = index) }
    }

    fun setBackground(index: Int) {
        if (index !in QrPalette.backgrounds.indices) return
        savedStateHandle[KEY_BACKGROUND] = index
        change { copy(backgroundIndex = index) }
    }

    fun setSize(sizePx: Int) {
        savedStateHandle[KEY_SIZE] = sizePx
        change { copy(sizePx = sizePx) }
    }

    fun setErrorCorrection(level: ErrorCorrection) {
        savedStateHandle[KEY_EC] = level.name
        change { copy(errorCorrection = level) }
    }

    fun setLogo(uri: Uri) {
        viewModelScope.launch {
            val bitmap = logoLoader.load(uri)
            if (bitmap == null) {
                eventChannel.send(GeneratorEvent.LogoFailed)
            } else {
                change { copy(logo = bitmap) }
            }
        }
    }

    fun removeLogo() {
        change { copy(logo = null) }
    }

    fun regenerateWithAnimation() {
        change { copy(generation = generation + 1) }
    }

    // endregion

    // region Export

    /** File name suggested for "Save image". */
    fun suggestedFileName(): String = "qrx-${time.nowMillis()}.png"

    fun saveToGallery() {
        export(
            work = { matrix, style, logo -> exporter.saveToGallery(matrix, style, logo, suggestedFileName()) },
            onSuccess = { GeneratorEvent.Saved },
        )
    }

    fun saveToDocument(uri: Uri) {
        export(
            work = { matrix, style, logo -> exporter.saveToDocument(uri, matrix, style, logo) },
            onSuccess = { GeneratorEvent.Saved },
        )
    }

    fun share() {
        export(
            work = { matrix, style, logo -> exporter.createShareUri(matrix, style, logo) },
            onSuccess = { GeneratorEvent.ShareReady(it.uri) },
        )
    }

    fun copyImage() {
        export(
            work = { matrix, style, logo -> exporter.createShareUri(matrix, style, logo) },
            onSuccess = { GeneratorEvent.CopyReady(it.uri) },
        )
    }

    private fun export(
        work: suspend (QrMatrix, QrStyle, Bitmap?) -> ExportResult,
        onSuccess: (ExportResult.Success) -> GeneratorEvent,
    ) {
        val snapshot = _state.value
        val matrix = snapshot.matrix ?: return
        viewModelScope.launch {
            val event = when (val result = work(matrix, snapshot.style, snapshot.logo)) {
                is ExportResult.Success -> onSuccess(result)
                ExportResult.Failure -> GeneratorEvent.ExportFailed
            }
            eventChannel.send(event)
        }
    }

    // endregion

    private fun change(transform: GeneratorUiState.() -> GeneratorUiState) {
        _state.update(transform)
        regenerate()
    }

    private fun regenerate() {
        generationJob?.cancel()
        generationJob = viewModelScope.launch {
            val snapshot = _state.value
            val computed = withContext(dispatchers.default) { compute(snapshot) }
            _state.update {
                it.copy(matrix = computed.matrix, error = computed.error, readability = computed.readability)
            }
        }
    }

    private class Computation(val matrix: QrMatrix?, val error: InputError?, val readability: Readability?)

    private fun compute(state: GeneratorUiState): Computation =
        when (val built = payloadBuilder.build(toInput(state))) {
            // An untouched form is not an error; stay quiet until there is something to complain about.
            is PayloadResult.Error -> Computation(null, built.error.takeUnless { it == InputError.EMPTY }, null)
            is PayloadResult.Success -> when (val result = generator.generate(built.payload, state.effectiveErrorCorrection)) {
                is QrGenerationResult.Failure -> Computation(null, InputError.TOO_LONG, null)
                is QrGenerationResult.Success -> Computation(
                    matrix = result.matrix,
                    error = null,
                    readability = evaluator.evaluate(
                        matrix = result.matrix,
                        foreground = state.foreground,
                        background = state.background,
                        hasLogo = state.logo != null,
                    ),
                )
            }
        }

    private fun toInput(state: GeneratorUiState): CreateInput {
        fun value(field: GeneratorField): String = state.fields[field].orEmpty()
        return when (state.type) {
            GeneratorType.WEBSITE -> CreateInput.Website(value(GeneratorField.WEBSITE_URL))
            GeneratorType.TEXT -> CreateInput.Text(value(GeneratorField.TEXT))
            GeneratorType.WIFI -> CreateInput.Wifi(
                ssid = value(GeneratorField.SSID),
                password = value(GeneratorField.PASSWORD),
                security = state.wifiSecurity,
                hidden = state.wifiHidden,
            )
            GeneratorType.CONTACT -> CreateInput.Contact(
                name = value(GeneratorField.NAME),
                phone = value(GeneratorField.PHONE),
                email = value(GeneratorField.EMAIL),
                organization = value(GeneratorField.ORGANIZATION),
                jobTitle = value(GeneratorField.JOB_TITLE),
                address = value(GeneratorField.ADDRESS),
                website = value(GeneratorField.CONTACT_WEBSITE),
                note = value(GeneratorField.NOTE),
            )
            GeneratorType.PHONE -> CreateInput.Phone(value(GeneratorField.PHONE))
            GeneratorType.EMAIL -> CreateInput.Email(
                address = value(GeneratorField.EMAIL),
                subject = value(GeneratorField.SUBJECT),
                body = value(GeneratorField.BODY),
            )
            GeneratorType.SMS -> CreateInput.Sms(value(GeneratorField.PHONE), value(GeneratorField.BODY))
            GeneratorType.LOCATION -> CreateInput.Location(
                latitude = value(GeneratorField.LATITUDE),
                longitude = value(GeneratorField.LONGITUDE),
                label = value(GeneratorField.LABEL),
            )
        }
    }

    private fun restoreState(): GeneratorUiState {
        val type = GeneratorType.fromName(savedStateHandle.get<String>(KEY_TYPE).orEmpty())
        val savedFields = savedStateHandle.get<HashMap<String, String>>(KEY_FIELDS).orEmpty()
        val fields = GeneratorField.entries
            .mapNotNull { field -> savedFields[field.name]?.let { field to it } }
            .toMap()
        return GeneratorUiState(
            type = type,
            fields = fields,
            wifiSecurity = WifiSecurity.entries.firstOrNull { it.name == savedStateHandle.get<String>(KEY_SECURITY) }
                ?: WifiSecurity.WPA,
            wifiHidden = savedStateHandle.get<Boolean>(KEY_HIDDEN) ?: false,
            foregroundIndex = savedStateHandle.get<Int>(KEY_FOREGROUND) ?: 0,
            backgroundIndex = savedStateHandle.get<Int>(KEY_BACKGROUND) ?: 0,
            sizePx = savedStateHandle.get<Int>(KEY_SIZE) ?: QrStyle.DEFAULT_SIZE_PX,
            errorCorrection = ErrorCorrection.entries.firstOrNull { it.name == savedStateHandle.get<String>(KEY_EC) }
                ?: ErrorCorrection.MEDIUM,
        )
    }

    private companion object {
        /** Navigation stores route arguments in the handle under their property names. */
        const val KEY_TYPE = "type"
        const val KEY_FIELDS = "generator_fields"
        const val KEY_SECURITY = "generator_security"
        const val KEY_HIDDEN = "generator_hidden"
        const val KEY_FOREGROUND = "generator_foreground"
        const val KEY_BACKGROUND = "generator_background"
        const val KEY_SIZE = "generator_size"
        const val KEY_EC = "generator_ec"
    }
}
