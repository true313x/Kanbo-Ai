package com.qrx.scanner.generator

/** Visual options for a generated QR code. Colours are opaque ARGB ints. */
data class QrStyle(
    val foreground: Int,
    val background: Int,
    val sizePx: Int,
    val errorCorrection: ErrorCorrection,
) {
    companion object {
        const val DEFAULT_FOREGROUND = 0xFF12152B.toInt()
        const val DEFAULT_BACKGROUND = 0xFFFFFFFF.toInt()
        const val DEFAULT_SIZE_PX = 1024
        val SIZES_PX = listOf(512, 1024, 2048)
    }
}
