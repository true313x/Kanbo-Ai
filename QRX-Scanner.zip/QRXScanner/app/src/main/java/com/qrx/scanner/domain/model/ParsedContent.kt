package com.qrx.scanner.domain.model

import java.util.Locale

/** Structured interpretation of a raw scanned string. Nothing here is ever executed automatically. */
sealed interface ParsedContent {
    val type: ContentType

    /** Short, single-line summary that is stored in history and shown in lists. */
    val displayValue: String

    data class Url(val url: String) : ParsedContent {
        override val type: ContentType get() = ContentType.URL
        override val displayValue: String get() = url
    }

    data class Text(val text: String) : ParsedContent {
        override val type: ContentType get() = ContentType.TEXT
        override val displayValue: String get() = text
    }

    data class Wifi(
        val ssid: String,
        val password: String?,
        val security: WifiSecurity,
        val hidden: Boolean,
    ) : ParsedContent {
        override val type: ContentType get() = ContentType.WIFI
        override val displayValue: String get() = ssid
    }

    data class Contact(
        val name: String?,
        val phones: List<String>,
        val emails: List<String>,
        val organization: String?,
        val jobTitle: String?,
        val address: String?,
        val website: String?,
        val note: String?,
    ) : ParsedContent {
        override val type: ContentType get() = ContentType.CONTACT
        override val displayValue: String
            get() = name ?: phones.firstOrNull() ?: emails.firstOrNull() ?: organization.orEmpty()
    }

    data class Phone(val number: String) : ParsedContent {
        override val type: ContentType get() = ContentType.PHONE
        override val displayValue: String get() = number
    }

    data class Email(
        val address: String,
        val subject: String?,
        val body: String?,
    ) : ParsedContent {
        override val type: ContentType get() = ContentType.EMAIL
        override val displayValue: String get() = address
    }

    data class Sms(val number: String, val message: String?) : ParsedContent {
        override val type: ContentType get() = ContentType.SMS
        override val displayValue: String get() = number
    }

    data class Geo(
        val latitude: Double,
        val longitude: Double,
        val query: String?,
    ) : ParsedContent {
        override val type: ContentType get() = ContentType.GEO
        override val displayValue: String
            get() = query ?: String.format(Locale.US, "%.5f, %.5f", latitude, longitude)
    }

    data class Barcode(val value: String) : ParsedContent {
        override val type: ContentType get() = ContentType.BARCODE
        override val displayValue: String get() = value
    }
}
