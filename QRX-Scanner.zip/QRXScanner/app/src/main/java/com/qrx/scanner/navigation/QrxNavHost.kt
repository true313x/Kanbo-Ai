package com.qrx.scanner.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.core.net.toUri
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.toRoute
import com.qrx.scanner.domain.model.DetectedCode
import com.qrx.scanner.domain.model.ScanSource
import com.qrx.scanner.presentation.create.CreateScreen
import com.qrx.scanner.presentation.document.DocumentKind
import com.qrx.scanner.presentation.document.DocumentScreen
import com.qrx.scanner.presentation.favorites.FavoritesScreen
import com.qrx.scanner.presentation.generator.GeneratorScreen
import com.qrx.scanner.presentation.history.HistoryScreen
import com.qrx.scanner.presentation.imagescan.ImageScanScreen
import com.qrx.scanner.presentation.result.ResultScreen
import com.qrx.scanner.presentation.scanner.ScannerScreen
import com.qrx.scanner.presentation.settings.SettingsScreen

fun NavController.navigateTopLevel(destination: TopLevelDestination) {
    navigate(destination.route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

private const val TRANSITION_MILLIS = 300
private const val FADE_MILLIS = 220

@Composable
fun QrxNavHost(
    navController: NavHostController,
    modifier: Modifier = Modifier,
) {
    fun AnimatedContentTransitionScope<NavBackStackEntry>.betweenTabs(): Boolean =
        TopLevelDestination.from(initialState.destination) != null &&
            TopLevelDestination.from(targetState.destination) != null

    NavHost(
        navController = navController,
        startDestination = ScannerRoute,
        modifier = modifier,
        enterTransition = {
            if (betweenTabs()) {
                fadeIn(tween(FADE_MILLIS, delayMillis = 60))
            } else {
                slideIntoContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Start,
                    animationSpec = tween(TRANSITION_MILLIS),
                    initialOffset = { it / 6 },
                ) + fadeIn(tween(TRANSITION_MILLIS))
            }
        },
        exitTransition = {
            fadeOut(tween(if (betweenTabs()) 120 else TRANSITION_MILLIS))
        },
        popEnterTransition = {
            fadeIn(tween(TRANSITION_MILLIS))
        },
        popExitTransition = {
            slideOutOfContainer(
                towards = AnimatedContentTransitionScope.SlideDirection.End,
                animationSpec = tween(TRANSITION_MILLIS),
                targetOffset = { it / 6 },
            ) + fadeOut(tween(TRANSITION_MILLIS))
        },
    ) {
        composable<ScannerRoute> {
            ScannerScreen(
                onCodeDetected = { code ->
                    navController.navigate(code.toResultRoute(ScanSource.CAMERA))
                },
                onImagePicked = { uri -> navController.navigate(ImageScanRoute(uri.toString())) },
                onOpenHistory = { navController.navigateTopLevel(TopLevelDestination.HISTORY) },
                onOpenSettings = { navController.navigateTopLevel(TopLevelDestination.SETTINGS) },
            )
        }
        composable<HistoryRoute> {
            HistoryScreen(
                onOpenRecord = { id -> navController.navigate(ResultRoute(historyId = id)) },
                onOpenFavorites = { navController.navigate(FavoritesRoute) },
            )
        }
        composable<FavoritesRoute> {
            FavoritesScreen(
                onBack = { navController.popBackStack() },
                onOpenRecord = { id -> navController.navigate(ResultRoute(historyId = id)) },
            )
        }
        composable<CreateRoute> {
            CreateScreen(onOpenGenerator = { type -> navController.navigate(GeneratorRoute(type.name)) })
        }
        composable<SettingsRoute> {
            SettingsScreen(onOpenDocument = { kind -> navController.navigate(DocumentRoute(kind.name)) })
        }
        composable<ResultRoute> {
            ResultScreen(onBack = { navController.popBackStack() })
        }
        composable<ImageScanRoute> { entry ->
            val route = entry.toRoute<ImageScanRoute>()
            ImageScanScreen(
                uri = route.uri.toUri(),
                onBack = { navController.popBackStack() },
                onOpenCode = { code ->
                    navController.navigate(code.toResultRoute(ScanSource.GALLERY))
                },
                onOpenSingleCode = { code ->
                    navController.navigate(code.toResultRoute(ScanSource.GALLERY)) {
                        popUpTo<ImageScanRoute> { inclusive = true }
                    }
                },
            )
        }
        composable<GeneratorRoute> {
            GeneratorScreen(onBack = { navController.popBackStack() })
        }
        composable<DocumentRoute> { entry ->
            val route = entry.toRoute<DocumentRoute>()
            DocumentScreen(
                kind = DocumentKind.fromName(route.kind),
                onBack = { navController.popBackStack() },
            )
        }
    }
}

private fun DetectedCode.toResultRoute(source: ScanSource): ResultRoute = ResultRoute(
    rawValue = rawValue,
    format = format.name,
    source = source.name,
    fresh = true,
)
