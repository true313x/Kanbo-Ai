package com.qrx.scanner.domain

import com.qrx.scanner.domain.security.Severity
import com.qrx.scanner.domain.security.UrlIssue
import com.qrx.scanner.domain.security.UrlSecurityAnalyzer
import com.qrx.scanner.domain.security.UrlSecurityReport
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UrlSecurityAnalyzerTest {

    private val analyzer = UrlSecurityAnalyzer()

    private fun UrlSecurityReport.has(issue: UrlIssue) = findings.any { it.issue == issue }

    @Test
    fun plainHttpsLinkIsClean() {
        val report = analyzer.analyze("https://example.com/")
        assertNull(report.level)
        assertTrue(report.isClean)
        assertTrue(report.canAutoOpen)
        assertFalse(report.isBlocked)
        assertFalse(report.requiresConfirmation)
    }

    @Test
    fun httpNeedsConfirmationAndIsNeverAutoOpened() {
        val report = analyzer.analyze("http://example.com")
        assertTrue(report.has(UrlIssue.INSECURE_HTTP))
        assertTrue(report.requiresConfirmation)
        assertFalse(report.canAutoOpen)
    }

    @Test
    fun javascriptAndIntentAreBlocked() {
        for (url in listOf("javascript:alert(1)", "intent://scan/#Intent;scheme=zxing;end", "file:///sdcard/a", "data:text/html,hi")) {
            val report = analyzer.analyze(url)
            assertTrue(url, report.isBlocked)
            assertEquals(url, Severity.DANGER, report.level)
            assertFalse(url, report.canAutoOpen)
        }
    }

    @Test
    fun ipAddressIsFlagged() {
        assertTrue(analyzer.analyze("https://192.168.0.1/login").has(UrlIssue.IP_ADDRESS))
        assertTrue(analyzer.analyze("https://[2001:db8::1]/").has(UrlIssue.IP_ADDRESS))
    }

    @Test
    fun punycodeAndLookAlikeHostsAreFlagged() {
        assertTrue(analyzer.analyze("https://xn--pple-43d.com").has(UrlIssue.PUNYCODE))
        assertTrue(analyzer.analyze("https://\u0430pple.com").has(UrlIssue.NON_ASCII_HOST))
    }

    @Test
    fun veryLongUrlIsFlagged() {
        assertTrue(analyzer.analyze("https://example.com/" + "a".repeat(400)).has(UrlIssue.VERY_LONG))
    }

    @Test
    fun shortenersAndSuspiciousTldsAreFlagged() {
        assertTrue(analyzer.analyze("https://bit.ly/abc").has(UrlIssue.URL_SHORTENER))
        assertTrue(analyzer.analyze("https://free-prize.zip").has(UrlIssue.SUSPICIOUS_TLD))
    }

    @Test
    fun redirectParametersAreFlagged() {
        assertTrue(analyzer.analyze("https://example.com/r?url=https://evil.example").has(UrlIssue.SUSPICIOUS_REDIRECT))
        assertFalse(analyzer.analyze("https://example.com/r?page=2").has(UrlIssue.SUSPICIOUS_REDIRECT))
    }

    @Test
    fun userInfoTrickIsFlagged() {
        val report = analyzer.analyze("https://google.com@evil.example/")
        assertTrue(report.has(UrlIssue.USER_INFO))
        assertEquals("evil.example", report.host)
    }

    @Test
    fun manySubdomainsAreFlagged() {
        assertTrue(analyzer.analyze("https://a.b.c.d.example.com").has(UrlIssue.MANY_SUBDOMAINS))
    }

    @Test
    fun unusualPortIsOnlyInformational() {
        val report = analyzer.analyze("https://example.com:8443/")
        assertEquals(Severity.INFO, report.level)
        assertTrue(report.canAutoOpen)
    }

    @Test
    fun garbageIsBlockedAsUnreadable() {
        val report = analyzer.analyze("not a url")
        assertTrue(report.has(UrlIssue.UNREADABLE))
        assertTrue(report.isBlocked)
    }
}
