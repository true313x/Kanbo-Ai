package com.qrx.scanner.domain

import com.qrx.scanner.domain.model.CodeFormat
import com.qrx.scanner.domain.model.ContentType
import com.qrx.scanner.domain.model.HistoryFilter
import com.qrx.scanner.domain.usecase.HistoryFilterer
import com.qrx.scanner.testutil.record
import org.junit.Assert.assertEquals
import org.junit.Test

class HistoryFiltererTest {

    private val url = record(1, ContentType.URL, "https://Example.com", format = CodeFormat.QR_CODE)
    private val text = record(2, ContentType.TEXT, "Shopping list", format = CodeFormat.QR_CODE)
    private val wifi = record(3, ContentType.WIFI, "WIFI:S:Home;;", display = "Home", format = CodeFormat.QR_CODE)
    private val contact = record(4, ContentType.CONTACT, "BEGIN:VCARD", display = "Jane Doe", format = CodeFormat.QR_CODE)
    private val phone = record(5, ContentType.PHONE, "tel:123", display = "123", format = CodeFormat.QR_CODE)
    private val ean = record(6, ContentType.BARCODE, "5901234123457", format = CodeFormat.EAN_13)
    private val all = listOf(url, text, wifi, contact, phone, ean)

    private val labels = mapOf(
        ContentType.URL to "Website",
        ContentType.TEXT to "Text",
        ContentType.WIFI to "Wi-Fi",
        ContentType.CONTACT to "Contact",
        ContentType.PHONE to "Phone",
        ContentType.EMAIL to "Email",
        ContentType.SMS to "SMS",
        ContentType.GEO to "Location",
        ContentType.BARCODE to "Barcode",
    )

    private fun apply(filter: HistoryFilter, query: String = "") =
        HistoryFilterer.apply(all, filter, query) { labels.getValue(it) }.map { it.id }

    @Test
    fun allKeepsEverything() {
        assertEquals(listOf(1L, 2L, 3L, 4L, 5L, 6L), apply(HistoryFilter.ALL))
    }

    @Test
    fun qrAndBarcodeSplitBySymbology() {
        assertEquals(listOf(1L, 2L, 3L, 4L, 5L), apply(HistoryFilter.QR))
        assertEquals(listOf(6L), apply(HistoryFilter.BARCODE))
    }

    @Test
    fun typeFilters() {
        assertEquals(listOf(1L), apply(HistoryFilter.URLS))
        assertEquals(listOf(2L), apply(HistoryFilter.TEXT))
        assertEquals(listOf(3L), apply(HistoryFilter.WIFI))
        assertEquals(listOf(4L), apply(HistoryFilter.CONTACTS))
    }

    @Test
    fun otherCollectsTheRemainingTypes() {
        assertEquals(listOf(5L, 6L), apply(HistoryFilter.OTHER))
    }

    @Test
    fun searchMatchesDisplayRawFormatAndTypeLabelIgnoringCase() {
        assertEquals(listOf(1L), apply(HistoryFilter.ALL, "example"))
        assertEquals(listOf(2L), apply(HistoryFilter.ALL, "SHOPPING"))
        assertEquals(listOf(4L), apply(HistoryFilter.ALL, "jane"))
        assertEquals(listOf(6L), apply(HistoryFilter.ALL, "ean-13"))
        assertEquals(listOf(3L), apply(HistoryFilter.ALL, "wi-fi"))
    }

    @Test
    fun searchAndFilterCombine() {
        assertEquals(emptyList<Long>(), apply(HistoryFilter.URLS, "shopping"))
        assertEquals(listOf(1L), apply(HistoryFilter.URLS, "  EXAMPLE  "))
    }
}
