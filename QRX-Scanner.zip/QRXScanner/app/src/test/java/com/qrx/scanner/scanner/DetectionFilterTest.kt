package com.qrx.scanner.scanner

import com.qrx.scanner.domain.model.CodeFormat
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DetectionFilterTest {

    private var now = 0L
    private val filter = DetectionFilter(now = { now })

    private fun accept(value: String, format: CodeFormat, at: Long): Boolean {
        now = at
        return filter.accept(value, format)
    }

    @Test
    fun qrCodeIsAcceptedOnFirstSighting() {
        assertTrue(accept("a", CodeFormat.QR_CODE, 0))
    }

    @Test
    fun sameCodeIsSuppressedWithinTheWindow() {
        assertTrue(accept("a", CodeFormat.QR_CODE, 0))
        assertFalse(accept("a", CodeFormat.QR_CODE, 500))
        assertFalse(accept("a", CodeFormat.QR_CODE, 2_000))
    }

    @Test
    fun codeInFrontOfTheLensNeverRetriggers() {
        assertTrue(accept("a", CodeFormat.QR_CODE, 0))
        assertFalse(accept("a", CodeFormat.QR_CODE, 2_000))
        assertFalse(accept("a", CodeFormat.QR_CODE, 4_000))
        assertTrue(accept("a", CodeFormat.QR_CODE, 6_600))
    }

    @Test
    fun differentCodeIsAcceptedImmediately() {
        assertTrue(accept("a", CodeFormat.QR_CODE, 0))
        assertTrue(accept("b", CodeFormat.QR_CODE, 100))
    }

    @Test
    fun sameValueInAnotherFormatIsADifferentCode() {
        assertTrue(accept("123456789012", CodeFormat.QR_CODE, 0))
        assertFalse(accept("123456789012", CodeFormat.UPC_A, 100))
        assertTrue(accept("123456789012", CodeFormat.UPC_A, 300))
    }

    @Test
    fun linearBarcodeNeedsTwoConsecutiveSightings() {
        assertFalse(accept("5901234123457", CodeFormat.EAN_13, 0))
        assertTrue(accept("5901234123457", CodeFormat.EAN_13, 100))
    }

    @Test
    fun staleSightingDoesNotCountForLinearBarcodes() {
        assertFalse(accept("5901234123457", CodeFormat.EAN_13, 0))
        assertFalse(accept("5901234123457", CodeFormat.EAN_13, 2_000))
        assertTrue(accept("5901234123457", CodeFormat.EAN_13, 2_100))
    }

    @Test
    fun misreadLinearBarcodeResetsTheConfirmation() {
        assertFalse(accept("5901234123457", CodeFormat.EAN_13, 0))
        assertFalse(accept("5901234123458", CodeFormat.EAN_13, 100))
        assertFalse(accept("5901234123457", CodeFormat.EAN_13, 200))
        assertTrue(accept("5901234123457", CodeFormat.EAN_13, 300))
    }

    @Test
    fun resetForgetsTheLastCode() {
        assertTrue(accept("a", CodeFormat.QR_CODE, 0))
        filter.reset()
        assertTrue(accept("a", CodeFormat.QR_CODE, 10))
    }
}
