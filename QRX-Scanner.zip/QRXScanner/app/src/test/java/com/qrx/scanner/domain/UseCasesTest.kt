package com.qrx.scanner.domain

import com.qrx.scanner.domain.model.AppSettings
import com.qrx.scanner.domain.model.CodeFormat
import com.qrx.scanner.domain.model.ContentType
import com.qrx.scanner.domain.model.ParsedContent
import com.qrx.scanner.domain.model.ScanSource
import com.qrx.scanner.domain.usecase.ProcessScanUseCase
import com.qrx.scanner.domain.usecase.SetFavoriteUseCase
import com.qrx.scanner.testutil.FakeHistoryRepository
import com.qrx.scanner.testutil.FakeSettingsRepository
import com.qrx.scanner.testutil.FixedTimeProvider
import com.qrx.scanner.testutil.record
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UseCasesTest {

    private val history = FakeHistoryRepository()
    private val time = FixedTimeProvider(1_234L)

    private fun processor(autoSave: Boolean = true) = ProcessScanUseCase(
        history = history,
        settings = FakeSettingsRepository(AppSettings(autoSaveHistory = autoSave)),
        time = time,
    )

    @Test
    fun scanIsInterpretedAndStoredWhenAutoSaveIsOn() = runTest {
        val outcome = processor()("https://example.com/a", CodeFormat.QR_CODE, ScanSource.CAMERA)

        assertTrue(outcome.content is ParsedContent.Url)
        assertTrue(outcome.record.isPersisted)
        assertEquals(ContentType.URL, outcome.record.type)
        assertEquals(1_234L, outcome.record.createdAt)
        assertEquals("camera", outcome.record.metadata["source"])
        assertEquals("example.com", outcome.record.metadata["host"])
        assertEquals(listOf(outcome.record), history.snapshot)
    }

    @Test
    fun scanIsNotStoredWhenAutoSaveIsOff() = runTest {
        val outcome = processor(autoSave = false)("hello", CodeFormat.QR_CODE, ScanSource.GALLERY)

        assertFalse(outcome.record.isPersisted)
        assertEquals("gallery", outcome.record.metadata["source"])
        assertTrue(history.snapshot.isEmpty())
    }

    @Test
    fun linearBarcodesAreTreatedAsBarcodes() = runTest {
        val outcome = processor()("5901234123457", CodeFormat.EAN_13, ScanSource.CAMERA)

        assertEquals(ContentType.BARCODE, outcome.record.type)
        assertEquals("5901234123457", outcome.record.displayValue)
    }

    @Test
    fun wifiDisplaysTheNetworkNameNotThePassword() = runTest {
        val outcome = processor()("WIFI:T:WPA;S:Home;P:secret;;", CodeFormat.QR_CODE, ScanSource.CAMERA)

        assertEquals("Home", outcome.record.displayValue)
        assertFalse(outcome.record.metadata.values.any { it.contains("secret") })
    }

    @Test
    fun favoritingAPersistedRecordUpdatesIt() = runTest {
        val id = history.save(record(raw = "a", createdAt = 1))
        val stored = history.getById(id)!!

        val updated = SetFavoriteUseCase(history)(stored, favorite = true)

        assertTrue(updated.isFavorite)
        assertEquals(id, updated.id)
        assertTrue(history.getById(id)!!.isFavorite)
    }

    @Test
    fun favoritingAnUnsavedRecordStoresItFirst() = runTest {
        val unsaved = record(id = 0, raw = "b")

        val updated = SetFavoriteUseCase(history)(unsaved, favorite = true)

        assertTrue(updated.isPersisted)
        assertTrue(updated.isFavorite)
        assertEquals(1, history.snapshot.size)
    }
}
