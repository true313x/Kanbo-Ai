package com.qrx.scanner.presentation

import com.qrx.scanner.domain.model.ContentType
import com.qrx.scanner.domain.model.HistoryFilter
import com.qrx.scanner.presentation.history.HistoryEvent
import com.qrx.scanner.presentation.history.HistoryViewModel
import com.qrx.scanner.testutil.FakeHistoryRepository
import com.qrx.scanner.testutil.MainDispatcherRule
import com.qrx.scanner.testutil.record
import androidx.lifecycle.SavedStateHandle
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class HistoryViewModelTest {

    @get:Rule
    val mainRule = MainDispatcherRule()

    private val repository = FakeHistoryRepository(
        listOf(
            record(1, ContentType.URL, "https://a.com", createdAt = 10),
            record(2, ContentType.TEXT, "note", createdAt = 20),
        ),
    )

    private fun viewModel() = HistoryViewModel(repository, SavedStateHandle())

    @Test
    fun recordsAreListedNewestFirst() = runTest {
        val viewModel = viewModel()
        viewModel.state.launchIn(backgroundScope)

        val state = viewModel.state.value
        assertFalse(state.isLoading)
        assertEquals(listOf(2L, 1L), state.records.map { it.id })
        assertEquals(HistoryFilter.ALL, state.filter)
    }

    @Test
    fun filterAndQueryAreKeptInTheState() = runTest {
        val viewModel = viewModel()
        viewModel.state.launchIn(backgroundScope)

        viewModel.setFilter(HistoryFilter.URLS)
        viewModel.setQuery("a.com")

        assertEquals(HistoryFilter.URLS, viewModel.state.value.filter)
        assertEquals("a.com", viewModel.state.value.query)
    }

    @Test
    fun favoriteIsToggled() = runTest {
        val viewModel = viewModel()
        viewModel.state.launchIn(backgroundScope)

        viewModel.toggleFavorite(repository.getById(1)!!)
        assertTrue(repository.getById(1)!!.isFavorite)

        viewModel.toggleFavorite(repository.getById(1)!!)
        assertFalse(repository.getById(1)!!.isFavorite)
    }

    @Test
    fun deleteAnnouncesItselfAndCanBeUndone() = runTest {
        val viewModel = viewModel()
        viewModel.state.launchIn(backgroundScope)
        val events = mutableListOf<HistoryEvent>()
        viewModel.events.onEach { events += it }.launchIn(backgroundScope)

        val target = repository.getById(2)!!
        viewModel.delete(target)

        assertEquals(listOf<HistoryEvent>(HistoryEvent.Deleted), events)
        assertEquals(listOf(1L), repository.snapshot.map { it.id })

        viewModel.undoDelete()
        assertEquals(setOf(1L, 2L), repository.snapshot.map { it.id }.toSet())
        assertEquals(target, repository.getById(2))
    }

    @Test
    fun undoWithoutAPreviousDeleteDoesNothing() = runTest {
        val viewModel = viewModel()
        viewModel.undoDelete()
        assertEquals(2, repository.snapshot.size)
    }

    @Test
    fun deleteAllEmptiesTheHistory() = runTest {
        val viewModel = viewModel()
        viewModel.state.launchIn(backgroundScope)

        viewModel.deleteAll()

        assertTrue(repository.snapshot.isEmpty())
        assertTrue(viewModel.state.first().records.isEmpty())
    }
}
