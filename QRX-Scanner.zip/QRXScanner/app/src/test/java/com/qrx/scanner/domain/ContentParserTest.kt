package com.qrx.scanner.domain

import com.qrx.scanner.domain.model.CodeFormat
import com.qrx.scanner.domain.model.ContentType
import com.qrx.scanner.domain.model.ParsedContent
import com.qrx.scanner.domain.model.WifiSecurity
import com.qrx.scanner.domain.parser.ContentParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ContentParserTest {

    private fun parse(value: String, format: CodeFormat = CodeFormat.QR_CODE) = ContentParser.parse(value, format)

    @Test
    fun wifiWithPassword() {
        val result = parse("WIFI:T:WPA;S:MyNet;P:secret123;;") as ParsedContent.Wifi
        assertEquals("MyNet", result.ssid)
        assertEquals("secret123", result.password)
        assertEquals(WifiSecurity.WPA, result.security)
        assertEquals(false, result.hidden)
    }

    @Test
    fun wifiEscapedCharactersAreDecoded() {
        val result = parse("WIFI:T:WPA;S:My\\;Net;P:pa\\:ss\\\\word;;") as ParsedContent.Wifi
        assertEquals("My;Net", result.ssid)
        assertEquals("pa:ss\\word", result.password)
    }

    @Test
    fun openWifiHasNoPassword() {
        val result = parse("WIFI:T:nopass;S:Cafe;P:ignored;;") as ParsedContent.Wifi
        assertEquals(WifiSecurity.OPEN, result.security)
        assertNull(result.password)
    }

    @Test
    fun hiddenWifiAndWpa3() {
        val result = parse("WIFI:T:SAE;S:Net;P:pw;H:true;;") as ParsedContent.Wifi
        assertEquals(WifiSecurity.WPA3, result.security)
        assertTrue(result.hidden)
    }

    @Test
    fun wifiWithoutSsidFallsBackToText() {
        assertTrue(parse("WIFI:T:WPA;P:pw;;") is ParsedContent.Text)
    }

    @Test
    fun vCardContact() {
        val card = """
            BEGIN:VCARD
            VERSION:3.0
            N:Doe;Jane;;;
            FN:Jane Doe
            ORG:Acme
            TITLE:Engineer
            TEL;TYPE=CELL:+15551234567
            EMAIL:jane@acme.com
            URL:https://acme.com
            END:VCARD
        """.trimIndent()
        val result = parse(card) as ParsedContent.Contact
        assertEquals("Jane Doe", result.name)
        assertEquals(listOf("+15551234567"), result.phones)
        assertEquals(listOf("jane@acme.com"), result.emails)
        assertEquals("Acme", result.organization)
        assertEquals("Engineer", result.jobTitle)
        assertEquals("https://acme.com", result.website)
    }

    @Test
    fun meCardContact() {
        val result = parse("MECARD:N:Doe,John;TEL:123456;EMAIL:j@x.com;;") as ParsedContent.Contact
        assertEquals("John Doe", result.name)
        assertEquals(listOf("123456"), result.phones)
        assertEquals(listOf("j@x.com"), result.emails)
    }

    @Test
    fun phoneNumber() {
        assertEquals(ParsedContent.Phone("+1 555 0100"), parse("tel:+1 555 0100"))
    }

    @Test
    fun mailtoWithSubjectAndBody() {
        val result = parse("mailto:a@b.com?subject=Hello%20World&body=Hi") as ParsedContent.Email
        assertEquals("a@b.com", result.address)
        assertEquals("Hello World", result.subject)
        assertEquals("Hi", result.body)
    }

    @Test
    fun matmsgEmail() {
        val result = parse("MATMSG:TO:a@b.com;SUB:Subject;BODY:Text;;") as ParsedContent.Email
        assertEquals("a@b.com", result.address)
        assertEquals("Subject", result.subject)
        assertEquals("Text", result.body)
    }

    @Test
    fun smsVariants() {
        assertEquals(ParsedContent.Sms("+1555", "Hello there"), parse("SMSTO:+1555:Hello there"))
        assertEquals(ParsedContent.Sms("+1555", "Hi"), parse("sms:+1555?body=Hi"))
        assertEquals(ParsedContent.Sms("+1555", null), parse("sms:+1555"))
    }

    @Test
    fun geoWithQuery() {
        val result = parse("geo:37.7749,-122.4194?q=Golden%20Gate") as ParsedContent.Geo
        assertEquals(37.7749, result.latitude, 1e-9)
        assertEquals(-122.4194, result.longitude, 1e-9)
        assertEquals("Golden Gate", result.query)
    }

    @Test
    fun invalidGeoFallsBackToText() {
        assertTrue(parse("geo:abc") is ParsedContent.Text)
        assertTrue(parse("geo:95.0,10.0") is ParsedContent.Text)
    }

    @Test
    fun urls() {
        assertEquals(ParsedContent.Url("https://example.com/path"), parse("https://example.com/path"))
        assertEquals(ParsedContent.Url("https://www.example.com"), parse("www.example.com"))
        assertEquals(ParsedContent.Url("HTTP://EXAMPLE.COM"), parse("HTTP://EXAMPLE.COM"))
    }

    @Test
    fun dangerousSchemesAreStillRecognisedAsUrls() {
        assertTrue(parse("javascript:alert(1)") is ParsedContent.Url)
        assertTrue(parse("intent://scan/#Intent;scheme=zxing;end") is ParsedContent.Url)
        assertTrue(parse("data:text/html;base64,PHNjcmlwdD4=") is ParsedContent.Url)
    }

    @Test
    fun plainTextStaysText() {
        assertEquals(ParsedContent.Text("hello world"), parse("hello world"))
        assertEquals(ParsedContent.Text("example.com"), parse("example.com"))
        assertEquals(ParsedContent.Text("12345"), parse("12345"))
        assertTrue(parse("   ") is ParsedContent.Text)
    }

    @Test
    fun linearBarcodesAreNeverInterpreted() {
        assertEquals(ParsedContent.Barcode("5901234123457"), parse("5901234123457", CodeFormat.EAN_13))
        assertEquals(ParsedContent.Barcode("https://example.com"), parse("https://example.com", CodeFormat.CODE_128))
    }

    @Test
    fun typesAreReportedCorrectly() {
        assertEquals(ContentType.URL, parse("https://a.com").type)
        assertEquals(ContentType.WIFI, parse("WIFI:S:x;;").type)
        assertEquals(ContentType.BARCODE, parse("123", CodeFormat.CODE_39).type)
    }
}
