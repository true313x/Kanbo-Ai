package com.qrx.scanner.domain

import com.qrx.scanner.domain.parser.TextCodec
import org.junit.Assert.assertEquals
import org.junit.Test

class TextCodecTest {

    @Test
    fun percentEncodeEscapesReservedAndNonAscii() {
        assertEquals("Hello%20World%20%26%20more", TextCodec.percentEncode("Hello World & more"))
        assertEquals("%D9%85%D8%B1%D8%AD%D8%A8%D8%A7", TextCodec.percentEncode("مرحبا"))
        assertEquals("a-b_c.d~e", TextCodec.percentEncode("a-b_c.d~e"))
    }

    @Test
    fun percentDecodeRoundTrips() {
        val original = "Zürich café — مرحبا & 100%"
        assertEquals(original, TextCodec.percentDecode(TextCodec.percentEncode(original)))
    }

    @Test
    fun percentDecodeKeepsMalformedSequences() {
        assertEquals("100%", TextCodec.percentDecode("100%"))
        assertEquals("50%zz", TextCodec.percentDecode("50%zz"))
    }

    @Test
    fun queryKeysAreLowerCasedAndValuesDecoded() {
        val query = TextCodec.parseQuery("Subject=Hi%20there&BODY=a&flag")
        assertEquals("Hi there", query["subject"])
        assertEquals("a", query["body"])
        assertEquals("", query["flag"])
    }

    @Test
    fun arabicIndicDigitsAreNormalised() {
        assertEquals("0123456789", TextCodec.normalizeDigits("٠١٢٣٤٥٦٧٨٩"))
        assertEquals("0123456789", TextCodec.normalizeDigits("۰۱۲۳۴۵۶۷۸۹"))
        assertEquals("37.7749", TextCodec.normalizeDigits("٣٧٫٧٧٤٩"))
    }
}
