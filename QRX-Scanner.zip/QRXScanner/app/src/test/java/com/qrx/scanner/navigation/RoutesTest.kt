package com.qrx.scanner.navigation

import com.qrx.scanner.domain.model.CodeFormat
import com.qrx.scanner.domain.model.ScanSource
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Test

/** Type-safe navigation serialises routes with kotlinx.serialization; this keeps them encodable. */
class RoutesTest {

    @Test
    fun resultRouteRoundTripsWithUnicodeAndLargePayloads() {
        val route = ResultRoute(
            historyId = 12,
            rawValue = "مرحبا " + "x".repeat(2500),
            format = CodeFormat.PDF_417.name,
            source = ScanSource.GALLERY.name,
            fresh = true,
        )
        val json = Json.encodeToString(ResultRoute.serializer(), route)
        assertEquals(route, Json.decodeFromString(ResultRoute.serializer(), json))
    }

    @Test
    fun resultRouteDefaultsDescribeAFreshCameraScanOfNothing() {
        val route = ResultRoute()
        assertEquals(0L, route.historyId)
        assertEquals(CodeFormat.QR_CODE.name, route.format)
        assertEquals(ScanSource.CAMERA.name, route.source)
        assertEquals(false, route.fresh)
    }

    @Test
    fun otherRoutesRoundTrip() {
        val image = ImageScanRoute("content://media/picker/0/1")
        assertEquals(image, Json.decodeFromString(ImageScanRoute.serializer(), Json.encodeToString(ImageScanRoute.serializer(), image)))
        val generator = GeneratorRoute("WIFI")
        assertEquals(generator, Json.decodeFromString(GeneratorRoute.serializer(), Json.encodeToString(GeneratorRoute.serializer(), generator)))
    }
}
