package com.qrx.scanner.generator

import com.qrx.scanner.domain.model.CodeFormat
import com.qrx.scanner.domain.model.ParsedContent
import com.qrx.scanner.domain.model.WifiSecurity
import com.qrx.scanner.domain.parser.ContentParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class QrPayloadBuilderTest {

    private val builder = QrPayloadBuilder()

    private fun payload(input: CreateInput): String =
        (builder.build(input) as PayloadResult.Success).payload

    private fun error(input: CreateInput): InputError =
        (builder.build(input) as PayloadResult.Error).error

    @Test
    fun websiteGetsHttpsWhenSchemeIsMissing() {
        assertEquals("https://example.com", payload(CreateInput.Website("example.com")))
        assertEquals("http://example.com/a?b=1", payload(CreateInput.Website("  http://example.com/a?b=1 ")))
    }

    @Test
    fun invalidWebsitesAreRejected() {
        assertEquals(InputError.EMPTY, error(CreateInput.Website("  ")))
        assertEquals(InputError.INVALID_URL, error(CreateInput.Website("ftp://example.com")))
        assertEquals(InputError.INVALID_URL, error(CreateInput.Website("exa mple.com")))
        assertEquals(InputError.INVALID_URL, error(CreateInput.Website("nodot")))
        assertEquals(InputError.INVALID_URL, error(CreateInput.Website("javascript:alert(1)")))
    }

    @Test
    fun textIsKeptVerbatimAndLimited() {
        assertEquals("  keep  spaces ", payload(CreateInput.Text("  keep  spaces ")))
        assertEquals(InputError.EMPTY, error(CreateInput.Text("   ")))
        assertEquals(InputError.TOO_LONG, error(CreateInput.Text("x".repeat(2001))))
    }

    @Test
    fun wifiEscapesSpecialCharacters() {
        val result = payload(CreateInput.Wifi("My;Net", "p:w", WifiSecurity.WPA, hidden = false))
        assertEquals("WIFI:T:WPA;S:My\\;Net;P:p\\:w;;", result)
    }

    @Test
    fun openAndHiddenWifi() {
        assertEquals("WIFI:T:nopass;S:Cafe;;", payload(CreateInput.Wifi("Cafe", "", WifiSecurity.OPEN, false)))
        assertEquals("WIFI:T:SAE;S:Net;P:pw;H:true;;", payload(CreateInput.Wifi("Net", "pw", WifiSecurity.WPA3, true)))
    }

    @Test
    fun wifiValidation() {
        assertEquals(InputError.EMPTY, error(CreateInput.Wifi("", "", WifiSecurity.WPA, false)))
        assertEquals(InputError.MISSING_SSID, error(CreateInput.Wifi("", "pw", WifiSecurity.WPA, false)))
        assertEquals(InputError.MISSING_PASSWORD, error(CreateInput.Wifi("Net", "", WifiSecurity.WPA, false)))
    }

    @Test
    fun wifiPayloadParsesBackToTheSameNetwork() {
        val raw = payload(CreateInput.Wifi("Café; 5G", "pa:ss\\word", WifiSecurity.WPA, hidden = true))
        val parsed = ContentParser.parse(raw, CodeFormat.QR_CODE) as ParsedContent.Wifi
        assertEquals("Café; 5G", parsed.ssid)
        assertEquals("pa:ss\\word", parsed.password)
        assertTrue(parsed.hidden)
    }

    @Test
    fun phoneNumbersAreCleaned() {
        assertEquals("tel:+15550100100", payload(CreateInput.Phone("+1 (555) 010-0100")))
        assertEquals("tel:0123456789", payload(CreateInput.Phone("٠١٢٣٤٥٦٧٨٩")))
        assertEquals(InputError.INVALID_PHONE, error(CreateInput.Phone("abc")))
        assertEquals(InputError.EMPTY, error(CreateInput.Phone("")))
    }

    @Test
    fun emailIsPercentEncoded() {
        val result = payload(CreateInput.Email("a@b.com", "Hi there", "Body & more"))
        assertEquals("mailto:a@b.com?subject=Hi%20there&body=Body%20%26%20more", result)
        assertEquals("mailto:a@b.com", payload(CreateInput.Email("a@b.com", "", "")))
        assertEquals(InputError.INVALID_EMAIL, error(CreateInput.Email("not-an-email", "", "")))
    }

    @Test
    fun smsPayload() {
        assertEquals("sms:+15550100?body=Hello%20you", payload(CreateInput.Sms("+1 555 0100", "Hello you")))
        assertEquals("sms:+15550100", payload(CreateInput.Sms("+15550100", "")))
    }

    @Test
    fun locationPayload() {
        assertEquals(
            "geo:37.7749,-122.4194?q=Golden%20Gate",
            payload(CreateInput.Location("37.7749", "-122.4194", "Golden Gate")),
        )
        assertEquals("geo:37.7749,10", payload(CreateInput.Location("37,7749", "10.0", "")))
        assertEquals("geo:0,0", payload(CreateInput.Location("0", "-0", "")))
    }

    @Test
    fun locationRangeIsValidated() {
        assertEquals(InputError.INVALID_COORDINATES, error(CreateInput.Location("91", "0", "")))
        assertEquals(InputError.INVALID_COORDINATES, error(CreateInput.Location("0", "181", "")))
        assertEquals(InputError.INVALID_COORDINATES, error(CreateInput.Location("abc", "0", "")))
        assertEquals(InputError.EMPTY, error(CreateInput.Location("", "", "")))
    }

    @Test
    fun contactBecomesAVCardThatParsesBack() {
        val input = CreateInput.Contact(
            name = "Jane Doe",
            phone = "+1 555 123 4567",
            email = "jane@acme.com",
            organization = "Acme, Inc.",
            jobTitle = "Engineer",
            address = "1 Main St; Springfield",
            website = "acme.com",
            note = "Met at the expo",
        )
        val raw = payload(input)
        assertTrue(raw.startsWith("BEGIN:VCARD\nVERSION:3.0\nN:Doe;Jane;;;\nFN:Jane Doe\n"))
        assertTrue(raw.endsWith("END:VCARD"))

        val parsed = ContentParser.parse(raw, CodeFormat.QR_CODE) as ParsedContent.Contact
        assertEquals("Jane Doe", parsed.name)
        assertEquals(listOf("+15551234567"), parsed.phones)
        assertEquals(listOf("jane@acme.com"), parsed.emails)
        assertEquals("Acme, Inc.", parsed.organization)
        assertEquals("https://acme.com", parsed.website)
    }

    @Test
    fun contactNeedsAName() {
        val input = CreateInput.Contact("", "+15551234567", "", "", "", "", "", "")
        assertEquals(InputError.MISSING_NAME, error(input))
        assertEquals(InputError.EMPTY, error(CreateInput.Contact("", "", "", "", "", "", "", "")))
    }
}
