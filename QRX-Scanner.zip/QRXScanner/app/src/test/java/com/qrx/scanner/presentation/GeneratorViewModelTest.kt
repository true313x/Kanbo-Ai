package com.qrx.scanner.presentation

import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.SavedStateHandle
import com.qrx.scanner.domain.model.WifiSecurity
import com.qrx.scanner.generator.ErrorCorrection
import com.qrx.scanner.generator.ExportResult
import com.qrx.scanner.generator.InputError
import com.qrx.scanner.generator.LogoLoader
import com.qrx.scanner.generator.QrCodeEncoder
import com.qrx.scanner.generator.QrExporter
import com.qrx.scanner.generator.QrMatrix
import com.qrx.scanner.generator.QrPayloadBuilder
import com.qrx.scanner.generator.QrStyle
import com.qrx.scanner.generator.Readability
import com.qrx.scanner.generator.ReadabilityEvaluator
import com.qrx.scanner.presentation.generator.GeneratorEvent
import com.qrx.scanner.presentation.generator.GeneratorField
import com.qrx.scanner.presentation.generator.GeneratorType
import com.qrx.scanner.presentation.generator.GeneratorViewModel
import com.qrx.scanner.testutil.FixedTimeProvider
import com.qrx.scanner.testutil.MainDispatcherRule
import com.qrx.scanner.testutil.TestDispatcherProvider
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class GeneratorViewModelTest {

    private val dispatcher = UnconfinedTestDispatcher()

    @get:Rule
    val mainRule = MainDispatcherRule(dispatcher)

    private class RecordingExporter(private val result: ExportResult) : QrExporter {
        var galleryCalls = 0

        override suspend fun saveToGallery(matrix: QrMatrix, style: QrStyle, logo: Bitmap?, fileName: String): ExportResult {
            galleryCalls++
            return result
        }

        override suspend fun saveToDocument(uri: Uri, matrix: QrMatrix, style: QrStyle, logo: Bitmap?): ExportResult = result
        override suspend fun createShareUri(matrix: QrMatrix, style: QrStyle, logo: Bitmap?): ExportResult = result
    }

    private object NoLogo : LogoLoader {
        override suspend fun load(uri: Uri): Bitmap? = null
    }

    private fun viewModel(
        type: GeneratorType,
        exporter: QrExporter = RecordingExporter(ExportResult.Failure),
    ) = GeneratorViewModel(
        savedStateHandle = SavedStateHandle(mapOf("type" to type.name)),
        payloadBuilder = QrPayloadBuilder(),
        generator = QrCodeEncoder(),
        evaluator = ReadabilityEvaluator(),
        exporter = exporter,
        logoLoader = NoLogo,
        dispatchers = TestDispatcherProvider(dispatcher),
        time = FixedTimeProvider(42L),
    )

    @Test
    fun emptyFormShowsNeitherCodeNorError() = runTest {
        val viewModel = viewModel(GeneratorType.WEBSITE)
        val state = viewModel.state.value
        assertNull(state.matrix)
        assertNull(state.error)
    }

    @Test
    fun validInputProducesACodeWithReadability() = runTest {
        val viewModel = viewModel(GeneratorType.WEBSITE)

        viewModel.setField(GeneratorField.WEBSITE_URL, "example.com")

        val state = viewModel.state.value
        assertNotNull(state.matrix)
        assertNull(state.error)
        assertEquals(Readability.GOOD, state.readability)
    }

    @Test
    fun invalidInputShowsAnErrorAndNoCode() = runTest {
        val viewModel = viewModel(GeneratorType.WEBSITE)

        viewModel.setField(GeneratorField.WEBSITE_URL, "not a site")

        val state = viewModel.state.value
        assertNull(state.matrix)
        assertEquals(InputError.INVALID_URL, state.error)
    }

    @Test
    fun clearingTheFieldRemovesTheErrorAgain() = runTest {
        val viewModel = viewModel(GeneratorType.PHONE)
        viewModel.setField(GeneratorField.PHONE, "abc")
        assertEquals(InputError.INVALID_PHONE, viewModel.state.value.error)

        viewModel.setField(GeneratorField.PHONE, "")

        assertNull(viewModel.state.value.error)
        assertNull(viewModel.state.value.matrix)
    }

    @Test
    fun wifiFormUsesSecurityAndPassword() = runTest {
        val viewModel = viewModel(GeneratorType.WIFI)
        viewModel.setField(GeneratorField.SSID, "Home")

        assertEquals(InputError.MISSING_PASSWORD, viewModel.state.value.error)

        viewModel.setWifiSecurity(WifiSecurity.OPEN)
        assertNotNull(viewModel.state.value.matrix)
        assertNull(viewModel.state.value.error)
    }

    @Test
    fun identicalColoursAreReportedAsUnreadable() = runTest {
        val viewModel = viewModel(GeneratorType.TEXT)
        viewModel.setField(GeneratorField.TEXT, "hello")

        viewModel.setForeground(0)
        viewModel.setBackground(5)

        assertEquals(Readability.POOR, viewModel.state.value.readability)
    }

    @Test
    fun outOfRangeColourIndexesAreIgnored() = runTest {
        val viewModel = viewModel(GeneratorType.TEXT)
        viewModel.setForeground(99)
        viewModel.setBackground(-1)
        assertEquals(0, viewModel.state.value.foregroundIndex)
        assertEquals(0, viewModel.state.value.backgroundIndex)
    }

    @Test
    fun errorCorrectionAndSizeAreAppliedToTheStyle() = runTest {
        val viewModel = viewModel(GeneratorType.TEXT)

        viewModel.setErrorCorrection(ErrorCorrection.QUARTILE)
        viewModel.setSize(2048)

        val style = viewModel.state.value.style
        assertEquals(ErrorCorrection.QUARTILE, style.errorCorrection)
        assertEquals(2048, style.sizePx)
    }

    @Test
    fun regenerateBumpsTheGenerationCounter() = runTest {
        val viewModel = viewModel(GeneratorType.TEXT)
        viewModel.setField(GeneratorField.TEXT, "hello")
        val before = viewModel.state.value.generation

        viewModel.regenerateWithAnimation()

        assertEquals(before + 1, viewModel.state.value.generation)
        assertNotNull(viewModel.state.value.matrix)
    }

    @Test
    fun exportDoesNothingWithoutACode() = runTest {
        val exporter = RecordingExporter(ExportResult.Failure)
        val viewModel = viewModel(GeneratorType.TEXT, exporter)
        val events = mutableListOf<GeneratorEvent>()
        viewModel.events.onEach { events += it }.launchIn(backgroundScope)

        viewModel.saveToGallery()

        assertEquals(0, exporter.galleryCalls)
        assertTrue(events.isEmpty())
    }

    @Test
    fun failedExportIsReported() = runTest {
        val exporter = RecordingExporter(ExportResult.Failure)
        val viewModel = viewModel(GeneratorType.TEXT, exporter)
        viewModel.setField(GeneratorField.TEXT, "hello")
        val events = mutableListOf<GeneratorEvent>()
        viewModel.events.onEach { events += it }.launchIn(backgroundScope)

        viewModel.saveToGallery()

        assertEquals(1, exporter.galleryCalls)
        assertEquals(listOf<GeneratorEvent>(GeneratorEvent.ExportFailed), events)
    }

    @Test
    fun fileNameIsDerivedFromTheClock() = runTest {
        assertEquals("qrx-42.png", viewModel(GeneratorType.TEXT).suggestedFileName())
    }
}
