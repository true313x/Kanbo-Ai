package com.qrx.scanner.testutil

import com.qrx.scanner.core.DispatcherProvider
import com.qrx.scanner.core.TimeProvider
import com.qrx.scanner.domain.model.AppSettings
import com.qrx.scanner.domain.model.CodeFormat
import com.qrx.scanner.domain.model.ContentType
import com.qrx.scanner.domain.model.ScanMode
import com.qrx.scanner.domain.model.ScanRecord
import com.qrx.scanner.domain.model.SearchEngine
import com.qrx.scanner.domain.model.ThemeMode
import com.qrx.scanner.domain.repository.HistoryRepository
import com.qrx.scanner.domain.repository.SettingsRepository
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.test.TestDispatcher
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.rules.TestWatcher
import org.junit.runner.Description

class FakeHistoryRepository(initial: List<ScanRecord> = emptyList()) : HistoryRepository {
    private val records = MutableStateFlow(initial)
    private var nextId = (initial.maxOfOrNull { it.id } ?: 0L) + 1L

    val snapshot: List<ScanRecord> get() = records.value

    override fun observeAll(): Flow<List<ScanRecord>> =
        records.map { list -> list.sortedWith(compareByDescending<ScanRecord> { it.createdAt }.thenByDescending { it.id }) }

    override fun observeFavorites(): Flow<List<ScanRecord>> =
        observeAll().map { list -> list.filter { it.isFavorite } }

    override fun observeById(id: Long): Flow<ScanRecord?> = records.map { list -> list.firstOrNull { it.id == id } }

    override suspend fun getById(id: Long): ScanRecord? = records.value.firstOrNull { it.id == id }

    override suspend fun save(record: ScanRecord): Long {
        val id = if (record.id > 0L) record.id else nextId++
        records.update { list -> list.filterNot { it.id == id } + record.copy(id = id) }
        return id
    }

    override suspend fun setFavorite(id: Long, favorite: Boolean) {
        records.update { list -> list.map { if (it.id == id) it.copy(isFavorite = favorite) else it } }
    }

    override suspend fun delete(id: Long) {
        records.update { list -> list.filterNot { it.id == id } }
    }

    override suspend fun deleteAll() {
        records.value = emptyList()
    }
}

class FakeSettingsRepository(initial: AppSettings = AppSettings()) : SettingsRepository {
    private val state = MutableStateFlow(initial)
    override val settings: Flow<AppSettings> = state

    override suspend fun setThemeMode(mode: ThemeMode) = state.update { it.copy(themeMode = mode) }
    override suspend fun setScanSound(enabled: Boolean) = state.update { it.copy(scanSound = enabled) }
    override suspend fun setHaptics(enabled: Boolean) = state.update { it.copy(haptics = enabled) }
    override suspend fun setAutoOpenLinks(enabled: Boolean) = state.update { it.copy(autoOpenLinks = enabled) }
    override suspend fun setAutoSaveHistory(enabled: Boolean) = state.update { it.copy(autoSaveHistory = enabled) }
    override suspend fun setScanMode(mode: ScanMode) = state.update { it.copy(scanMode = mode) }
    override suspend fun setSearchEngine(engine: SearchEngine) = state.update { it.copy(searchEngine = engine) }
}

class FixedTimeProvider(var now: Long = 1_700_000_000_000L) : TimeProvider {
    override fun nowMillis(): Long = now
}

class TestDispatcherProvider(private val dispatcher: CoroutineDispatcher) : DispatcherProvider {
    override val main: CoroutineDispatcher = dispatcher
    override val default: CoroutineDispatcher = dispatcher
    override val io: CoroutineDispatcher = dispatcher
}

/** Replaces Dispatchers.Main so that `viewModelScope` works in plain JVM tests. */
@OptIn(ExperimentalCoroutinesApi::class)
class MainDispatcherRule(
    val dispatcher: TestDispatcher = UnconfinedTestDispatcher(),
) : TestWatcher() {
    override fun starting(description: Description) {
        Dispatchers.setMain(dispatcher)
    }

    override fun finished(description: Description) {
        Dispatchers.resetMain()
    }
}

fun record(
    id: Long = 0L,
    type: ContentType = ContentType.TEXT,
    raw: String = "value",
    display: String = raw,
    format: CodeFormat = CodeFormat.QR_CODE,
    createdAt: Long = 1_000L,
    favorite: Boolean = false,
): ScanRecord = ScanRecord(
    id = id,
    type = type,
    rawValue = raw,
    displayValue = display,
    format = format,
    createdAt = createdAt,
    isFavorite = favorite,
    metadata = emptyMap(),
)
