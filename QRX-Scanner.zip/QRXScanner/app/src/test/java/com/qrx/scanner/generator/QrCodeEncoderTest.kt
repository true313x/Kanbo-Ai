package com.qrx.scanner.generator

import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeReader
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class QrCodeEncoderTest {

    private val encoder = QrCodeEncoder()

    private fun encode(payload: String, level: ErrorCorrection = ErrorCorrection.MEDIUM): QrMatrix =
        (encoder.generate(payload, level) as QrGenerationResult.Success).matrix

    /** Renders the matrix at 6 px per module and decodes it again, exactly like a camera would see it. */
    private fun decode(matrix: QrMatrix): String {
        val scale = 6
        val side = matrix.size * scale
        val pixels = IntArray(side * side) { WHITE }
        for (y in 0 until side) {
            for (x in 0 until side) {
                if (matrix[x / scale, y / scale]) pixels[y * side + x] = BLACK
            }
        }
        val bitmap = BinaryBitmap(HybridBinarizer(RGBLuminanceSource(side, side, pixels)))
        val hints = mapOf<DecodeHintType, Any>(DecodeHintType.TRY_HARDER to true)
        return QRCodeReader().decode(bitmap, hints).text
    }

    @Test
    fun urlRoundTrips() {
        val matrix = encode("https://example.com/path?x=1")
        assertEquals("https://example.com/path?x=1", decode(matrix))
    }

    @Test
    fun matrixKeepsAFourModuleQuietZone() {
        val matrix = encode("hello")
        assertEquals(4, matrix.quietZone)
        assertEquals(matrix.size - 8, matrix.dataSize)
        for (i in 0 until matrix.size) {
            for (edge in 0 until 4) {
                assertTrue(!matrix[i, edge] && !matrix[edge, i])
                assertTrue(!matrix[i, matrix.size - 1 - edge] && !matrix[matrix.size - 1 - edge, i])
            }
        }
    }

    @Test
    fun arabicTextRoundTripsAsUtf8() {
        val text = "مرحبا بالعالم"
        assertEquals(text, decode(encode(text, ErrorCorrection.HIGH)))
    }

    @Test
    fun everyErrorCorrectionLevelDecodes() {
        for (level in ErrorCorrection.entries) {
            assertEquals(level.name, "QRX-${level.name}", decode(encode("QRX-${level.name}", level)))
        }
    }

    @Test
    fun strongerCorrectionNeverShrinksTheCode() {
        val payload = "https://example.com/some/longer/address?with=parameters&and=more"
        assertTrue(encode(payload, ErrorCorrection.HIGH).size >= encode(payload, ErrorCorrection.LOW).size)
    }

    @Test
    fun emptyPayloadFails() {
        val result = encoder.generate("", ErrorCorrection.MEDIUM)
        assertEquals(QrGenerationResult.Failure(GenerationFailure.EMPTY), result)
    }

    @Test
    fun oversizedPayloadFails() {
        val result = encoder.generate("a".repeat(6000), ErrorCorrection.MEDIUM)
        assertEquals(QrGenerationResult.Failure(GenerationFailure.TOO_MUCH_DATA), result)
    }

    private companion object {
        const val BLACK = 0xFF000000.toInt()
        const val WHITE = 0xFFFFFFFF.toInt()
    }
}
