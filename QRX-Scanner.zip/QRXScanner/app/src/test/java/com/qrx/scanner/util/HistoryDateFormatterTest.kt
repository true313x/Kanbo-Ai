package com.qrx.scanner.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.util.Locale

class HistoryDateFormatterTest {

    private val zone = ZoneOffset.UTC
    private val now = ZonedDateTime.of(2026, 10, 9, 12, 0, 0, 0, zone).toInstant().toEpochMilli()

    private fun format(year: Int, month: Int, day: Int, hour: Int, minute: Int): String {
        val timestamp = ZonedDateTime.of(year, month, day, hour, minute, 0, 0, zone).toInstant().toEpochMilli()
        return HistoryDateFormatter.format(timestamp, now, Locale.US, "Today", "Yesterday", zone)
    }

    @Test
    fun sameDayIsToday() {
        val text = format(2026, 10, 9, 10, 32)
        assertTrue(text, text.startsWith("Today • 10:32"))
    }

    @Test
    fun previousDayIsYesterday() {
        val text = format(2026, 10, 8, 23, 5)
        assertTrue(text, text.startsWith("Yesterday • 11:05"))
    }

    @Test
    fun earlierThisYearShowsDayAndMonth() {
        val text = format(2026, 10, 3, 8, 15)
        assertTrue(text, text.startsWith("3 Oct • 8:15"))
    }

    @Test
    fun earlierYearsAlsoShowTheYear() {
        val text = format(2025, 1, 5, 9, 0)
        assertTrue(text, text.startsWith("5 Jan 2025 • 9:00"))
    }

    @Test
    fun midnightBelongsToTheNewDay() {
        val text = format(2026, 10, 9, 0, 0)
        assertTrue(text, text.startsWith("Today • "))
        assertEquals(true, text.contains("12:00"))
    }
}
