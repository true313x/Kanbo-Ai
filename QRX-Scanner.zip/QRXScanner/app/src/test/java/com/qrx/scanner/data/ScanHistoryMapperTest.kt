package com.qrx.scanner.data

import com.qrx.scanner.data.mapper.ScanHistoryMapper
import com.qrx.scanner.database.ScanHistory
import com.qrx.scanner.domain.model.CodeFormat
import com.qrx.scanner.domain.model.ContentType
import com.qrx.scanner.domain.model.ScanRecord
import org.junit.Assert.assertEquals
import org.junit.Test

class ScanHistoryMapperTest {

    @Test
    fun recordSurvivesARoundTripThroughTheEntity() {
        val record = ScanRecord(
            id = 7,
            type = ContentType.WIFI,
            rawValue = "WIFI:S:Café \"5G\";;",
            displayValue = "Café \"5G\"",
            format = CodeFormat.QR_CODE,
            createdAt = 99L,
            isFavorite = true,
            metadata = mapOf("ssid" to "Café \"5G\"", "note" to "line1\nline2", "arabic" to "مرحبا"),
        )
        assertEquals(record, ScanHistoryMapper.toDomain(ScanHistoryMapper.toEntity(record)))
    }

    @Test
    fun unknownTypeAndFormatDegradeGracefully() {
        val entity = ScanHistory(1, "FUTURE_TYPE", "raw", "raw", "FUTURE_FORMAT", 5L, false, "{}")
        val record = ScanHistoryMapper.toDomain(entity)
        assertEquals(ContentType.TEXT, record.type)
        assertEquals(CodeFormat.QR_CODE, record.format)
    }

    @Test
    fun corruptMetadataBecomesEmpty() {
        val entity = ScanHistory(1, "TEXT", "raw", "raw", "QR_CODE", 5L, false, "not json")
        assertEquals(emptyMap<String, String>(), ScanHistoryMapper.toDomain(entity).metadata)
    }
}
