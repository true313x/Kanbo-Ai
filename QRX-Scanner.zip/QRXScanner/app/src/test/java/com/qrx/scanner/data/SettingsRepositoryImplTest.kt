package com.qrx.scanner.data

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.qrx.scanner.data.settings.SettingsRepositoryImpl
import com.qrx.scanner.domain.model.AppSettings
import com.qrx.scanner.domain.model.ScanMode
import com.qrx.scanner.domain.model.SearchEngine
import com.qrx.scanner.domain.model.ThemeMode
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class SettingsRepositoryImplTest {

    @get:Rule
    val folder = TemporaryFolder()

    private fun TestScope.createRepository(name: String = "settings.preferences_pb"): Pair<SettingsRepositoryImpl, DataStore<Preferences>> {
        val dataStore = PreferenceDataStoreFactory.create(scope = backgroundScope) { File(folder.root, name) }
        return SettingsRepositoryImpl(dataStore) to dataStore
    }

    @Test
    fun defaultsAreUsedWhenNothingIsStored() = runTest {
        val (repository, _) = createRepository()
        assertEquals(AppSettings(), repository.settings.first())
    }

    @Test
    fun everySettingIsPersisted() = runTest {
        val (repository, _) = createRepository()

        repository.setThemeMode(ThemeMode.DARK)
        repository.setScanSound(false)
        repository.setHaptics(false)
        repository.setAutoOpenLinks(true)
        repository.setAutoSaveHistory(false)
        repository.setScanMode(ScanMode.QR_ONLY)
        repository.setSearchEngine(SearchEngine.DUCKDUCKGO)

        assertEquals(
            AppSettings(
                themeMode = ThemeMode.DARK,
                scanSound = false,
                haptics = false,
                autoOpenLinks = true,
                autoSaveHistory = false,
                scanMode = ScanMode.QR_ONLY,
                searchEngine = SearchEngine.DUCKDUCKGO,
            ),
            repository.settings.first(),
        )
    }

    @Test
    fun unknownStoredEnumValuesFallBackToDefaults() = runTest {
        val (repository, dataStore) = createRepository()
        dataStore.edit { it[stringPreferencesKey("theme_mode")] = "NEON" }
        dataStore.edit { it[stringPreferencesKey("scan_mode")] = "???" }

        val settings = repository.settings.first()
        assertEquals(ThemeMode.SYSTEM, settings.themeMode)
        assertEquals(ScanMode.AUTO, settings.scanMode)
    }
}
