package com.qrx.scanner.generator

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ReadabilityEvaluatorTest {

    private val evaluator = ReadabilityEvaluator()
    private val encoder = QrCodeEncoder()

    private fun matrix(level: ErrorCorrection = ErrorCorrection.MEDIUM): QrMatrix =
        (encoder.generate("https://example.com/readability", level) as QrGenerationResult.Success).matrix

    @Test
    fun blackOnWhiteIsGood() {
        assertEquals(Readability.GOOD, evaluator.evaluate(matrix(), BLACK, WHITE, hasLogo = false))
    }

    @Test
    fun brandInkOnWhiteIsGood() {
        assertEquals(Readability.GOOD, evaluator.evaluate(matrix(), 0xFF12152B.toInt(), WHITE, hasLogo = false))
    }

    @Test
    fun sameColourIsPoor() {
        assertEquals(Readability.POOR, evaluator.evaluate(matrix(), 0xFF12152B.toInt(), 0xFF12152B.toInt(), false))
    }

    @Test
    fun veryLowContrastIsPoor() {
        assertEquals(Readability.POOR, evaluator.evaluate(matrix(), 0xFFCCCCCC.toInt(), WHITE, false))
    }

    @Test
    fun mediumContrastIsRisky() {
        assertEquals(Readability.RISKY, evaluator.evaluate(matrix(), 0xFF9A9A9A.toInt(), WHITE, false))
    }

    @Test
    fun invertedCodesAreRiskyBecauseManyScannersIgnoreThem() {
        assertEquals(Readability.RISKY, evaluator.evaluate(matrix(), WHITE, BLACK, false))
    }

    @Test
    fun smallLogoOnHighCorrectionStaysReadable() {
        val result = evaluator.evaluate(matrix(ErrorCorrection.HIGH), BLACK, WHITE, hasLogo = true)
        assertNotEquals(Readability.POOR, result)
    }

    @Test
    fun contrastRatioMatchesWcagReferenceValues() {
        assertEquals(21.0, ReadabilityEvaluator.contrastRatio(BLACK, WHITE), 0.01)
        assertEquals(1.0, ReadabilityEvaluator.contrastRatio(WHITE, WHITE), 0.0001)
        assertTrue(ReadabilityEvaluator.contrastRatio(0xFF767676.toInt(), WHITE) >= 4.5)
    }

    private companion object {
        const val BLACK = 0xFF000000.toInt()
        const val WHITE = 0xFFFFFFFF.toInt()
    }
}
