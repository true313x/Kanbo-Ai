package com.qrx.scanner.scanner

import com.google.zxing.BarcodeFormat
import com.qrx.scanner.domain.model.CodeFormat
import com.qrx.scanner.domain.model.ScanMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FormatMapperTest {

    @Test
    fun allThirteenFormatsAreSupported() {
        assertEquals(13, CodeFormat.entries.size)
    }

    @Test
    fun mlKitMappingRoundTrips() {
        for (format in CodeFormat.entries) {
            assertEquals(format, BarcodeFormatMapper.toCodeFormat(BarcodeFormatMapper.toMlKitFormat(format)))
        }
    }

    @Test
    fun mlKitUnknownFormatMapsToNull() {
        assertNull(BarcodeFormatMapper.toCodeFormat(-1))
    }

    @Test
    fun zxingMappingRoundTrips() {
        for (format in CodeFormat.entries) {
            assertEquals(format, ZxingFormatMapper.toCodeFormat(ZxingFormatMapper.toZxing(format)))
        }
    }

    @Test
    fun zxingUnsupportedFormatsMapToNull() {
        assertNull(ZxingFormatMapper.toCodeFormat(BarcodeFormat.MAXICODE))
        assertNull(ZxingFormatMapper.toCodeFormat(BarcodeFormat.RSS_14))
    }

    @Test
    fun scanModesSelectTheRightFormats() {
        assertEquals(CodeFormat.entries.toList(), BarcodeFormatMapper.formatsFor(ScanMode.AUTO))
        assertEquals(listOf(CodeFormat.QR_CODE), BarcodeFormatMapper.formatsFor(ScanMode.QR_ONLY))
        val barcodes = BarcodeFormatMapper.formatsFor(ScanMode.BARCODE_ONLY)
        assertFalse(CodeFormat.QR_CODE in barcodes)
        assertEquals(12, barcodes.size)
    }

    @Test
    fun twoDimensionalFlagMatchesTheSymbology() {
        assertTrue(CodeFormat.QR_CODE.isTwoDimensional)
        assertTrue(CodeFormat.PDF_417.isTwoDimensional)
        assertTrue(CodeFormat.EAN_13.isOneDimensional)
        assertTrue(CodeFormat.CODE_128.isOneDimensional)
    }

    @Test
    fun namesRoundTrip() {
        for (format in CodeFormat.entries) assertEquals(format, CodeFormat.fromName(format.name))
        assertNull(CodeFormat.fromName("nope"))
    }
}
