package com.qrx.scanner.database

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ScanHistoryDaoTest {

    private lateinit var database: QrxDatabase
    private lateinit var dao: ScanHistoryDao

    @Before
    fun createDatabase() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, QrxDatabase::class.java).allowMainThreadQueries().build()
        dao = database.scanHistoryDao()
    }

    @After
    fun closeDatabase() {
        database.close()
    }

    private fun entity(raw: String, createdAt: Long, favorite: Boolean = false) = ScanHistory(
        type = "TEXT",
        rawValue = raw,
        displayValue = raw,
        format = "QR_CODE",
        createdAt = createdAt,
        isFavorite = favorite,
        metadata = "{}",
    )

    @Test
    fun insertGeneratesIdsAndReadsBack() = runBlocking {
        val first = dao.upsert(entity("a", 1))
        val second = dao.upsert(entity("b", 2))

        assertTrue(second > first)
        assertEquals("a", dao.getById(first)?.rawValue)
    }

    @Test
    fun allScansAreOrderedNewestFirst() = runBlocking {
        dao.upsert(entity("old", 1))
        dao.upsert(entity("new", 3))
        dao.upsert(entity("mid", 2))

        assertEquals(listOf("new", "mid", "old"), dao.observeAll().first().map { it.rawValue })
    }

    @Test
    fun favoritesAreFilteredAndToggled() = runBlocking {
        val id = dao.upsert(entity("a", 1))
        dao.upsert(entity("b", 2, favorite = true))

        assertEquals(listOf("b"), dao.observeFavorites().first().map { it.rawValue })

        dao.setFavorite(id, true)
        assertEquals(2, dao.observeFavorites().first().size)

        dao.setFavorite(id, false)
        assertEquals(listOf("b"), dao.observeFavorites().first().map { it.rawValue })
    }

    @Test
    fun upsertWithTheSameIdReplacesTheRow() = runBlocking {
        val id = dao.upsert(entity("a", 1))
        dao.upsert(entity("changed", 1).copy(id = id))

        assertEquals(1, dao.observeAll().first().size)
        assertEquals("changed", dao.getById(id)?.rawValue)
    }

    @Test
    fun deleteRemovesOneRowAndDeleteAllRemovesEverything() = runBlocking {
        val id = dao.upsert(entity("a", 1))
        dao.upsert(entity("b", 2))

        dao.deleteById(id)
        assertNull(dao.getById(id))
        assertEquals(1, dao.observeAll().first().size)

        dao.deleteAll()
        assertTrue(dao.observeAll().first().isEmpty())
    }

    @Test
    fun observeByIdEmitsNullForMissingRows() = runBlocking {
        assertNull(dao.observeById(404).first())
    }
}
