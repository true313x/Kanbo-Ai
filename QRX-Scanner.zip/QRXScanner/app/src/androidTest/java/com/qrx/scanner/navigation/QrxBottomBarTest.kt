package com.qrx.scanner.navigation

import androidx.compose.ui.test.assertIsSelected
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.qrx.scanner.domain.model.ThemeMode
import com.qrx.scanner.ui.theme.QrxTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class QrxBottomBarTest {

    @get:Rule
    val composeRule = createComposeRule()

    private fun label(destination: TopLevelDestination): String =
        InstrumentationRegistry.getInstrumentation().targetContext.getString(destination.labelRes)

    @Test
    fun showsTheFourTabsAndMarksTheSelectedOne() {
        composeRule.setContent {
            QrxTheme(ThemeMode.LIGHT) {
                QrxBottomBar(selected = TopLevelDestination.HISTORY, onSelect = {})
            }
        }

        composeRule.onNodeWithText(label(TopLevelDestination.HISTORY)).assertIsSelected()
        for (destination in TopLevelDestination.entries) {
            composeRule.onNodeWithText(label(destination)).assertExists()
        }
    }

    @Test
    fun tappingATabReportsIt() {
        var selected: TopLevelDestination? = null
        composeRule.setContent {
            QrxTheme(ThemeMode.DARK) {
                QrxBottomBar(selected = TopLevelDestination.SCAN, onSelect = { selected = it })
            }
        }

        composeRule.onNodeWithText(label(TopLevelDestination.SETTINGS)).performClick()

        assertEquals(TopLevelDestination.SETTINGS, selected)
    }

    @Test
    fun navigationRailOffersTheSameTabs() {
        var selected: TopLevelDestination? = null
        composeRule.setContent {
            QrxTheme(ThemeMode.LIGHT) {
                QrxNavigationRail(selected = TopLevelDestination.SCAN, onSelect = { selected = it })
            }
        }

        composeRule.onNodeWithText(label(TopLevelDestination.CREATE)).performClick()

        assertEquals(TopLevelDestination.CREATE, selected)
    }
}
