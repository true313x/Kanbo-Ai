# QRX Scanner

A fast, private QR code and barcode scanner and generator for Android.
Open the app → the camera is already running → scan → result. Everything happens on the device.

> **Package:** `com.qrx.scanner` · **minSdk** 26 · **targetSdk** 36 · **compileSdk** 37 · Kotlin + Jetpack Compose + Material 3

## Features

**Scanner**
- Live camera scanning with CameraX and ML Kit (bundled model, works offline).
- All 13 formats: QR, Aztec, Data Matrix, PDF417, Codabar, Code 39, Code 93, Code 128, EAN-8, EAN-13, ITF, UPC-A, UPC-E.
- Scan modes: Auto, QR only, Barcode only.
- Pinch zoom, zoom presets, ML Kit auto-zoom, tap-to-focus, flash, front/back camera.
- Duplicate debouncing; linear barcodes must be seen twice before they are accepted (avoids misreads).
- Scan from a gallery image (system photo picker, no storage permission). Several codes in one image are listed.

**Results**
- Automatic type detection: link, text, Wi-Fi, contact (vCard / MECARD), phone, email, SMS, location, barcode.
- Per-type actions (open, connect, add contact, call, send, map, copy, share, search, save).
- Link safety check, fully offline: `javascript:`/`intent:`/`data:` and other non-web schemes are blocked, and warnings are
  raised for plain HTTP, IP-address hosts, punycode / look-alike characters, user-info tricks, URL shorteners, redirect
  parameters, suspicious endings, very long links. Nothing is ever opened automatically unless the user enabled
  *Open links automatically*, and then only for clean `https` links.

**History & favorites** — search, filters (All / QR / Barcode / URLs / Text / Wi-Fi / Contacts / Other), swipe right to
favorite, swipe left to delete (with Undo), delete all with confirmation.

**Create** — Website, Text, Wi-Fi, Contact, Phone, Email, SMS, Location. Customize colors, size and error correction,
add a logo. A real ZXing decode of the styled code drives the *Easy to scan / May be hard to scan / Likely won't scan* badge.
Save to `Pictures/QRX`, share, or copy the image.

**Settings** — theme (System/Light/Dark), language (English/العربية with full RTL), scan sound, haptics, auto-open links,
auto-save history, scan mode, search engine, privacy tools, about, licenses, privacy policy.

**Also** — splash screen API, adaptive + monochrome icon, tablet/foldable/landscape layouts (navigation rail ≥ 600 dp),
TalkBack labels, state kept across rotation and process death.

## Privacy

No account, no ads, no analytics, no trackers, no network permission. The only permission is `CAMERA`.
Backups are disabled. See [`docs/PRIVACY_POLICY.md`](docs/PRIVACY_POLICY.md).
QR content is treated as untrusted input: it is parsed, displayed and *offered* to other apps — never executed.

## Architecture

Single Gradle module, layered by package (Clean Architecture + MVVM, unidirectional data flow).

```
presentation ──► domain ◄── data
     │             ▲          │
     ▼             │          ▼
  scanner      generator   database / DataStore
```

| Package        | Responsibility                                                                                   |
|----------------|--------------------------------------------------------------------------------------------------|
| `domain`       | Pure Kotlin: models, `ContentParser`, `UrlSecurityAnalyzer`, use cases, repository interfaces.   |
| `data`         | Repository implementations, mappers, DataStore settings.                                         |
| `database`     | Room entity `ScanHistory`, DAO, database (schema exported to `app/schemas`).                     |
| `scanner`      | ML Kit analyzer, detection filter, gallery image scanning (ML Kit → ZXing fallback).             |
| `generator`    | Payload builder, ZXing encoder, readability evaluator, bitmap renderer, exporter.                |
| `security`     | URL checks live in `domain/security` (pure, unit-tested).                                        |
| `presentation` | Screens + ViewModels (`scanner`, `result`, `imagescan`, `history`, `favorites`, `create`, `generator`, `settings`, `document`). |
| `navigation`   | Type-safe `@Serializable` routes, NavHost, bottom bar / rail.                                    |
| `ui`           | Theme (tokens), reusable components, icons.                                                      |
| `core`         | DI modules, dispatchers, time provider, language manager, scan feedback.                         |

## Tech stack

Kotlin 2.3 · Jetpack Compose (BOM 2026.09.00) · Material 3 · Navigation Compose (type-safe routes) · Hilt ·
Room · DataStore · CameraX 1.6 · ML Kit Barcode Scanning 17.3 · ZXing core 3.5 · Coroutines/Flow ·
kotlinx.serialization · Android Gradle Plugin 9.4 (built-in Kotlin) · KSP. All versions live in
[`gradle/libs.versions.toml`](gradle/libs.versions.toml).

## Setup

Requirements: **Android Studio** (a release that supports AGP 9.4), **JDK 17**, Android SDK Platform **37**.

1. Open the project folder in Android Studio and let it sync (it downloads Gradle 9.6.0 from
   `gradle/wrapper/gradle-wrapper.properties`).
2. Optional: generate the wrapper scripts once if you want to build from a terminal:
   `gradle wrapper --gradle-version 9.6.0`
3. Run the `app` configuration on a device or emulator (a real device is best for the camera).

## Build

```bash
./gradlew assembleDebug          # debug APK
./gradlew bundleRelease          # release AAB (configure signing first)
./gradlew lint                   # Android lint
```

Release builds use R8 shrinking and resource shrinking (`app/proguard-rules.pro`). Configure your own signing
config (never commit keystores; `*.jks` / `*.keystore` are git-ignored).

## Testing

```bash
./gradlew test                   # JVM unit tests
./gradlew connectedAndroidTest   # instrumented tests (device / emulator)
```

Unit tests cover the content parser, URL security analyzer, payload builder, QR encoder (decode round trip),
readability evaluator, detection filter, format mappers, history filtering/date formatting, use cases,
DataStore settings, Room mapper, `HistoryViewModel`, `GeneratorViewModel` and route serialization.
Instrumented tests cover the Room DAO and the navigation bar. Hand-written fakes are used instead of a mocking library.

## Screenshots

See [`docs/screenshots`](docs/screenshots/README.md) — add images there:

| Scanner | Result | History | Generator |
|---------|--------|---------|-----------|
| _placeholder_ | _placeholder_ | _placeholder_ | _placeholder_ |

## Design notes

- Identity: midnight-indigo surfaces, one ultraviolet primary, and a cyan **scan beam** that is the only gradient in the app.
- The result screen is a torn "ticket" (side notches + dashed tear line) — the one deliberately memorable element.
- Letter-spacing is zero everywhere to protect Arabic letter joining; layouts use `start`/`end`, swipe actions use physical directions.

## License

[MIT](LICENSE)
