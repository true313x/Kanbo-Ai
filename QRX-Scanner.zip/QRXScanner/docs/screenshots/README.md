# Screenshots

Placeholders for the Play Store listing and the project README. Capture them on a Pixel-class device in
**both** light and dark themes, and in **English and Arabic (RTL)**.

| File                      | Screen                                       |
|---------------------------|----------------------------------------------|
| `01-scanner.png`          | Scanner with the viewfinder and scan beam    |
| `02-result-url.png`       | Result "ticket" for a link with security note |
| `03-result-wifi.png`      | Wi-Fi result with Connect / Copy password    |
| `04-history.png`          | History with filters and a swipe in progress |
| `05-create.png`           | Create: choose a type                        |
| `06-generator.png`        | QR generator with style options              |
| `07-settings.png`         | Settings                                     |
| `08-dark-rtl.png`         | Dark theme, Arabic, RTL layout               |
