# QRX Scanner — Privacy Policy

_Last updated: 2026-10-09_

This is the same text the app shows under **Settings → Privacy policy**. Host a copy at a public URL and
link it from the Google Play listing (Play Console → App content → Privacy policy).

## What we collect
Nothing. QRX Scanner does not collect, transmit or sell personal data. It contains no analytics,
advertising or tracking libraries and has no user accounts.

## What is stored on your device
Your scan history, favorites and settings are stored in the app's private storage. They are excluded from
cloud backup and device transfer, and are removed when you clear your history or uninstall the app.

## Permissions
- **Camera** — used only to detect codes while the scanner is open. No photos or video are saved or uploaded.

Images chosen from your gallery go through the Android system photo picker; the app never receives access
to your photo library.

## Sharing
Data leaves the app only when you tap an action such as Share, Open link, Call or Search web. The app you
choose then handles it under its own policy. The scanner, history and generator work fully offline.

## Your control
You can delete a single scan or your entire history at any time from the History and Settings screens.

## Changes and contact
If this policy changes, the updated version ships with a new app release. For questions, use the developer
contact shown on the app's Google Play page.

---

# سياسة الخصوصية — QRX Scanner

**ما الذي نجمعه:** لا شيء. لا يجمع التطبيق بيانات شخصية ولا يرسلها ولا يبيعها، ولا يحتوي على أدوات تحليلات أو إعلانات أو تتبّع.

**ما الذي يُخزَّن على جهازك:** سجل المسح والمفضلة والإعدادات في مساحة التطبيق الخاصة، وهي مستثناة من النسخ الاحتياطي السحابي، وتُحذف عند مسح السجل أو إزالة التطبيق.

**الأذونات:** الكاميرا فقط، وتُستخدم لالتقاط الرموز أثناء فتح الماسح. لا تُحفظ صور أو فيديو ولا تُرفع.

**المشاركة:** لا تغادر البيانات التطبيق إلا عندما تضغط على إجراء مثل مشاركة أو فتح الرابط أو اتصال أو بحث في الويب.

**تحكّمك:** يمكنك حذف أي مسح أو السجل كاملًا في أي وقت.
