# Build notes

## Toolchain (pinned in `gradle/libs.versions.toml`)

| Component            | Version        |
|----------------------|----------------|
| Android Gradle Plugin| 9.4.0 (built-in Kotlin, new DSL) |
| Gradle               | 9.6.0          |
| Kotlin               | 2.3.21         |
| KSP                  | 2.3.10         |
| Hilt / Dagger        | 2.60.1         |
| Compose BOM          | 2026.09.00     |
| compileSdk / targetSdk / minSdk | 37 / 36 / 26 |

AGP 9 has Kotlin built in, so `org.jetbrains.kotlin.android` is intentionally **not** applied; only the Compose compiler
and serialization plugins are. KSP must be ≥ 2.3.6 and Hilt ≥ 2.59.2 for AGP 9.

## Verification status

This project was authored in an environment **without** the Android SDK, a Kotlin compiler or network access, so
`./gradlew build`, `test` and `lint` have **not** been executed yet. What was verified statically:

- Every `R.string.*` reference resolves, and the Arabic file mirrors the English keys (no missing/unused strings).
- All XML resources are well-formed; the version catalog has no unused or missing aliases.
- Imports were checked for unused / unresolved names and brackets for balance.

Expected first-run chores: Gradle sync, accepting SDK licences, and possibly small compile fixes. If a library has
shipped a newer release, bump it in the catalog.

## `gradle-wrapper.jar`

Binary files cannot be generated here. Android Studio works without it; for terminal builds run
`gradle wrapper --gradle-version 9.6.0` once.
