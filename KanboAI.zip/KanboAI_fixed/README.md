# Kanbo AI

Local LLM chat for Android (llama.cpp, arm64).

1. `git submodule add https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp`
   (or `git submodule update --init --recursive`)
2. Open in Android Studio → Run (release build for full speed).

Diagnostics: Settings → Engine log (copy button). Each load prints stage markers:
`nativeInspect` → `nativeLoad: weights loaded` → `nativeLoad: ready`. The last marker shows where a failure happened.
