package ai.kanbo.app.models

import android.os.StatFs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class CatalogModel(val id: String, val name: String, val repo: String, val file: String, val sizeMb: Int, val minRamMb: Int)

val Catalog = listOf(
    CatalogModel("qwen25-05b", "Qwen2.5 0.5B", "Qwen/Qwen2.5-0.5B-Instruct-GGUF", "qwen2.5-0.5b-instruct-q4_k_m.gguf", 400, 2500),
    CatalogModel("llama32-1b", "Llama 3.2 1B", "bartowski/Llama-3.2-1B-Instruct-GGUF", "Llama-3.2-1B-Instruct-Q4_K_M.gguf", 810, 3500),
    CatalogModel("qwen25-15b", "Qwen2.5 1.5B", "Qwen/Qwen2.5-1.5B-Instruct-GGUF", "qwen2.5-1.5b-instruct-q4_k_m.gguf", 1100, 3500),
    CatalogModel("gemma2-2b", "Gemma 2 2B", "bartowski/gemma-2-2b-it-GGUF", "gemma-2-2b-it-Q4_K_M.gguf", 1700, 4500),
    CatalogModel("qwen25-3b", "Qwen2.5 3B", "Qwen/Qwen2.5-3B-Instruct-GGUF", "qwen2.5-3b-instruct-q4_k_m.gguf", 2100, 5500),
    CatalogModel("llama32-3b", "Llama 3.2 3B", "bartowski/Llama-3.2-3B-Instruct-GGUF", "Llama-3.2-3B-Instruct-Q4_K_M.gguf", 2000, 5500),
)

object ModelDownloader {
    private fun isGguf(f: File) = runCatching { f.inputStream().use { s -> ByteArray(4).also { s.read(it) } }.toString(Charsets.US_ASCII) == "GGUF" }.getOrDefault(false)

    /** Resumable download from Hugging Face; emits progress 0..1. The file is only published once it is a valid GGUF. */
    fun download(m: CatalogModel, dest: File, token: String? = null): Flow<Float> = flow {
        dest.parentFile!!.mkdirs()
        val part = File(dest.path + ".part")
        var have = if (part.exists()) part.length() else 0L
        val c = (URL("https://huggingface.co/${m.repo}/resolve/main/${m.file}").openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 30_000
            setRequestProperty("User-Agent", "KanboAI/0.1")
            if (have > 0) setRequestProperty("Range", "bytes=$have-")
            token?.let { setRequestProperty("Authorization", "Bearer $it") }
        }
        try {
            val code = c.responseCode
            if (code == 416) {   // the .part file is already complete
                if (!isGguf(part)) { part.delete(); throw IOException("Corrupt partial file, try again") }
                if (!part.renameTo(dest)) throw IOException("Cannot save model")
                emit(1f); return@flow
            }
            if (code != 200 && code != 206) throw IOException("HTTP $code")
            if (code == 200) have = 0   // server ignored the Range header: start over
            val len = c.contentLengthLong
            val total = if (len > 0) have + len else -1L
            if (len > 0 && len > StatFs(dest.parentFile!!.path).availableBytes - 200L * 1048576) throw IOException("No space")
            var done = have
            var last = -1f
            FileOutputStream(part, have > 0).use { out ->
                c.inputStream.use { inp ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = inp.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val p = done.toFloat() / total
                            if (p - last >= 0.005f) { last = p; emit(p.coerceAtMost(1f)) }
                        }
                    }
                }
            }
            if (total > 0 && part.length() != total) throw IOException("Incomplete download, try again")
            if (!isGguf(part)) { part.delete(); throw IOException("Downloaded file is not a valid GGUF") }
            if (!part.renameTo(dest)) throw IOException("Cannot save model")
            emit(1f)
        } finally {
            c.disconnect()
        }
    }.flowOn(Dispatchers.IO)
}
