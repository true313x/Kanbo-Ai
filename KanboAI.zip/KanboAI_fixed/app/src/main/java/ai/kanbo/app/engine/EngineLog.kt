package ai.kanbo.app.engine

import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Appends to files/native.log. Used by both processes (UI and :engine); every line is one O_APPEND write. */
object EngineLog {
    @Volatile private var file: File? = null
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    fun init(ctx: Context) { file = File(ctx.filesDir, "native.log") }

    @Synchronized
    fun w(msg: String) {
        Log.i("KanboEngine", msg)
        val f = file ?: return
        runCatching {
            FileOutputStream(f, true).use { it.write("[K ${fmt.format(Date())} p${android.os.Process.myPid()}] $msg\n".toByteArray()) }
        }
    }
}
