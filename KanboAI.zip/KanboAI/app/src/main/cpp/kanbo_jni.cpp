#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <chrono>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <exception>
#include <memory>
#include <mutex>
#include <string>
#include <vector>
#include "llama.h"
#include "gguf.h"
#include "ggml-backend.h"

using Clock = std::chrono::steady_clock;

struct Session {
    llama_model *model = nullptr;
    llama_context *ctx = nullptr;
    const llama_vocab *vocab = nullptr;
    std::vector<llama_token> cached;   // tokens currently in the KV cache (prefix reuse)
    std::atomic<bool> cancel{false};
    std::atomic<int> threads{1};       // requested thread count (applied between tokens, never mid-decode)
    int applied_threads = 0;
    int n_ctx = 0, n_batch = 0;
    double pp_tps = 0.0, tg_tps = 0.0; // measured here: llama's perf counters are disabled by default
    ~Session() {
        if (ctx) llama_free(ctx);
        if (model) llama_model_free(model);
    }
};

// ---------------------------------------------------------------- logging / errors
static FILE *g_log = nullptr;
static std::mutex g_mu;
static std::string g_err;

static void write_log(const char *text) {
    std::lock_guard<std::mutex> lk(g_mu);
    if (g_log) { fputs(text, g_log); fflush(g_log); }
}

static void klog(const char *fmt, ...) {
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    __android_log_write(ANDROID_LOG_INFO, "KanboNative", buf);
    std::string line = std::string("[N] ") + buf + "\n";
    write_log(line.c_str());
}

static void set_err(const std::string &e) {
    klog("ERROR: %s", e.c_str());
    std::lock_guard<std::mutex> lk(g_mu);
    g_err = e;
}

static void log_cb(ggml_log_level, const char *text, void *) {
    __android_log_write(ANDROID_LOG_INFO, "llama", text);
    write_log(text);
}

// ---------------------------------------------------------------- helpers
static std::string jstr(JNIEnv *env, jstring s) {
    if (!s) return {};
    const char *c = env->GetStringUTFChars(s, nullptr);
    if (!c) return {};
    std::string r(c);
    env->ReleaseStringUTFChars(s, c);
    return r;
}

static std::string jbytes(JNIEnv *env, jbyteArray a) {
    if (!a) return {};
    jsize n = env->GetArrayLength(a);
    std::string r((size_t) n, '\0');
    if (n > 0) env->GetByteArrayRegion(a, 0, n, reinterpret_cast<jbyte *>(&r[0]));
    return r;
}

static ggml_type kv_type(int c) { return c == 1 ? GGML_TYPE_Q8_0 : c == 2 ? GGML_TYPE_Q4_0 : GGML_TYPE_F16; }

// length of the longest prefix that ends on a complete UTF-8 sequence
static size_t utf8_complete_len(const std::string &s) {
    size_t n = s.size();
    for (size_t back = 1; back <= 3 && back <= n; ++back) {
        unsigned char c = (unsigned char) s[n - back];
        if ((c & 0xC0) == 0x80) continue;
        size_t need = c >= 0xF0 ? 4 : c >= 0xE0 ? 3 : c >= 0xC0 ? 2 : 1;
        return back >= need ? n : n - back;
    }
    return n;
}

// llama.cpp changed the arity of llama_sampler_init_penalties over time; call whichever the linked header declares.
template <class F>
static auto make_penalties(F f, int32_t n_vocab, int32_t last_n, float rep, float freq, float pres, int)
    -> decltype(f(n_vocab, last_n, rep, freq, pres)) { return f(n_vocab, last_n, rep, freq, pres); }
template <class F>
static auto make_penalties(F f, int32_t, int32_t last_n, float rep, float freq, float pres, long)
    -> decltype(f(last_n, rep, freq, pres)) { return f(last_n, rep, freq, pres); }

#define FN(name) Java_ai_kanbo_app_engine_NativeBridge_##name

static int apply_template(const char *tmpl, const std::vector<llama_chat_message> &msgs, size_t total, std::vector<char> &buf) {
    buf.assign(total * 2 + 1024, 0);
    int len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int32_t) buf.size());
    if (len > (int) buf.size()) {
        buf.resize((size_t) len);
        len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int32_t) buf.size());
    }
    return len;
}

static jint generate_impl(JNIEnv *env, Session *s, jobjectArray roles, jobjectArray contents, jint maxTokens,
                          jfloat temp, jfloat topP, jint topK, jobject cb) {
    jclass cls = env->GetObjectClass(cb);
    jmethodID onTok = cls ? env->GetMethodID(cls, "onToken", "([B)Z") : nullptr;
    if (cls) env->DeleteLocalRef(cls);
    if (!onTok) { env->ExceptionClear(); set_err("TokenListener.onToken not found (check ProGuard rules)"); return -3; }

    const jsize n = env->GetArrayLength(roles);
    std::vector<std::string> r((size_t) n), c((size_t) n);
    std::vector<llama_chat_message> msgs((size_t) n);
    size_t total = 0;
    for (jsize i = 0; i < n; ++i) {
        auto jr = (jstring) env->GetObjectArrayElement(roles, i);
        auto jc = (jbyteArray) env->GetObjectArrayElement(contents, i);
        r[i] = jstr(env, jr);
        c[i] = jbytes(env, jc);
        if (jr) env->DeleteLocalRef(jr);
        if (jc) env->DeleteLocalRef(jc);
        msgs[i] = {r[i].c_str(), c[i].c_str()};
        total += r[i].size() + c[i].size() + 32;
    }

    // model template first; many GGUFs ship Jinja that llama.cpp cannot render -> fall back to ChatML
    std::vector<char> buf;
    const char *tmpl = llama_model_chat_template(s->model, nullptr);
    int len = apply_template(tmpl, msgs, total, buf);
    if (len < 0) { klog("chat template unsupported, using chatml"); len = apply_template("chatml", msgs, total, buf); }
    if (len < 0) { set_err("cannot apply chat template"); return -3; }

    // Llama / Gemma templates rely on the tokenizer to add BOS; skip it only if the template already emitted it
    bool add_special = llama_vocab_get_add_bos(s->vocab);
    if (add_special) {
        llama_token bos = llama_vocab_bos(s->vocab);
        if (bos != LLAMA_TOKEN_NULL) {
            char bp[64];
            int bl = llama_token_to_piece(s->vocab, bos, bp, sizeof(bp), 0, true);
            if (bl > 0 && len >= bl && memcmp(buf.data(), bp, (size_t) bl) == 0) add_special = false;
        }
    }

    std::vector<llama_token> toks((size_t) len + 16);
    int nt = llama_tokenize(s->vocab, buf.data(), len, toks.data(), (int32_t) toks.size(), add_special, true);
    if (nt < 0) {
        toks.resize((size_t) -nt);
        nt = llama_tokenize(s->vocab, buf.data(), len, toks.data(), (int32_t) toks.size(), add_special, true);
    }
    if (nt <= 0) { set_err("tokenize failed"); return -3; }
    toks.resize((size_t) nt);
    if ((int) toks.size() >= s->n_ctx - 16) return -2;
    maxTokens = std::min<int>(maxTokens, s->n_ctx - (int) toks.size());
    if (maxTokens <= 0) return 0;

    auto apply_threads = [&]() {
        int t = s->threads.load();
        if (t > 0 && t != s->applied_threads) { llama_set_n_threads(s->ctx, t, t); s->applied_threads = t; }
    };
    apply_threads();

    // reuse the KV cache for the shared prefix: only new tokens are processed
    llama_memory_t mem = llama_get_memory(s->ctx);
    size_t common = 0;
    while (common < s->cached.size() && common < toks.size() && s->cached[common] == toks[common]) ++common;
    if (common == toks.size()) --common;
    if (!llama_memory_seq_rm(mem, 0, (llama_pos) common, -1)) {
        llama_memory_clear(mem, true);
        common = 0;
    }
    s->cached.assign(toks.begin(), toks.begin() + (long) common);

    const auto t0 = Clock::now();
    const size_t n_new = toks.size() - common;
    for (size_t i = common; i < toks.size() && !s->cancel; i += (size_t) s->n_batch) {
        int cnt = (int) std::min<size_t>((size_t) s->n_batch, toks.size() - i);
        llama_batch b = llama_batch_get_one(toks.data() + i, cnt);
        if (llama_decode(s->ctx, b) != 0) { s->cached.clear(); set_err("llama_decode failed (prompt)"); return -4; }
        s->cached.insert(s->cached.end(), toks.begin() + (long) i, toks.begin() + (long) i + cnt);
    }
    const double pp_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
    s->pp_tps = pp_ms > 0 ? 1000.0 * (double) n_new / pp_ms : 0.0;
    s->tg_tps = 0.0;

    llama_sampler *smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, make_penalties(&llama_sampler_init_penalties, (int32_t) llama_vocab_n_tokens(s->vocab), 64, 1.1f, 0.0f, 0.0f, 0));
    if (temp <= 0.f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
    } else {
        llama_sampler_chain_add(smpl, llama_sampler_init_top_k(topK));
        llama_sampler_chain_add(smpl, llama_sampler_init_top_p(topP, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_temp(temp));
        llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    }

    std::string pending;
    int produced = 0, rc = 0;
    const auto t1 = Clock::now();
    while (produced < maxTokens && !s->cancel) {
        llama_token tok = llama_sampler_sample(smpl, s->ctx, -1);
        if (llama_vocab_is_eog(s->vocab, tok)) break;
        char piece[512];
        int pl = llama_token_to_piece(s->vocab, tok, piece, sizeof(piece), 0, true);
        if (pl > 0) pending.append(piece, (size_t) pl);
        size_t ok = utf8_complete_len(pending);
        if (ok > 0) {
            jbyteArray arr = env->NewByteArray((jsize) ok);
            env->SetByteArrayRegion(arr, 0, (jsize) ok, reinterpret_cast<const jbyte *>(pending.data()));
            pending.erase(0, ok);
            jboolean cont = env->CallBooleanMethod(cb, onTok, arr);
            env->DeleteLocalRef(arr);
            if (env->ExceptionCheck()) { env->ExceptionClear(); s->cancel = true; }
            if (!cont) s->cancel = true;
        }
        llama_batch b = llama_batch_get_one(&tok, 1);
        if (llama_decode(s->ctx, b) != 0) { s->cached.clear(); set_err("llama_decode failed (generation)"); rc = -4; break; }
        s->cached.push_back(tok);
        ++produced;
        apply_threads();
    }
    const double tg_ms = std::chrono::duration<double, std::milli>(Clock::now() - t1).count();
    s->tg_tps = produced > 0 && tg_ms > 0 ? 1000.0 * produced / tg_ms : 0.0;
    llama_sampler_free(smpl);
    return rc < 0 ? rc : produced;
}

extern "C" {

JNIEXPORT jboolean JNICALL FN(nativeInit)(JNIEnv *env, jobject, jstring libDir, jstring logPath, jboolean safe) {
    {
        std::lock_guard<std::mutex> lk(g_mu);
        if (!g_log) g_log = fopen(jstr(env, logPath).c_str(), "a");
    }
    llama_log_set(log_cb, nullptr);
    std::string dir = jstr(env, libDir);
    std::string safeLib = dir + "/libggml-cpu-android_armv8.0_1.so";  // runs on every arm64 phone
    klog("=== init safe=%d dir=%s", (int) safe, dir.c_str());
    try {
        if (safe) ggml_backend_load(safeLib.c_str());
        else ggml_backend_load_all_from_path(dir.c_str());
        if (ggml_backend_reg_count() == 0) {
            klog("no CPU backend loaded, falling back to the baseline ARMv8.0 kernels");
            ggml_backend_load(safeLib.c_str());
        }
        llama_backend_init();
    } catch (const std::exception &e) {
        set_err(std::string("init exception: ") + e.what());
        return JNI_FALSE;
    }
    int n = (int) ggml_backend_reg_count();
    klog("backends=%d", n);
    if (n == 0) { set_err("no CPU backend could be loaded from " + dir); return JNI_FALSE; }
    return JNI_TRUE;
}

JNIEXPORT jstring JNICALL FN(nativeLastError)(JNIEnv *env, jobject) {
    std::lock_guard<std::mutex> lk(g_mu);
    return env->NewStringUTF(g_err.c_str());
}

static bool gguf_num(const gguf_context *g, const std::string &key, long long &out) {
    int64_t id = gguf_find_key(g, key.c_str());
    if (id < 0) return false;
    switch (gguf_get_kv_type(g, id)) {
        case GGUF_TYPE_UINT8:  out = gguf_get_val_u8(g, id);  return true;
        case GGUF_TYPE_INT8:   out = gguf_get_val_i8(g, id);  return true;
        case GGUF_TYPE_UINT16: out = gguf_get_val_u16(g, id); return true;
        case GGUF_TYPE_INT16:  out = gguf_get_val_i16(g, id); return true;
        case GGUF_TYPE_UINT32: out = gguf_get_val_u32(g, id); return true;
        case GGUF_TYPE_INT32:  out = gguf_get_val_i32(g, id); return true;
        case GGUF_TYPE_UINT64: out = (long long) gguf_get_val_u64(g, id); return true;
        case GGUF_TYPE_INT64:  out = gguf_get_val_i64(g, id); return true;
        case GGUF_TYPE_ARRAY: {   // per-layer arrays (e.g. head_count_kv): take the largest value
            size_t n = gguf_get_arr_n(g, id);
            if (n == 0) return false;
            const void *d = gguf_get_arr_data(g, id);
            long long best = 0;
            enum gguf_type t = gguf_get_arr_type(g, id);
            for (size_t i = 0; i < n; ++i) {
                long long v;
                if (t == GGUF_TYPE_UINT32) v = ((const uint32_t *) d)[i];
                else if (t == GGUF_TYPE_INT32) v = ((const int32_t *) d)[i];
                else return false;
                if (v > best) best = v;
            }
            out = best;
            return true;
        }
        default: return false;
    }
}

JNIEXPORT jlongArray JNICALL FN(nativeInspect)(JNIEnv *env, jobject, jstring jpath) {
    try {
        std::string path = jstr(env, jpath);
        klog("nativeInspect: begin %s", path.c_str());
        // read only the GGUF header/metadata: no model object, no tokenizer, no backend work
        struct gguf_init_params ip = { /*.no_alloc =*/ true, /*.ctx =*/ nullptr };
        gguf_context *g = gguf_init_from_file(path.c_str(), ip);
        if (!g) { set_err("not a valid or supported GGUF model"); return nullptr; }
        int64_t aid = gguf_find_key(g, "general.architecture");
        if (aid < 0) { gguf_free(g); set_err("GGUF has no general.architecture"); return nullptr; }
        std::string arch = gguf_get_val_str(g, aid);
        long long layers = 0, embd = 0, heads = 0, kvh = 0, ctx = 0;
        gguf_num(g, arch + ".block_count", layers);
        gguf_num(g, arch + ".embedding_length", embd);
        gguf_num(g, arch + ".attention.head_count", heads);
        if (!gguf_num(g, arch + ".attention.head_count_kv", kvh)) kvh = heads;
        gguf_num(g, arch + ".context_length", ctx);
        gguf_free(g);
        if (layers <= 0 || embd <= 0) { set_err("unsupported model: arch=" + arch + " (missing layer/embedding info)"); return nullptr; }
        jlong v[5] = {layers, embd, heads, kvh, ctx};
        klog("nativeInspect: ok arch=%s layers=%d embd=%d heads=%d kv_heads=%d ctx_train=%d", arch.c_str(), (int) v[0], (int) v[1], (int) v[2], (int) v[3], (int) v[4]);
        jlongArray out = env->NewLongArray(5);
        env->SetLongArrayRegion(out, 0, 5, v);
        return out;
    } catch (const std::exception &e) {
        set_err(std::string("inspect exception: ") + e.what());
        return nullptr;
    }
}

JNIEXPORT jlong JNICALL FN(nativeLoad)(JNIEnv *env, jobject, jstring jpath, jint nCtx, jint nBatch,
                                        jint nThreads, jboolean mmap, jint kv, jboolean flash) {
    try {
        std::string path = jstr(env, jpath);
        klog("nativeLoad: begin ctx=%d batch=%d threads=%d mmap=%d kv=%d flash=%d", (int) nCtx, (int) nBatch, (int) nThreads, (int) mmap, (int) kv, (int) flash);
        std::unique_ptr<Session> s(new Session());
        llama_model_params mp = llama_model_default_params();
        mp.n_gpu_layers = 0;
        mp.load_mode = mmap ? LLAMA_LOAD_MODE_MMAP : LLAMA_LOAD_MODE_NONE;
        s->model = llama_model_load_from_file(path.c_str(), mp);
        if (!s->model) { set_err("llama_model_load_from_file failed"); return 0; }
        klog("nativeLoad: weights loaded");

        // attempt 1: requested KV precision / flash-attn. attempt 2: the most compatible setup (F16 KV, no flash-attn)
        for (int attempt = 0; attempt < 2 && !s->ctx; ++attempt) {
            llama_context_params cp = llama_context_default_params();
            cp.n_ctx = (uint32_t) nCtx;
            cp.n_batch = (uint32_t) nBatch;
            cp.n_ubatch = (uint32_t) nBatch;
            cp.n_threads = nThreads;
            cp.n_threads_batch = nThreads;
            cp.type_k = attempt == 0 ? kv_type(kv) : GGML_TYPE_F16;
            cp.type_v = attempt == 0 ? kv_type(kv) : GGML_TYPE_F16;
            bool fa = attempt == 0 && (flash || kv != 0);
            cp.flash_attn_type = fa ? LLAMA_FLASH_ATTN_TYPE_ENABLED : LLAMA_FLASH_ATTN_TYPE_DISABLED;
            if (attempt == 1) klog("nativeLoad: retrying context with F16 KV cache and no flash-attn");
            s->ctx = llama_init_from_model(s->model, cp);
        }
        if (!s->ctx) { set_err("llama_init_from_model failed (not enough memory or unsupported KV setup)"); return 0; }
        s->vocab = llama_model_get_vocab(s->model);
        s->n_ctx = (int) llama_n_ctx(s->ctx);
        s->n_batch = std::max(1, std::min<int>(nBatch, s->n_ctx));
        s->threads = nThreads;
        s->applied_threads = nThreads;
        klog("nativeLoad: ready n_ctx=%d", s->n_ctx);
        return (jlong) s.release();
    } catch (const std::exception &e) {
        set_err(std::string("load exception: ") + e.what());
        return 0;
    }
}

// returns tokens produced, or: -2 context overflow, -3 template/tokenize error, -4 decode error
JNIEXPORT jint JNICALL FN(nativeGenerate)(JNIEnv *env, jobject, jlong h, jobjectArray roles, jobjectArray contents,
                                           jint maxTokens, jfloat temp, jfloat topP, jint topK, jobject cb) {
    auto *s = (Session *) h;
    if (!s || !s->ctx || !cb) { set_err("generate: no model loaded"); return -3; }
    s->cancel = false;
    try {
        return generate_impl(env, s, roles, contents, maxTokens, temp, topP, topK, cb);
    } catch (const std::exception &e) {
        s->cached.clear();
        set_err(std::string("generate exception: ") + e.what());
        return -4;
    }
}

JNIEXPORT void JNICALL FN(nativeCancel)(JNIEnv *, jobject, jlong h) { if (h) ((Session *) h)->cancel = true; }

// only records the request: it is applied between tokens, so it never races with llama_decode
JNIEXPORT void JNICALL FN(nativeSetThreads)(JNIEnv *, jobject, jlong h, jint n) { if (h && n > 0) ((Session *) h)->threads = n; }

JNIEXPORT jdoubleArray JNICALL FN(nativeStats)(JNIEnv *env, jobject, jlong h) {
    auto *s = (Session *) h;
    jdouble v[2] = {s ? s->pp_tps : 0.0, s ? s->tg_tps : 0.0};
    jdoubleArray out = env->NewDoubleArray(2);
    env->SetDoubleArrayRegion(out, 0, 2, v);
    return out;
}

JNIEXPORT void JNICALL FN(nativeFree)(JNIEnv *, jobject, jlong h) {
    delete (Session *) h;   // destructor frees ctx then model
    klog("nativeFree: done");
}

}  // extern "C"
