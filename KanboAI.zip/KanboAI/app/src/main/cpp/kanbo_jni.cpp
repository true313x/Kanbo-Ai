#include <jni.h>
#include <atomic>
#include <algorithm>
#include <string>
#include <vector>
#include "llama.h"
#include "ggml-backend.h"

struct Session {
    llama_model *model = nullptr;
    llama_context *ctx = nullptr;
    const llama_vocab *vocab = nullptr;
    std::vector<llama_token> cached;   // tokens currently in the KV cache (prefix reuse)
    std::atomic<bool> cancel{false};
    int n_ctx = 0, n_batch = 0;
};

static std::string jstr(JNIEnv *env, jstring s) {
    const char *c = env->GetStringUTFChars(s, nullptr);
    std::string r(c);
    env->ReleaseStringUTFChars(s, c);
    return r;
}

static std::string jbytes(JNIEnv *env, jbyteArray a) {
    jsize n = env->GetArrayLength(a);
    std::string r(n, '\0');
    env->GetByteArrayRegion(a, 0, n, reinterpret_cast<jbyte *>(r.data()));
    return r;
}

static ggml_type kv_type(int c) { return c == 1 ? GGML_TYPE_Q8_0 : c == 2 ? GGML_TYPE_Q4_0 : GGML_TYPE_F16; }

// length of the longest prefix that ends on a complete UTF-8 sequence
static size_t utf8_complete_len(const std::string &s) {
    size_t n = s.size();
    for (size_t back = 1; back <= 3 && back <= n; ++back) {
        unsigned char c = (unsigned char) s[n - back];
        if ((c & 0xC0) == 0x80) continue;
        size_t need = c >= 0xF0 ? 4 : c >= 0xE0 ? 3 : c >= 0xC0 ? 2 : 1;
        return back >= need ? n : n - back;
    }
    return n;
}

#define FN(name) Java_ai_kanbo_app_engine_NativeBridge_##name

extern "C" {

JNIEXPORT void JNICALL FN(nativeInit)(JNIEnv *env, jobject, jstring libDir) {
    ggml_backend_load_all_from_path(jstr(env, libDir).c_str());  // picks best CPU variant at runtime
    llama_backend_init();
}

JNIEXPORT jlongArray JNICALL FN(nativeInspect)(JNIEnv *env, jobject, jstring jpath) {
    llama_model_params mp = llama_model_default_params();
    mp.vocab_only = true;
    llama_model *m = llama_model_load_from_file(jstr(env, jpath).c_str(), mp);
    if (!m) return nullptr;
    jlong v[5] = {llama_model_n_layer(m), llama_model_n_embd(m), llama_model_n_head(m),
                  llama_model_n_head_kv(m), llama_model_n_ctx_train(m)};
    llama_model_free(m);
    jlongArray out = env->NewLongArray(5);
    env->SetLongArrayRegion(out, 0, 5, v);
    return out;
}

JNIEXPORT jlong JNICALL FN(nativeLoad)(JNIEnv *env, jobject, jstring jpath, jint nCtx, jint nBatch,
                                        jint nThreads, jboolean mmap, jint kv, jboolean flash) {
    auto *s = new Session();
    llama_model_params mp = llama_model_default_params();
    mp.use_mmap = mmap;
    mp.n_gpu_layers = 0;
    s->model = llama_model_load_from_file(jstr(env, jpath).c_str(), mp);
    if (!s->model) { delete s; return 0; }

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = nCtx;
    cp.n_batch = nBatch;
    cp.n_ubatch = nBatch;
    cp.n_threads = nThreads;
    cp.n_threads_batch = nThreads;
    cp.type_k = kv_type(kv);
    cp.type_v = kv_type(kv);
    cp.flash_attn_type = (flash || kv != 0) ? LLAMA_FLASH_ATTN_TYPE_ENABLED : LLAMA_FLASH_ATTN_TYPE_DISABLED;
    s->ctx = llama_init_from_model(s->model, cp);
    if (!s->ctx) { llama_model_free(s->model); delete s; return 0; }
    s->vocab = llama_model_get_vocab(s->model);
    s->n_ctx = (int) llama_n_ctx(s->ctx);
    s->n_batch = nBatch;
    return (jlong) s;
}

// returns tokens produced, or: -2 context overflow, -3 template/tokenize error, -4 decode error
JNIEXPORT jint JNICALL FN(nativeGenerate)(JNIEnv *env, jobject, jlong h, jobjectArray roles, jobjectArray contents,
                                           jint maxTokens, jfloat temp, jfloat topP, jint topK, jobject cb) {
    auto *s = (Session *) h;
    s->cancel = false;
    jmethodID onTok = env->GetMethodID(env->GetObjectClass(cb), "onToken", "([B)Z");

    const jsize n = env->GetArrayLength(roles);
    std::vector<std::string> r(n), c(n);
    std::vector<llama_chat_message> msgs(n);
    size_t total = 0;
    for (jsize i = 0; i < n; ++i) {
        auto jr = (jstring) env->GetObjectArrayElement(roles, i);
        auto jc = (jbyteArray) env->GetObjectArrayElement(contents, i);
        r[i] = jstr(env, jr);
        c[i] = jbytes(env, jc);
        env->DeleteLocalRef(jr);
        env->DeleteLocalRef(jc);
        msgs[i] = {r[i].c_str(), c[i].c_str()};
        total += r[i].size() + c[i].size() + 32;
    }

    const char *tmpl = llama_model_chat_template(s->model, nullptr);
    std::vector<char> buf(total * 2 + 1024);
    int len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int32_t) buf.size());
    if (len > (int) buf.size()) {
        buf.resize(len);
        len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int32_t) buf.size());
    }
    if (len < 0) return -3;

    std::vector<llama_token> toks(len + 16);
    int nt = llama_tokenize(s->vocab, buf.data(), len, toks.data(), (int32_t) toks.size(), false, true);
    if (nt < 0) {
        toks.resize(-nt);
        nt = llama_tokenize(s->vocab, buf.data(), len, toks.data(), (int32_t) toks.size(), false, true);
    }
    if (nt <= 0) return -3;
    toks.resize(nt);
    if ((int) toks.size() >= s->n_ctx - 16) return -2;
    maxTokens = std::min<int>(maxTokens, s->n_ctx - (int) toks.size());

    // reuse the KV cache for the shared prefix: only new tokens are processed
    llama_memory_t mem = llama_get_memory(s->ctx);
    size_t common = 0;
    while (common < s->cached.size() && common < toks.size() && s->cached[common] == toks[common]) ++common;
    if (common == toks.size()) --common;
    if (!llama_memory_seq_rm(mem, 0, (llama_pos) common, -1)) {
        llama_memory_clear(mem, true);
        common = 0;
    }
    s->cached.assign(toks.begin(), toks.begin() + common);

    llama_perf_context_reset(s->ctx);
    for (size_t i = common; i < toks.size() && !s->cancel; i += s->n_batch) {
        int cnt = (int) std::min<size_t>(s->n_batch, toks.size() - i);
        llama_batch b = llama_batch_get_one(toks.data() + i, cnt);
        if (llama_decode(s->ctx, b) != 0) { s->cached.clear(); return -4; }
        s->cached.insert(s->cached.end(), toks.begin() + i, toks.begin() + i + cnt);
    }

    llama_sampler *smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_penalties(64, 1.1f, 0.0f, 0.0f));
    if (temp <= 0.f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
    } else {
        llama_sampler_chain_add(smpl, llama_sampler_init_top_k(topK));
        llama_sampler_chain_add(smpl, llama_sampler_init_top_p(topP, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_temp(temp));
        llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    }

    std::string pending;
    int produced = 0, rc = 0;
    while (produced < maxTokens && !s->cancel) {
        llama_token tok = llama_sampler_sample(smpl, s->ctx, -1);
        if (llama_vocab_is_eog(s->vocab, tok)) break;
        char piece[256];
        int pl = llama_token_to_piece(s->vocab, tok, piece, sizeof(piece), 0, true);
        if (pl > 0) pending.append(piece, pl);
        size_t ok = utf8_complete_len(pending);
        if (ok > 0) {
            jbyteArray arr = env->NewByteArray((jsize) ok);
            env->SetByteArrayRegion(arr, 0, (jsize) ok, reinterpret_cast<const jbyte *>(pending.data()));
            pending.erase(0, ok);
            jboolean cont = env->CallBooleanMethod(cb, onTok, arr);
            env->DeleteLocalRef(arr);
            if (env->ExceptionCheck()) { env->ExceptionClear(); s->cancel = true; }
            if (!cont) s->cancel = true;
        }
        llama_batch b = llama_batch_get_one(&tok, 1);
        if (llama_decode(s->ctx, b) != 0) { s->cached.clear(); rc = -4; break; }
        s->cached.push_back(tok);
        ++produced;
    }
    llama_sampler_free(smpl);
    return rc < 0 ? rc : produced;
}

JNIEXPORT void JNICALL FN(nativeCancel)(JNIEnv *, jobject, jlong h) { ((Session *) h)->cancel = true; }

JNIEXPORT void JNICALL FN(nativeSetThreads)(JNIEnv *, jobject, jlong h, jint n) {
    llama_set_n_threads(((Session *) h)->ctx, n, n);
}

JNIEXPORT jdoubleArray JNICALL FN(nativeStats)(JNIEnv *env, jobject, jlong h) {
    llama_perf_context_data d = llama_perf_context(((Session *) h)->ctx);
    jdouble v[2] = {d.t_p_eval_ms > 0 ? 1000.0 * d.n_p_eval / d.t_p_eval_ms : 0.0,
                    d.t_eval_ms > 0 ? 1000.0 * d.n_eval / d.t_eval_ms : 0.0};
    jdoubleArray out = env->NewDoubleArray(2);
    env->SetDoubleArrayRegion(out, 0, 2, v);
    return out;
}

JNIEXPORT void JNICALL FN(nativeFree)(JNIEnv *, jobject, jlong h) {
    auto *s = (Session *) h;
    llama_free(s->ctx);
    llama_model_free(s->model);
    delete s;
}

}  // extern "C"
