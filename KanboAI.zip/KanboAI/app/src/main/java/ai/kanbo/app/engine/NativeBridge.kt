package ai.kanbo.app.engine

fun interface TokenListener { fun onToken(bytes: ByteArray): Boolean }

object NativeBridge {
    init { System.loadLibrary("kanbo_native") }
    external fun nativeInit(libDir: String, logPath: String, safe: Boolean)
    external fun nativeInspect(path: String): LongArray?
    external fun nativeLoad(path: String, nCtx: Int, nBatch: Int, nThreads: Int, mmap: Boolean, kv: Int, flash: Boolean): Long
    external fun nativeGenerate(
        h: Long, roles: Array<String>, contents: Array<ByteArray>,
        maxTokens: Int, temp: Float, topP: Float, topK: Int, cb: TokenListener,
    ): Int
    external fun nativeCancel(h: Long)
    external fun nativeSetThreads(h: Long, n: Int)
    external fun nativeStats(h: Long): DoubleArray
    external fun nativeFree(h: Long)
}
