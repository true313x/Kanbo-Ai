package ai.kanbo.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Assistant text split into the model's "thinking" part (DeepSeek-R1 / Qwen3 style) and the visible answer. */
data class ParsedReply(val thinking: String?, val answer: String, val thinkingOpen: Boolean)

private const val THINK_OPEN = "<think>"
private const val THINK_CLOSE = "</think>"

fun splitThink(raw: String): ParsedReply {
    val t = raw.trimStart()
    if (t.startsWith(THINK_OPEN)) {
        val end = t.indexOf(THINK_CLOSE)
        return if (end < 0) ParsedReply(t.removePrefix(THINK_OPEN).trim(), "", true)
        else ParsedReply(t.substring(THINK_OPEN.length, end).trim(), t.substring(end + THINK_CLOSE.length).trimStart(), false)
    }
    val end = t.indexOf(THINK_CLOSE)
    if (end >= 0) return ParsedReply(t.substring(0, end).trim(), t.substring(end + THINK_CLOSE.length).trimStart(), false)
    return ParsedReply(null, raw, false)
}

sealed interface Block {
    data class Para(val text: String) : Block
    data class Heading(val level: Int, val text: String) : Block
    data class Item(val marker: String, val text: String) : Block
    data class Code(val lang: String, val code: String) : Block
    data class Quote(val text: String) : Block
}

private val HEADING = Regex("^(#{1,6})\\s+(.*)$")
private val BULLET = Regex("^[-*\u2022]\\s+(.*)$")
private val NUMBERED = Regex("^(\\d{1,3})[.)]\\s+(.*)$")

/** Minimal Markdown: fenced code, headings, bullet / numbered lists, quotes, paragraphs. Tolerates half-streamed text. */
fun parseBlocks(src: String): List<Block> {
    val out = ArrayList<Block>()
    val lines = src.replace("\r\n", "\n").split("\n")
    val para = StringBuilder()
    fun flush() {
        if (para.isNotBlank()) out.add(Block.Para(para.toString().trim()))
        para.clear()
    }
    var i = 0
    while (i < lines.size) {
        val line = lines[i]
        val t = line.trim()
        if (t.startsWith("```")) {
            flush()
            val lang = t.removePrefix("```").trim()
            val code = StringBuilder()
            i++
            while (i < lines.size && !lines[i].trim().startsWith("```")) {
                if (code.isNotEmpty()) code.append('\n')
                code.append(lines[i])
                i++
            }
            out.add(Block.Code(lang, code.toString()))
        } else if (t.isEmpty()) {
            flush()
        } else {
            val h = HEADING.matchEntire(t)
            val b = BULLET.matchEntire(t)
            val n = NUMBERED.matchEntire(t)
            if (h != null) {
                flush()
                out.add(Block.Heading(h.groupValues[1].length, h.groupValues[2]))
            } else if (b != null) {
                flush()
                out.add(Block.Item("\u2022", b.groupValues[1]))
            } else if (n != null) {
                flush()
                out.add(Block.Item(n.groupValues[1] + ".", n.groupValues[2]))
            } else if (t.startsWith(">")) {
                flush()
                out.add(Block.Quote(t.removePrefix(">").trim()))
            } else if (t == "---" || t == "***" || t == "___") {
                flush()
            } else {
                if (para.isNotEmpty()) para.append('\n')
                para.append(line.trimEnd())
            }
        }
        i++
    }
    flush()
    return out
}

/** **bold**, *italic* and `code` inside one line of text. */
fun inlineStyled(s: String, codeBg: Color): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < s.length) {
        val c = s[i]
        if (c == '*' && s.startsWith("**", i)) {
            val e = s.indexOf("**", i + 2)
            if (e > i + 2) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(s.substring(i + 2, e)) }
                i = e + 2
                continue
            }
        }
        if (c == '`') {
            val e = s.indexOf('`', i + 1)
            if (e > i + 1) {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg, fontSize = 14.sp)) { append(s.substring(i + 1, e)) }
                i = e + 1
                continue
            }
        }
        if (c == '*' && i + 1 < s.length && s[i + 1] != ' ' && s[i + 1] != '*') {
            val e = s.indexOf('*', i + 1)
            if (e > i + 1 && s[e - 1] != ' ') {
                withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(s.substring(i + 1, e)) }
                i = e + 1
                continue
            }
        }
        append(c)
        i++
    }
}

@Composable
fun MarkdownText(text: String, modifier: Modifier = Modifier) {
    val blocks = remember(text) { parseBlocks(text) }
    val cs = MaterialTheme.colorScheme
    val body = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Content, color = cs.onSurface)
    SelectionContainer {
        Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            blocks.forEach { b ->
                when (b) {
                    is Block.Para -> Text(inlineStyled(b.text, cs.surfaceContainerHighest), style = body)
                    is Block.Heading -> {
                        val st = when (b.level) {
                            1 -> MaterialTheme.typography.titleLarge
                            2 -> MaterialTheme.typography.titleMedium
                            else -> MaterialTheme.typography.titleSmall
                        }
                        Text(inlineStyled(b.text, cs.surfaceContainerHighest), style = st.copy(textDirection = TextDirection.Content, color = cs.onSurface, fontWeight = FontWeight.Bold))
                    }
                    is Block.Item -> Row(Modifier.padding(start = 4.dp)) {
                        Text(b.marker, Modifier.width(24.dp), style = body.copy(color = cs.primary, fontWeight = FontWeight.Bold))
                        Text(inlineStyled(b.text, cs.surfaceContainerHighest), Modifier.weight(1f), style = body)
                    }
                    is Block.Quote -> Row(Modifier.height(IntrinsicSize.Min)) {
                        Box(Modifier.width(3.dp).fillMaxHeight().background(cs.outlineVariant, RoundedCornerShape(2.dp)))
                        Spacer(Modifier.width(10.dp))
                        Text(inlineStyled(b.text, cs.surfaceContainerHighest), style = body.copy(color = cs.onSurfaceVariant))
                    }
                    is Block.Code -> CodeBlock(b.lang, b.code)
                }
            }
        }
    }
}

@Composable
private fun CodeBlock(lang: String, code: String) {
    val clip = LocalClipboardManager.current
    val cs = MaterialTheme.colorScheme
    Surface(shape = RoundedCornerShape(14.dp), color = cs.surfaceContainerHighest, modifier = Modifier.fillMaxWidth()) {
        Column {
            Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 4.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(lang.ifBlank { "code" }, Modifier.weight(1f), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                IconButton({ clip.setText(AnnotatedString(code)) }) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = null, tint = cs.onSurfaceVariant)
                }
            }
            Text(
                code,
                Modifier.horizontalScroll(rememberScrollState()).padding(start = 14.dp, end = 14.dp, bottom = 14.dp),
                style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 19.sp, color = cs.onSurface, textDirection = TextDirection.Ltr),
            )
        }
    }
}
