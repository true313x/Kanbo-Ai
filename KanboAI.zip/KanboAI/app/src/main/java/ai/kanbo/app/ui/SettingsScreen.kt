@file:OptIn(ExperimentalMaterial3Api::class)

package ai.kanbo.app.ui

import ai.kanbo.app.R
import android.content.ClipData
import android.content.ClipboardManager
import android.os.Build
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth()) {
        Text(title, Modifier.padding(start = 8.dp, bottom = 8.dp), style = MaterialTheme.typography.titleSmall, color = cs.primary)
        Surface(shape = RoundedCornerShape(24.dp), color = cs.surfaceContainerLow, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
        }
    }
}

@Composable
private fun <T> Choices(label: String, options: List<Pair<String, T>>, current: T, onPick: (T) -> Unit) {
    Text(label, style = MaterialTheme.typography.labelLarge)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o ->
            FilterChip(selected = o.second == current, onClick = { onPick(o.second) }, label = { Text(o.first) })
        }
    }
}

@Composable
private fun SwitchRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit, onMemory: () -> Unit) {
    val s = vm.prefs
    var showLog by remember { mutableStateOf(false) }
    val auto = stringResource(R.string.auto)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings)) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back)) }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Section(stringResource(R.string.appearance_section)) {
                Choices(
                    stringResource(R.string.theme),
                    listOf(stringResource(R.string.theme_system) to 0, stringResource(R.string.theme_light) to 1, stringResource(R.string.theme_dark) to 2),
                    s.themeMode,
                ) { s.themeMode = it; s.save() }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    SwitchRow(stringResource(R.string.dynamic_color), null, s.dynamicColor) { s.dynamicColor = it; s.save() }
                }
            }

            Section(stringResource(R.string.memory)) {
                SwitchRow(stringResource(R.string.memory_use), stringResource(R.string.memory_desc), s.memoryEnabled) { s.memoryEnabled = it; s.save() }
                OutlinedButton(onClick = onMemory, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.manage) + " · " + stringResource(R.string.memory_count, vm.memory.items.size))
                }
            }

            Section(stringResource(R.string.generation)) {
                if (vm.supportsThinkingToggle) {
                    SwitchRow(stringResource(R.string.thinking_mode), stringResource(R.string.thinking_mode_desc), s.thinking) { s.thinking = it; s.save() }
                }
                Text(stringResource(R.string.temperature) + ": " + "%.2f".format(s.temp))
                Slider(s.temp, { s.temp = it }, valueRange = 0f..1.5f, onValueChangeFinished = { s.save() })
                Text(stringResource(R.string.top_p) + ": " + "%.2f".format(s.topP))
                Slider(s.topP, { s.topP = it }, valueRange = 0.1f..1f, onValueChangeFinished = { s.save() })
                Text(stringResource(R.string.top_k) + ": " + s.topK)
                Slider(s.topK.toFloat(), { s.topK = it.toInt() }, valueRange = 1f..100f, onValueChangeFinished = { s.save() })
                Choices(
                    stringResource(R.string.max_tokens),
                    listOf("256" to 256, "512" to 512, "1024" to 1024, "2048" to 2048, "4096" to 4096),
                    s.maxTokens,
                ) { s.maxTokens = it; s.save() }
                OutlinedTextField(
                    value = s.system,
                    onValueChange = { s.system = it; s.save() },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.system_prompt)) },
                    minLines = 2,
                    maxLines = 5,
                )
            }

            Section(stringResource(R.string.engine)) {
                Text(stringResource(R.string.apply_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Choices(
                    stringResource(R.string.context),
                    listOf(auto to 0, "512" to 512, "1024" to 1024, "2048" to 2048, "4096" to 4096, "8192" to 8192),
                    s.ctxSize,
                ) { s.ctxSize = it; s.save() }
                Choices(
                    stringResource(R.string.threads),
                    listOf(auto to 0, "2" to 2, "3" to 3, "4" to 4, "6" to 6, "8" to 8),
                    s.threads,
                ) { s.threads = it; s.save() }
                Choices(
                    stringResource(R.string.kv_cache),
                    listOf(auto to -1, "F16" to 0, "Q8" to 1, "Q4" to 2),
                    s.kv,
                ) { s.kv = it; s.save() }
                SwitchRow(stringResource(R.string.safe_cpu), null, s.safeCpu) { s.safeCpu = it; s.save(); vm.applySafe() }
                OutlinedButton(onClick = { showLog = true }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.show_log)) }
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    if (showLog) {
        val ctx = LocalContext.current
        val text = remember { vm.log().ifEmpty { "—" } }
        AlertDialog(
            onDismissRequest = { showLog = false },
            confirmButton = { TextButton(onClick = { showLog = false }) { Text(stringResource(R.string.close)) } },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("kanbo log", text))
                    }) { Text(stringResource(R.string.copy)) }
                    TextButton(onClick = { vm.clearLog(); showLog = false }) { Text(stringResource(R.string.clear)) }
                }
            },
            text = { SelectionContainer { Text(text, Modifier.verticalScroll(rememberScrollState()), style = MaterialTheme.typography.bodySmall) } },
        )
    }
}
