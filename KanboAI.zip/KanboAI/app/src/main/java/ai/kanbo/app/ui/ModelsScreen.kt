@file:OptIn(ExperimentalMaterial3Api::class)

package ai.kanbo.app.ui

import ai.kanbo.app.R
import ai.kanbo.app.models.Catalog
import ai.kanbo.app.models.CatalogFamilies
import ai.kanbo.app.models.CatalogModel
import ai.kanbo.app.models.recommendedModelId
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.io.File
import java.util.Locale

private fun gb(mb: Int): String = String.format(Locale.US, "%.1f GB", mb / 1024.0)

@Composable
fun ModelsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val p = vm.profile
    val active by vm.loaded.collectAsStateWithLifecycle()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importModel(uri) }
    var filter by remember { mutableStateOf("all") }
    var showLink by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<File?>(null) }
    val recId = recommendedModelId(p.totalRamMb)
    val busy = vm.loadingName != null
    val cs = MaterialTheme.colorScheme

    val shown = Catalog.filter { m ->
        when (filter) {
            "all" -> true
            "installed" -> vm.files.any { it.name == m.file }
            else -> m.family == filter
        }
    }.sortedBy { it.sizeMb }
    val locals = if (filter == "all" || filter == "installed") vm.files.filter { f -> Catalog.none { it.file == f.name } } else emptyList()
    val extraDownloads = vm.progress.keys.filter { k -> Catalog.none { it.id == k } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.models)) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back)) }
                },
            )
        },
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Surface(shape = RoundedCornerShape(20.dp), color = cs.secondaryContainer, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            stringResource(R.string.device, p.totalRamMb.toInt(), p.perfCores, p.tier.name),
                            style = MaterialTheme.typography.labelLarge,
                            color = cs.onSecondaryContainer,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(stringResource(R.string.models_hint), style = MaterialTheme.typography.bodySmall, color = cs.onSecondaryContainer)
                    }
                }
            }
            val st = vm.status
            if (st != null || busy) {
                item {
                    Surface(shape = RoundedCornerShape(16.dp), color = cs.surfaceContainerHigh, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(st ?: stringResource(R.string.loading), style = MaterialTheme.typography.bodyMedium)
                            if (busy) {
                                Spacer(Modifier.height(8.dp))
                                LinearProgressIndicator(Modifier.fillMaxWidth())
                            }
                        }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FilledTonalButton(onClick = { showLink = true }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.Link, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.add_from_link), maxLines = 1)
                    }
                    OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, enabled = vm.importing == null, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.import_model), maxLines = 1)
                    }
                }
                val ip = vm.importing
                if (ip != null) {
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { ip }, modifier = Modifier.fillMaxWidth())
                }
            }
            item {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val keys = listOf("all", "installed") + CatalogFamilies
                    keys.forEach { k ->
                        val label = when (k) {
                            "all" -> stringResource(R.string.filter_all)
                            "installed" -> stringResource(R.string.filter_installed)
                            else -> k
                        }
                        FilterChip(selected = filter == k, onClick = { filter = k }, label = { Text(label) })
                    }
                }
            }
            items(extraDownloads, key = { it }) { id ->
                val prog = vm.progress[id] ?: 0f
                Surface(shape = RoundedCornerShape(20.dp), color = cs.surfaceContainerLow, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(id.removePrefix("link:"), style = MaterialTheme.typography.titleMedium, maxLines = 2)
                        Spacer(Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LinearProgressIndicator(progress = { prog }, modifier = Modifier.weight(1f))
                            Spacer(Modifier.width(10.dp))
                            Text("${(prog * 100).toInt()}%", style = MaterialTheme.typography.labelMedium)
                            TextButton(onClick = { vm.cancelDownload(id) }) { Text(stringResource(R.string.cancel)) }
                        }
                    }
                }
            }
            items(shown, key = { it.id }) { m ->
                ModelCard(
                    m = m,
                    installed = vm.files.firstOrNull { it.name == m.file },
                    prog = vm.progress[m.id],
                    active = active == m.name,
                    busy = busy,
                    loadingThis = vm.loadingName == m.name,
                    recommended = m.id == recId,
                    ramOk = p.totalRamMb >= m.minRamMb,
                    onDownload = { vm.download(m) },
                    onCancelDownload = { vm.cancelDownload(m.id) },
                    onRun = { f -> vm.load(f, m.name) },
                    onCancelLoad = { vm.cancelLoad() },
                    onDelete = { f -> deleteTarget = f },
                )
            }
            items(locals, key = { "local:" + it.name }) { f ->
                val name = vm.displayName(f)
                val m = CatalogModel("local:" + f.name, name, "Local", "", f.name, (f.length() / 1048576).toInt(), 0)
                ModelCard(
                    m = m,
                    installed = f,
                    prog = null,
                    active = active == name,
                    busy = busy,
                    loadingThis = vm.loadingName == name,
                    recommended = false,
                    ramOk = true,
                    onDownload = {},
                    onCancelDownload = {},
                    onRun = { file -> vm.load(file, name) },
                    onCancelLoad = { vm.cancelLoad() },
                    onDelete = { file -> deleteTarget = file },
                )
            }
        }
    }

    if (showLink) {
        LinkDialog(onDismiss = { showLink = false }, onAdd = { vm.downloadFromLink(it) })
    }
    deleteTarget?.let { f ->
        ConfirmDialog(
            title = stringResource(R.string.delete_model_title),
            text = vm.displayName(f) + "\n" + stringResource(R.string.delete_model_msg),
            confirmLabel = stringResource(R.string.delete),
            onConfirm = { vm.delete(f); deleteTarget = null },
            onDismiss = { deleteTarget = null },
        )
    }
}

@Composable
private fun Tag(text: String, container: androidx.compose.ui.graphics.Color, content: androidx.compose.ui.graphics.Color) {
    Surface(shape = RoundedCornerShape(8.dp), color = container) {
        Text(text, Modifier.padding(horizontal = 8.dp, vertical = 3.dp), style = MaterialTheme.typography.labelSmall, color = content)
    }
}

@Composable
private fun ModelCard(
    m: CatalogModel,
    installed: File?,
    prog: Float?,
    active: Boolean,
    busy: Boolean,
    loadingThis: Boolean,
    recommended: Boolean,
    ramOk: Boolean,
    onDownload: () -> Unit,
    onCancelDownload: () -> Unit,
    onRun: (File) -> Unit,
    onCancelLoad: () -> Unit,
    onDelete: (File) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (active) cs.primaryContainer else cs.surfaceContainerLow,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(m.name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                if (active) Tag(stringResource(R.string.running_now), cs.primary, cs.onPrimary)
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                Tag(m.family, cs.secondaryContainer, cs.onSecondaryContainer)
                if (m.sizeMb > 0) Tag(gb(m.sizeMb), cs.surfaceContainerHighest, cs.onSurface)
                if (m.minRamMb > 0) Tag("RAM ≥ " + String.format(Locale.US, "%.1f", m.minRamMb / 1000.0) + " GB", cs.surfaceContainerHighest, cs.onSurface)
                if (m.reasoning) Tag(stringResource(R.string.reasoning), cs.tertiaryContainer, cs.onTertiaryContainer)
                if (recommended) Tag(stringResource(R.string.recommended), cs.primary, cs.onPrimary)
            }
            val d = m.desc()
            if (d.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(d, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
            }
            Spacer(Modifier.height(12.dp))
            when {
                prog != null -> Row(verticalAlignment = Alignment.CenterVertically) {
                    LinearProgressIndicator(progress = { prog }, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(10.dp))
                    Text("${(prog * 100).toInt()}%", style = MaterialTheme.typography.labelMedium)
                    TextButton(onClick = onCancelDownload) { Text(stringResource(R.string.cancel)) }
                }
                installed != null -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { onRun(installed) }, enabled = !active && !busy) {
                        Text(stringResource(if (active) R.string.loaded else if (loadingThis) R.string.loading else R.string.load))
                    }
                    Spacer(Modifier.width(8.dp))
                    if (loadingThis) {
                        TextButton(onClick = onCancelLoad) { Text(stringResource(R.string.cancel)) }
                    } else {
                        TextButton(onClick = { onDelete(installed) }, enabled = !active && !busy) { Text(stringResource(R.string.delete)) }
                    }
                }
                !ramOk -> Text(
                    stringResource(R.string.needs_ram, String.format(Locale.US, "%.1f", m.minRamMb / 1000.0)),
                    style = MaterialTheme.typography.labelMedium,
                    color = cs.error,
                )
                else -> FilledTonalButton(onClick = onDownload) {
                    Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.download))
                }
            }
        }
    }
}

@Composable
private fun LinkDialog(onDismiss: () -> Unit, onAdd: (String) -> Boolean) {
    var text by remember { mutableStateOf("") }
    var bad by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.link_title)) },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it; bad = false },
                    label = { Text(stringResource(R.string.link_hint)) },
                    isError = bad,
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    if (bad) stringResource(R.string.link_invalid) else stringResource(R.string.link_help),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (bad) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { if (onAdd(text)) onDismiss() else bad = true }) { Text(stringResource(R.string.download)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}
