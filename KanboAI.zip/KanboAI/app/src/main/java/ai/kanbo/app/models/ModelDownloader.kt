package ai.kanbo.app.models

import android.os.StatFs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.util.Locale

data class CatalogModel(
    val id: String,
    val name: String,
    val family: String,
    val repo: String,
    val file: String,
    val sizeMb: Int,
    val minRamMb: Int,
    val reasoning: Boolean = false,
    val descEn: String = "",
    val descAr: String = "",
    /** Direct download link; when null the file is fetched from the Hugging Face [repo]. */
    val url: String? = null,
) {
    fun desc(): String = if (Locale.getDefault().language == "ar") descAr.ifBlank { descEn } else descEn
}

val Catalog = listOf(
    CatalogModel("qwen3-06b", "Qwen3 0.6B", "Qwen", "Qwen/Qwen3-0.6B-GGUF", "Qwen3-0.6B-Q8_0.gguf", 610, 2500, true,
        "Tiny and fast, with an optional thinking mode. Good for quick answers.", "صغير وسريع مع وضع تفكير اختياري. مناسب للإجابات السريعة."),
    CatalogModel("qwen25-05b", "Qwen2.5 0.5B", "Qwen", "Qwen/Qwen2.5-0.5B-Instruct-GGUF", "qwen2.5-0.5b-instruct-q4_k_m.gguf", 400, 2500, false,
        "Very small and fast. Basic chat on any phone.", "صغير جدًا وسريع. محادثة أساسية على أي هاتف."),
    CatalogModel("llama32-1b", "Llama 3.2 1B", "Llama", "bartowski/Llama-3.2-1B-Instruct-GGUF", "Llama-3.2-1B-Instruct-Q4_K_M.gguf", 810, 3500, false,
        "Meta's compact model. Fast and well rounded.", "نموذج Meta المدمج. سريع ومتوازن."),
    CatalogModel("gemma3-1b", "Gemma 3 1B", "Gemma", "unsloth/gemma-3-1b-it-GGUF", "gemma-3-1b-it-Q4_K_M.gguf", 770, 3000, false,
        "Google's small model with good multilingual support.", "نموذج Google الصغير مع دعم جيد لعدة لغات."),
    CatalogModel("qwen3-17b", "Qwen3 1.7B", "Qwen", "unsloth/Qwen3-1.7B-GGUF", "Qwen3-1.7B-Q4_K_M.gguf", 1055, 3500, true,
        "Small but smart. Can think step by step; handles Arabic well.", "صغير وذكي. يفكّر خطوة بخطوة ويتعامل جيدًا مع العربية."),
    CatalogModel("qwen25-15b", "Qwen2.5 1.5B", "Qwen", "Qwen/Qwen2.5-1.5B-Instruct-GGUF", "qwen2.5-1.5b-instruct-q4_k_m.gguf", 1100, 3500, false,
        "Reliable everyday assistant.", "مساعد يومي موثوق."),
    CatalogModel("deepseek-r1-15b", "DeepSeek R1 Distill 1.5B", "DeepSeek", "bartowski/DeepSeek-R1-Distill-Qwen-1.5B-GGUF", "DeepSeek-R1-Distill-Qwen-1.5B-Q4_K_M.gguf", 1066, 3500, true,
        "DeepSeek-R1 reasoning distilled into 1.5B. Shows its thinking; good at math and logic.", "تفكير DeepSeek-R1 مُقطَّر في نموذج 1.5B. يعرض تفكيره ويتميّز في الحساب والمنطق."),
    CatalogModel("gemma2-2b", "Gemma 2 2B", "Gemma", "bartowski/gemma-2-2b-it-GGUF", "gemma-2-2b-it-Q4_K_M.gguf", 1700, 4500, false,
        "Natural, fluent writing.", "كتابة طبيعية وسلسة."),
    CatalogModel("qwen25-3b", "Qwen2.5 3B", "Qwen", "Qwen/Qwen2.5-3B-Instruct-GGUF", "qwen2.5-3b-instruct-q4_k_m.gguf", 2100, 5500, false,
        "Strong all-rounder for mid-range phones.", "نموذج قوي ومتعدد الاستخدامات للهواتف المتوسطة."),
    CatalogModel("llama32-3b", "Llama 3.2 3B", "Llama", "bartowski/Llama-3.2-3B-Instruct-GGUF", "Llama-3.2-3B-Instruct-Q4_K_M.gguf", 2000, 5500, false,
        "Good quality for its size.", "جودة جيدة بالنسبة لحجمه."),
    CatalogModel("qwen3-4b", "Qwen3 4B", "Qwen", "unsloth/Qwen3-4B-GGUF", "Qwen3-4B-Q4_K_M.gguf", 2385, 5500, true,
        "Best small all-rounder: strong reasoning, multilingual (including Arabic).", "أفضل نموذج صغير متكامل: تفكير قوي ودعم لغات متعددة منها العربية."),
    CatalogModel("gemma3-4b", "Gemma 3 4B", "Gemma", "unsloth/gemma-3-4b-it-GGUF", "gemma-3-4b-it-Q4_K_M.gguf", 2375, 5500, false,
        "Excellent multilingual quality (140+ languages).", "جودة ممتازة بلغات متعددة (أكثر من 140 لغة)."),
    CatalogModel("phi4-mini", "Phi-4 mini 3.8B", "Phi", "unsloth/Phi-4-mini-instruct-GGUF", "Phi-4-mini-instruct-Q4_K_M.gguf", 2375, 5500, false,
        "Microsoft's compact model, strong at reasoning and code.", "نموذج Microsoft المدمج، قوي في الاستدلال والبرمجة."),
    CatalogModel("deepseek-r1-7b", "DeepSeek R1 Distill 7B", "DeepSeek", "lmstudio-community/DeepSeek-R1-Distill-Qwen-7B-GGUF", "DeepSeek-R1-Distill-Qwen-7B-Q4_K_M.gguf", 4460, 10000, true,
        "Full 7B R1 distillation. Needs a high-end phone (12 GB RAM or more).", "تقطير R1 الكامل بحجم 7B. يحتاج هاتفًا قويًا (ذاكرة 12 جيجا أو أكثر)."),
    CatalogModel("deepseek-r1-llama-8b", "DeepSeek R1 Distill Llama 8B", "DeepSeek", "unsloth/DeepSeek-R1-Distill-Llama-8B-GGUF", "DeepSeek-R1-Distill-Llama-8B-Q4_K_M.gguf", 4690, 10000, true,
        "R1 reasoning on a Llama 8B base. High-end phones only.", "تفكير R1 على أساس Llama 8B. للهواتف القوية فقط."),
    CatalogModel("qwen3-8b", "Qwen3 8B", "Qwen", "unsloth/Qwen3-8B-GGUF", "Qwen3-8B-Q4_K_M.gguf", 4790, 10000, true,
        "Top quality in this list. High-end phones only (12 GB RAM or more).", "أعلى جودة في القائمة. للهواتف القوية فقط (ذاكرة 12 جيجا أو أكثر)."),
)

val CatalogFamilies: List<String> = Catalog.map { it.family }.distinct()

/** The model suggested for this much RAM. */
fun recommendedModelId(totalRamMb: Long): String = when {
    totalRamMb >= 10000 -> "qwen3-8b"
    totalRamMb >= 5500 -> "qwen3-4b"
    totalRamMb >= 3500 -> "qwen3-17b"
    else -> "qwen25-05b"
}

/** Accepts a Hugging Face link ("https://huggingface.co/user/repo/resolve/main/x.gguf", "/blob/" links too), any direct .gguf link, or "user/repo/file.gguf". */
fun parseModelLink(raw: String): CatalogModel? {
    val s = raw.trim()
    val url: String = when {
        s.startsWith("http://") || s.startsWith("https://") ->
            s.substringBefore('?').substringBefore('#').replace("/blob/", "/resolve/")
        Regex("^[\\w.-]+/[\\w.-]+/.+\\.gguf$", RegexOption.IGNORE_CASE).matches(s) -> {
            val parts = s.split('/')
            "https://huggingface.co/${parts[0]}/${parts[1]}/resolve/main/${parts.drop(2).joinToString("/")}"
        }
        else -> return null
    }
    if (!url.lowercase().endsWith(".gguf")) return null
    val last = try { URLDecoder.decode(url.substringAfterLast('/'), "UTF-8") } catch (e: Exception) { url.substringAfterLast('/') }
    val safe = last.replace(Regex("[^A-Za-z0-9._-]"), "_")
    if (safe.length < 6) return null
    return CatalogModel("link:$safe", safe.removeSuffix(".gguf"), "Custom", "", safe, 0, 0, url = url)
}

object ModelDownloader {
    private fun isGguf(f: File) = runCatching { f.inputStream().use { s -> ByteArray(4).also { s.read(it) } }.toString(Charsets.US_ASCII) == "GGUF" }.getOrDefault(false)

    /** Resumable download from Hugging Face; emits progress 0..1. The file is only published once it is a valid GGUF. */
    fun download(m: CatalogModel, dest: File, token: String? = null): Flow<Float> = flow {
        dest.parentFile!!.mkdirs()
        val part = File(dest.path + ".part")
        var have = if (part.exists()) part.length() else 0L
        val c = (URL(m.url ?: "https://huggingface.co/${m.repo}/resolve/main/${m.file}").openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 30_000
            setRequestProperty("User-Agent", "KanboAI/0.1")
            if (have > 0) setRequestProperty("Range", "bytes=$have-")
            token?.let { setRequestProperty("Authorization", "Bearer $it") }
        }
        try {
            val code = c.responseCode
            if (code == 416) {   // the .part file is already complete
                if (!isGguf(part)) { part.delete(); throw IOException("Corrupt partial file, try again") }
                if (!part.renameTo(dest)) throw IOException("Cannot save model")
                emit(1f); return@flow
            }
            if (code != 200 && code != 206) throw IOException("HTTP $code")
            if (code == 200) have = 0   // server ignored the Range header: start over
            val len = c.contentLengthLong
            val total = if (len > 0) have + len else -1L
            if (len > 0 && len > StatFs(dest.parentFile!!.path).availableBytes - 200L * 1048576) throw IOException("No space")
            var done = have
            var last = -1f
            FileOutputStream(part, have > 0).use { out ->
                c.inputStream.use { inp ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = inp.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val p = done.toFloat() / total
                            if (p - last >= 0.005f) { last = p; emit(p.coerceAtMost(1f)) }
                        }
                    }
                }
            }
            if (total > 0 && part.length() != total) throw IOException("Incomplete download, try again")
            if (!isGguf(part)) { part.delete(); throw IOException("Downloaded file is not a valid GGUF") }
            if (!part.renameTo(dest)) throw IOException("Cannot save model")
            emit(1f)
        } finally {
            c.disconnect()
        }
    }.flowOn(Dispatchers.IO)
}
