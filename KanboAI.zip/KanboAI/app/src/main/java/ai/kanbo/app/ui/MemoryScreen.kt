@file:OptIn(ExperimentalMaterial3Api::class)

package ai.kanbo.app.ui

import ai.kanbo.app.R
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp

@Composable
fun MemoryScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var showAdd by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    val mems = vm.memory.items

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.memory)) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back)) }
                },
                actions = {
                    if (mems.isNotEmpty()) TextButton(onClick = { confirmClear = true }) { Text(stringResource(R.string.memory_clear_all)) }
                },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAdd = true },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text(stringResource(R.string.memory_add)) },
            )
        },
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Surface(shape = RoundedCornerShape(20.dp), color = cs.secondaryContainer, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
                        Icon(Icons.Filled.Memory, contentDescription = null, tint = cs.onSecondaryContainer)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(stringResource(R.string.memory_desc), style = MaterialTheme.typography.bodyMedium, color = cs.onSecondaryContainer)
                            Spacer(Modifier.height(10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(stringResource(R.string.memory_use), Modifier.weight(1f), style = MaterialTheme.typography.labelLarge, color = cs.onSecondaryContainer)
                                Switch(checked = vm.prefs.memoryEnabled, onCheckedChange = { vm.prefs.memoryEnabled = it; vm.prefs.save() })
                            }
                        }
                    }
                }
            }
            if (mems.isEmpty()) {
                item {
                    Text(
                        stringResource(R.string.memory_empty),
                        Modifier.fillMaxWidth().padding(24.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                    )
                }
            }
            items(mems.toList(), key = { it.id }) { m ->
                Surface(shape = RoundedCornerShape(18.dp), color = cs.surfaceContainerLow, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            m.text,
                            Modifier.weight(1f).padding(vertical = 8.dp),
                            style = MaterialTheme.typography.bodyMedium.copy(textDirection = TextDirection.Content),
                        )
                        IconButton(onClick = { vm.memory.remove(m.id) }) {
                            Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.delete))
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        var t by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text(stringResource(R.string.memory_add)) },
            text = {
                OutlinedTextField(
                    value = t,
                    onValueChange = { t = it },
                    placeholder = { Text(stringResource(R.string.memory_hint)) },
                    minLines = 2,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.memory.add(t); showAdd = false }) { Text(stringResource(R.string.save)) }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
    if (confirmClear) {
        ConfirmDialog(
            title = stringResource(R.string.memory_clear_title),
            text = stringResource(R.string.memory_desc),
            confirmLabel = stringResource(R.string.memory_clear_all),
            onConfirm = { vm.memory.clear(); confirmClear = false },
            onDismiss = { confirmClear = false },
        )
    }
}
