package ai.kanbo.app

import ai.kanbo.app.ui.KanboRoot
import ai.kanbo.app.ui.KanboTheme
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefs = (application as KanboApp).prefs
        setContent {
            KanboTheme(themeMode = prefs.themeMode, dynamic = prefs.dynamicColor) { KanboRoot() }
        }
    }
}
