package ai.kanbo.app.engine

import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class LlamaEngine(private val app: Context) {
    private val mutex = Mutex()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val ready by lazy { NativeBridge.nativeInit(app.applicationInfo.nativeLibraryDir) }
    @Volatile private var handle = 0L
    @Volatile private var lastUse = SystemClock.elapsedRealtime()
    @Volatile private var pendingThreads = 0
    private val _loaded = MutableStateFlow<String?>(null)
    val loaded: StateFlow<String?> = _loaded

    init {
        // free RAM automatically when the model sits idle
        scope.launch {
            while (true) {
                delay(30_000)
                if (SystemClock.elapsedRealtime() - lastUse > 180_000) unloadIfIdle()
            }
        }
    }

    suspend fun inspect(path: String): ModelInfo? = withContext(Dispatchers.IO) {
        ready
        NativeBridge.nativeInspect(path)?.let { ModelInfo(it[0].toInt(), it[1].toInt(), it[2].toInt(), it[3].toInt(), it[4].toInt()) }
    }

    suspend fun load(path: String, name: String, c: EngineConfig): Boolean = mutex.withLock {
        withContext(Dispatchers.Default) {
            freeLocked()
            ready
            val h = NativeBridge.nativeLoad(path, c.nCtx, c.nBatch, c.nThreads, c.useMmap, c.kv.code, c.flashAttn)
            handle = h
            pendingThreads = 0
            lastUse = SystemClock.elapsedRealtime()
            _loaded.value = if (h != 0L) name else null
            h != 0L
        }
    }

    private fun freeLocked() {
        if (handle != 0L) { NativeBridge.nativeFree(handle); handle = 0L; _loaded.value = null }
    }

    fun unloadIfIdle() {
        scope.launch { if (mutex.tryLock()) try { freeLocked() } finally { mutex.unlock() } }
    }

    /** Applied safely at the start of the next generation (used by the thermal guard). */
    fun requestThreads(n: Int) { pendingThreads = n }

    fun generate(history: List<ChatMsg>, sp: SamplerParams): Flow<String> = callbackFlow {
        val job = launch(Dispatchers.Default) {
            mutex.withLock {
                val h = handle
                if (h == 0L) { close(EngineException(-1)); return@withLock }
                if (pendingThreads > 0) { NativeBridge.nativeSetThreads(h, pendingThreads); pendingThreads = 0 }
                val rc = NativeBridge.nativeGenerate(
                    h,
                    Array(history.size) { history[it].role },
                    Array(history.size) { history[it].text.toByteArray(Charsets.UTF_8) },
                    sp.maxTokens, sp.temperature, sp.topP, sp.topK,
                    TokenListener { trySend(String(it, Charsets.UTF_8)).isSuccess },
                )
                lastUse = SystemClock.elapsedRealtime()
                if (rc < 0) close(EngineException(rc)) else close()
            }
        }
        awaitClose { val h = handle; if (h != 0L && job.isActive) NativeBridge.nativeCancel(h) }
    }.buffer(Channel.UNLIMITED)

    /** (prompt tokens/s, generation tokens/s) of the last run. */
    fun stats(): Pair<Double, Double> {
        val h = handle
        if (h == 0L) return 0.0 to 0.0
        val d = NativeBridge.nativeStats(h)
        return d[0] to d[1]
    }
}
