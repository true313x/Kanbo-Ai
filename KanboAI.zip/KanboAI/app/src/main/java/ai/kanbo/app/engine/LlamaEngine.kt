package ai.kanbo.app.engine

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.RemoteException
import android.os.SystemClock
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * UI-side client of [EngineService] (separate process).
 *
 * Invariant: nothing here can wait forever. Every wait has a timeout, and a dead / unreachable engine
 * process is always turned into an [EngineException] instead of a silent hang.
 */
class LlamaEngine(private val app: Context) {
    private companion object {
        const val CONNECT_TIMEOUT_MS = 20_000L
        const val INSPECT_TIMEOUT_MS = 30_000L
        const val UNLOAD_TIMEOUT_MS = 30_000L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val loadMutex = Mutex()
    private val pending = ConcurrentHashMap<Int, CompletableDeferred<Bundle>>()
    private val ids = AtomicInteger()
    @Volatile private var service: Messenger? = null
    @Volatile private var connected = CompletableDeferred<Unit>()
    @Volatile private var bound = false
    @Volatile private var sink: ((String) -> Unit)? = null
    @Volatile private var done: ((Int) -> Unit)? = null
    @Volatile private var genId = 0
    @Volatile private var lastStats = 0.0 to 0.0
    @Volatile private var lastUse = SystemClock.elapsedRealtime()
    @Volatile private var safeCpu = false
    private val _loaded = MutableStateFlow<String?>(null)
    val loaded: StateFlow<String?> = _loaded

    private val reply = Messenger(Handler(Looper.getMainLooper()) { m -> onReply(m); true })
    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            EngineLog.w("engine connected")
            service = Messenger(b)
            connected.complete(Unit)
        }
        override fun onServiceDisconnected(n: ComponentName) = onCrash("service disconnected")
        override fun onBindingDied(n: ComponentName) = onCrash("binding died")
        override fun onNullBinding(n: ComponentName) = onCrash("null binding")
    }

    init {
        EngineLog.init(app)
        scope.launch {
            while (true) {
                delay(30_000)
                if (_loaded.value != null && SystemClock.elapsedRealtime() - lastUse > 180_000) unloadIfIdle()
            }
        }
    }

    /** Drops the binding on purpose: the next call binds again and gets a fresh process (no OS restart back-off). */
    private fun unbind() {
        service = null
        connected.completeExceptionally(EngineException(EngineException.CRASHED))  // no-op if already connected
        connected = CompletableDeferred()
        if (bound) { bound = false; runCatching { app.unbindService(conn) } }
    }

    private fun onCrash(reason: String, code: Int = EngineException.CRASHED) {
        EngineLog.w("engine lost: $reason")
        unbind()
        _loaded.value = null
        val ex = EngineException(code)
        val ps = pending.values.toList()
        pending.clear()
        ps.forEach { it.completeExceptionally(ex) }
        done?.invoke(code)
    }

    /** Kills the engine process (even if it is stuck in native code) and forgets all state. */
    fun restartEngine() {
        if (bound || service != null) {
            runCatching { service?.send(Message.obtain(null, Proto.EXIT, 0, 0)) }
            onCrash("restart requested", EngineException.CANCELLED)
        }
    }

    private fun onReply(m: Message) {
        val d = m.data
        when (m.what) {
            Proto.R_OK -> pending.remove(m.arg1)?.complete(d)
            Proto.R_ERR -> {
                val msg = d.getString("msg")
                val p = pending.remove(m.arg1)
                if (p != null) p.completeExceptionally(EngineException(EngineException.REMOTE, msg))
                else if (m.arg1 == genId) { EngineLog.w("generation error: $msg"); done?.invoke(EngineException.REMOTE) }
            }
            Proto.R_TOKEN -> if (m.arg1 == genId) sink?.invoke(d.getString("t") ?: "")
            Proto.R_DONE -> if (m.arg1 == genId) {
                d.getDoubleArray("st")?.let { lastStats = it[0] to it[1] }
                done?.invoke(d.getInt("rc"))
            }
        }
    }

    private suspend fun ensure() {
        var attempt = 0
        while (true) {
            if (!bound) {
                bound = app.bindService(Intent(app, EngineService::class.java), conn, Context.BIND_AUTO_CREATE)
                if (!bound) throw EngineException(EngineException.NO_ENGINE, "cannot bind engine service")
            }
            val c = connected
            val ok = withTimeoutOrNull(CONNECT_TIMEOUT_MS) { c.await(); true }
            if (ok == true && service != null) return
            EngineLog.w("engine did not connect within ${CONNECT_TIMEOUT_MS / 1000}s (attempt ${attempt + 1})")
            unbind()
            if (++attempt >= 2) throw EngineException(EngineException.NO_ENGINE)
        }
    }

    private fun post(what: Int, id: Int, fill: Bundle.() -> Unit = {}): Boolean {
        val s = service ?: return false
        return try {
            s.send(Message.obtain(null, what, id, 0).apply { replyTo = reply; data = Bundle().apply(fill) })
            true
        } catch (e: RemoteException) { onCrash("send failed: $e"); false }
    }

    private suspend fun call(what: Int, timeoutMs: Long, fill: Bundle.() -> Unit): Bundle {
        ensure()
        val id = ids.incrementAndGet()
        val d = CompletableDeferred<Bundle>()
        pending[id] = d
        try {
            if (!post(what, id, fill)) throw EngineException(EngineException.CRASHED)
            return withTimeout(timeoutMs) { d.await() }
        } catch (e: TimeoutCancellationException) {
            EngineLog.w("engine op $what timed out after ${timeoutMs / 1000}s -> restarting the engine")
            restartEngine()
            throw EngineException(EngineException.TIMEOUT)
        } finally {
            pending.remove(id)
        }
    }

    /** Safe mode loads the baseline ARMv8.0 CPU kernels; the engine process restarts to apply it. */
    fun setSafe(v: Boolean) {
        if (v == safeCpu) return
        safeCpu = v
        restartEngine()
    }

    suspend fun inspect(path: String): ModelInfo? =
        call(Proto.INSPECT, INSPECT_TIMEOUT_MS) { putString("path", path); putBoolean("safe", safeCpu) }.getLongArray("v")?.let {
            ModelInfo(it[0].toInt(), it[1].toInt(), it[2].toInt(), it[3].toInt(), it[4].toInt(), if (it.size > 5) it[5].toInt() else 0)
        }

    suspend fun load(path: String, name: String, sizeMb: Long, c: EngineConfig): Boolean = loadMutex.withLock {
        call(Proto.LOAD, 120_000L + sizeMb * 150L) {
            putString("path", path); putInt("ctx", c.nCtx); putInt("batch", c.nBatch); putInt("threads", c.nThreads)
            putBoolean("mmap", c.useMmap); putInt("kv", c.kv.code); putBoolean("flash", c.flashAttn); putBoolean("safe", safeCpu)
        }
        lastUse = SystemClock.elapsedRealtime()
        _loaded.value = name
        true
    }

    fun requestThreads(n: Int) { if (_loaded.value != null) post(Proto.THREADS, 0) { putInt("n", n) } }

    fun unloadIfIdle() {
        scope.launch {
            if (_loaded.value != null && sink == null) {
                runCatching { call(Proto.UNLOAD, UNLOAD_TIMEOUT_MS) {} }
                _loaded.value = null
            }
        }
    }

    fun generate(history: List<ChatMsg>, sp: SamplerParams): Flow<String> = callbackFlow {
        ensure()
        val id = ids.incrementAndGet()
        genId = id
        sink = { trySend(it) }
        done = { rc -> sink = null; done = null; if (rc < 0) close(EngineException(rc)) else close() }
        if (!post(Proto.GEN, id) {
                putStringArray("roles", Array(history.size) { history[it].role })
                putStringArray("texts", Array(history.size) { history[it].text })
                putInt("max", sp.maxTokens); putFloat("temp", sp.temperature); putFloat("topP", sp.topP); putInt("topK", sp.topK)
            }) close(EngineException(EngineException.CRASHED))
        awaitClose { post(Proto.CANCEL, id); lastUse = SystemClock.elapsedRealtime(); sink = null; done = null }
    }.buffer(Channel.UNLIMITED)

    fun stats(): Pair<Double, Double> = lastStats
}
