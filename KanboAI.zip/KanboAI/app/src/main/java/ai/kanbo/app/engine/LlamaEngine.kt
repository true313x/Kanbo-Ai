package ai.kanbo.app.engine

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.SystemClock
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/** UI-side client of [EngineService] (separate process). */
class LlamaEngine(private val app: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mutex = Mutex()
    private val pending = ConcurrentHashMap<Int, CompletableDeferred<Bundle>>()
    private val ids = AtomicInteger()
    private var service: Messenger? = null
    private var connected = CompletableDeferred<Unit>()
    private var bound = false
    @Volatile private var sink: ((String) -> Unit)? = null
    @Volatile private var done: ((Int) -> Unit)? = null
    @Volatile private var lastStats = 0.0 to 0.0
    @Volatile private var lastUse = SystemClock.elapsedRealtime()
    private var safeCpu = false
    private val _loaded = MutableStateFlow<String?>(null)
    val loaded: StateFlow<String?> = _loaded

    private val reply = Messenger(Handler(Looper.getMainLooper()) { m -> onReply(m); true })
    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) { service = Messenger(b); connected.complete(Unit) }
        override fun onServiceDisconnected(n: ComponentName) { onCrash() }
    }

    init {
        scope.launch {
            while (true) {
                delay(30_000)
                if (_loaded.value != null && SystemClock.elapsedRealtime() - lastUse > 180_000) unloadIfIdle()
            }
        }
    }

    private fun onCrash() {
        service = null
        connected = CompletableDeferred()
        _loaded.value = null
        val ex = EngineException(-9)
        pending.values.forEach { it.completeExceptionally(ex) }
        pending.clear()
        done?.invoke(-9)
    }

    private fun onReply(m: Message) {
        val d = m.data
        when (m.what) {
            Proto.R_OK -> pending.remove(m.arg1)?.complete(d)
            Proto.R_ERR -> {
                val p = pending.remove(m.arg1)
                if (p != null) p.completeExceptionally(IllegalStateException(d.getString("msg"))) else done?.invoke(-5)
            }
            Proto.R_TOKEN -> sink?.invoke(d.getString("t") ?: "")
            Proto.R_DONE -> { d.getDoubleArray("st")?.let { lastStats = it[0] to it[1] }; done?.invoke(d.getInt("rc")) }
        }
    }

    private suspend fun ensure() {
        if (!bound) bound = app.bindService(Intent(app, EngineService::class.java), conn, Context.BIND_AUTO_CREATE)
        connected.await()
    }

    private fun post(what: Int, id: Int, fill: Bundle.() -> Unit = {}) {
        try {
            service?.send(Message.obtain(null, what, id, 0).apply { replyTo = reply; data = Bundle().apply(fill) })
        } catch (e: Exception) { onCrash() }
    }

    private suspend fun call(what: Int, fill: Bundle.() -> Unit): Bundle {
        ensure()
        val id = ids.incrementAndGet()
        val d = CompletableDeferred<Bundle>()
        pending[id] = d
        post(what, id, fill)
        return d.await()
    }

    /** Safe mode loads the baseline ARMv8.0 CPU kernels; the engine process restarts to apply it. */
    fun setSafe(v: Boolean) {
        if (v == safeCpu) return
        safeCpu = v
        if (service != null) post(Proto.EXIT, 0)
    }

    suspend fun inspect(path: String): ModelInfo? =
        call(Proto.INSPECT) { putString("path", path); putBoolean("safe", safeCpu) }.getLongArray("v")?.let {
            ModelInfo(it[0].toInt(), it[1].toInt(), it[2].toInt(), it[3].toInt(), it[4].toInt())
        }

    suspend fun load(path: String, name: String, c: EngineConfig): Boolean = mutex.withLock {
        call(Proto.LOAD) {
            putString("path", path); putInt("ctx", c.nCtx); putInt("batch", c.nBatch); putInt("threads", c.nThreads)
            putBoolean("mmap", c.useMmap); putInt("kv", c.kv.code); putBoolean("flash", c.flashAttn); putBoolean("safe", safeCpu)
        }
        lastUse = SystemClock.elapsedRealtime()
        _loaded.value = name
        true
    }

    fun requestThreads(n: Int) { if (_loaded.value != null) post(Proto.THREADS, 0) { putInt("n", n) } }

    fun unloadIfIdle() {
        scope.launch {
            if (_loaded.value != null && sink == null) {
                runCatching { call(Proto.UNLOAD) {} }
                _loaded.value = null
            }
        }
    }

    fun generate(history: List<ChatMsg>, sp: SamplerParams): Flow<String> = callbackFlow {
        ensure()
        sink = { trySend(it) }
        done = { rc -> sink = null; done = null; if (rc < 0) close(EngineException(rc)) else close() }
        post(Proto.GEN, ids.incrementAndGet()) {
            putStringArray("roles", Array(history.size) { history[it].role })
            putStringArray("texts", Array(history.size) { history[it].text })
            putInt("max", sp.maxTokens); putFloat("temp", sp.temperature); putFloat("topP", sp.topP); putInt("topK", sp.topK)
        }
        awaitClose { post(Proto.CANCEL, 0); lastUse = SystemClock.elapsedRealtime(); sink = null }
    }.buffer(Channel.UNLIMITED)

    fun stats(): Pair<Double, Double> = lastStats
}
