package ai.kanbo.app.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class MemoryItem(val id: String, val text: String, val created: Long)

/**
 * Long-term memory: short facts the user shared or asked to be remembered. Stored only on the device and injected into
 * the system prompt of every chat. Capture is rule-based (explicit phrases in English / Arabic): fast, predictable, and
 * it costs no extra model inference on a phone.
 */
class MemoryStore(ctx: Context) {
    private val file = File(ctx.filesDir, "memory.json")
    val items = mutableStateListOf<MemoryItem>()

    init {
        try {
            if (file.exists()) {
                val a = JSONArray(file.readText())
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    items.add(MemoryItem(o.getString("id"), o.getString("t"), o.optLong("c", 0L)))
                }
            }
        } catch (e: Exception) {
            items.clear()
        }
    }

    private fun persist() {
        try {
            val a = JSONArray()
            items.forEach { a.put(JSONObject().put("id", it.id).put("t", it.text).put("c", it.created)) }
            val tmp = File(file.path + ".tmp")
            tmp.writeText(a.toString())
            if (!tmp.renameTo(file)) {
                file.delete()
                tmp.renameTo(file)
            }
        } catch (e: Exception) {
            // memory is a convenience: never crash because of it
        }
    }

    /** Adds one fact. Returns false when it is empty or already known. */
    fun add(raw: String): Boolean {
        val t = raw.replace(Regex("\\s+"), " ").trim().trimEnd('.', '!', '،', ',', ' ').take(200)
        if (t.length < 3) return false
        val low = t.lowercase()
        if (items.any { val o = it.text.lowercase(); o == low || o.contains(low) || low.contains(o) }) return false
        items.add(MemoryItem(UUID.randomUUID().toString(), t, System.currentTimeMillis()))
        while (items.size > MAX_ITEMS) items.removeAt(0)
        persist()
        return true
    }

    fun remove(id: String) {
        items.removeAll { it.id == id }
        persist()
    }

    fun clear() {
        items.clear()
        persist()
    }

    /** Looks for explicit "remember ..." / "my name is ..." statements. Returns the facts that were newly saved. */
    fun capture(text: String): List<String> {
        val saved = ArrayList<String>()
        for (f in extract(text)) if (add(f)) saved.add(f)
        return saved
    }

    /** Text block for the system prompt, newest facts first, limited in size (small models have small contexts). */
    fun promptBlock(maxChars: Int = 900): String {
        if (items.isEmpty()) return ""
        val sb = StringBuilder(
            "Facts the user shared about themselves or asked you to remember (they speak in the first person). " +
                "Use them naturally when relevant; do not recite them unprompted:\n",
        )
        var used = sb.length
        for (m in items.asReversed()) {
            val line = "- ${m.text}\n"
            if (used + line.length > maxChars) break
            sb.append(line)
            used += line.length
        }
        return sb.toString().trimEnd()
    }

    companion object {
        private const val MAX_ITEMS = 60
        private val SPLIT = Regex("(?<=[.!?\u061F\\n])")
        private val EN_REMEMBER = Regex("(?i)\\b(?:remember|keep in mind|don't forget|do not forget)\\s+(?:that\\s+)?(.{3,200})")
        private val EN_NAME = Regex("(?i)\\b(?:my name is|call me)\\s+([\\p{L}][\\p{L}'\\-]{1,24}(?:\\s+[\\p{L}][\\p{L}'\\-]{1,24})?)")
        private val EN_FACT = Regex("(?i)\\bI\\s+(?:live in|am from|work at|work as|study at|prefer)\\s+.{2,80}")
        private val AR_REMEMBER = Regex("(?:تذكّر|تذكر|لا تنس|لا تنسَ|احفظ)\\s*(?:أن|ان|إن|أنني|أنني|أني|اني)?\\s*(.{3,200})")
        private val AR_NAME = Regex("(?:اسمي|ناديني|نادني)\\s+([\\p{L}]{2,24}(?:\\s+[\\p{L}]{2,24})?)")
        private val AR_FACT = Regex("(?:أسكن في|اسكن في|أعيش في|اعيش في|أنا من|أعمل في|اعمل في|أعمل ك|أدرس في|ادرس في|أفضل)\\s+.{2,80}")

        fun extract(text: String): List<String> {
            val out = LinkedHashSet<String>()
            for (raw in text.split(SPLIT)) {
                val s = raw.trim()
                if (s.length < 4) continue
                if (s.contains('?') || s.contains('\u061F')) continue   // a question is not a statement to remember
                EN_REMEMBER.find(s)?.let { out.add(it.groupValues[1]) }
                AR_REMEMBER.find(s)?.let { out.add(it.groupValues[1]) }
                EN_NAME.find(s)?.let { out.add("User's name is " + it.groupValues[1].trim()) }
                AR_NAME.find(s)?.let { out.add("اسم المستخدم " + it.groupValues[1].trim()) }
                EN_FACT.find(s)?.let { out.add(it.value) }
                AR_FACT.find(s)?.let { out.add(it.value) }
            }
            return out.toList()
        }
    }
}
