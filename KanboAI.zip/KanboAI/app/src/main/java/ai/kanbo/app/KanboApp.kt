package ai.kanbo.app

import ai.kanbo.app.engine.LlamaEngine
import android.app.Application
import android.content.ComponentCallbacks2

class KanboApp : Application() {
    private val lazyEngine = lazy { LlamaEngine(this) }
    val engine: LlamaEngine get() = lazyEngine.value

    @Suppress("DEPRECATION")
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (lazyEngine.isInitialized() && level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL &&
            level != ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) engine.unloadIfIdle()
    }
}
