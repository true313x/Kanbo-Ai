package ai.kanbo.app.ui

import ai.kanbo.app.R
import ai.kanbo.app.engine.ChatMsg
import ai.kanbo.app.models.Catalog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun KanboRoot(vm: ChatViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(bottomBar = {
        NavigationBar {
            NavigationBarItem(tab == 0, { tab = 0 }, { Text("💬") }, label = { Text(stringResource(R.string.chat)) })
            NavigationBarItem(tab == 1, { tab = 1 }, { Text("🧠") }, label = { Text(stringResource(R.string.models)) })
        }
    }) { pad ->
        Box(Modifier.padding(pad)) { if (tab == 0) ChatScreen(vm) else ModelsScreen(vm) }
    }
}

@Composable
fun ChatScreen(vm: ChatViewModel) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val name by vm.loaded.collectAsStateWithLifecycle()
    val n = name
    val st = vm.status

    LaunchedEffect(vm.messages.size, vm.messages.lastOrNull()?.text?.length) {
        if (vm.messages.isNotEmpty()) listState.scrollToItem(vm.messages.lastIndex)
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        Text(
            when {
                st != null -> stringResource(st)
                n == null -> stringResource(R.string.no_model)
                else -> n + if (vm.tps > 0) " · " + stringResource(R.string.speed, vm.tps) else ""
            },
            Modifier.padding(horizontal = 16.dp, vertical = 8.dp), style = MaterialTheme.typography.labelMedium,
        )
        LazyColumn(
            Modifier.weight(1f), state = listState,
            contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
        ) { items(vm.messages) { Bubble(it) } }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, Modifier.weight(1f),
                placeholder = { Text(stringResource(R.string.hint)) }, maxLines = 5,
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { if (vm.streaming) vm.stop() else { vm.send(input); input = "" } }) {
                Text(stringResource(if (vm.streaming) R.string.stop else R.string.send))
            }
        }
    }
}

@Composable
private fun Bubble(m: ChatMsg) {
    val user = m.role == "user"
    Box(Modifier.fillMaxWidth(), contentAlignment = if (user) Alignment.CenterEnd else Alignment.CenterStart) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (user) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        ) { Text(m.text.ifEmpty { "…" }, Modifier.padding(12.dp)) }
    }
}

@Composable
fun ModelsScreen(vm: ChatViewModel) {
    val p = vm.profile
    val name by vm.loaded.collectAsStateWithLifecycle()
    val best = Catalog.lastOrNull { p.totalRamMb >= it.minRamMb }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text(stringResource(R.string.device, p.totalRamMb, p.perfCores, p.tier.name), style = MaterialTheme.typography.labelLarge) }
        items(Catalog) { m ->
            val prog = vm.progress[m.id]
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(m.name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        if (m == best) Text("⭐ " + stringResource(R.string.recommended), style = MaterialTheme.typography.labelSmall)
                    }
                    Text("${m.sizeMb} MB · ≥ ${m.minRamMb / 1000} GB RAM", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    when {
                        prog != null -> LinearProgressIndicator(progress = { prog }, modifier = Modifier.fillMaxWidth())
                        vm.isDownloaded(m) -> Button({ vm.load(m) }, enabled = name != m.name) {
                            Text(stringResource(if (name == m.name) R.string.loaded else R.string.load))
                        }
                        else -> OutlinedButton({ vm.download(m) }, enabled = p.totalRamMb >= m.minRamMb) {
                            Text(stringResource(R.string.download))
                        }
                    }
                }
            }
        }
    }
}
