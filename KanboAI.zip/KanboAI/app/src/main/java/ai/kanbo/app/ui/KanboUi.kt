@file:OptIn(ExperimentalMaterial3Api::class)

package ai.kanbo.app.ui

import ai.kanbo.app.R
import ai.kanbo.app.data.ChatMeta
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

const val SCREEN_CHAT = 0
const val SCREEN_MODELS = 1
const val SCREEN_SETTINGS = 2
const val SCREEN_MEMORY = 3

@Composable
fun KanboRoot(vm: ChatViewModel = viewModel()) {
    var screen by rememberSaveable { mutableStateOf(SCREEN_CHAT) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val running by vm.loaded.collectAsStateWithLifecycle()

    // after a model starts from the Models screen, go back to the chat
    LaunchedEffect(running) { if (running != null && screen == SCREEN_MODELS) screen = SCREEN_CHAT }

    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }
    BackHandler(enabled = screen != SCREEN_CHAT && !drawerState.isOpen) { screen = SCREEN_CHAT }

    val notice = vm.memoryNotice
    val savedLabel = stringResource(R.string.memory_saved)
    val manageLabel = stringResource(R.string.manage)
    LaunchedEffect(notice) {
        if (notice != null) {
            val r = snackbar.showSnackbar(message = "$savedLabel: $notice", actionLabel = manageLabel, duration = SnackbarDuration.Short)
            if (r == SnackbarResult.ActionPerformed) screen = SCREEN_MEMORY
            vm.clearMemoryNotice()
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = screen == SCREEN_CHAT || drawerState.isOpen,
        drawerContent = {
            ChatDrawer(
                vm = vm,
                onClose = { scope.launch { drawerState.close() } },
                onNavigate = { s -> screen = s; scope.launch { drawerState.close() } },
            )
        },
    ) {
        when (screen) {
            SCREEN_MODELS -> ModelsScreen(vm, onBack = { screen = SCREEN_CHAT })
            SCREEN_SETTINGS -> SettingsScreen(vm, onBack = { screen = SCREEN_CHAT }, onMemory = { screen = SCREEN_MEMORY })
            SCREEN_MEMORY -> MemoryScreen(vm, onBack = { screen = SCREEN_CHAT })
            else -> ChatScreen(vm, snackbar, onMenu = { scope.launch { drawerState.open() } }, onModels = { screen = SCREEN_MODELS })
        }
    }
}

// ============================================================================ shared dialog

@Composable
fun ConfirmDialog(title: String, text: String, confirmLabel: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(confirmLabel, color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

// ============================================================================ drawer (chat history)

private sealed interface DrawerRow {
    data class Header(val res: Int) : DrawerRow
    data class Item(val meta: ChatMeta) : DrawerRow
}

private fun groupRes(m: ChatMeta): Int {
    if (m.pinned) return R.string.pinned
    val d = Instant.ofEpochMilli(m.updated).atZone(ZoneId.systemDefault()).toLocalDate()
    val days = ChronoUnit.DAYS.between(d, LocalDate.now())
    return when {
        days <= 0L -> R.string.today
        days == 1L -> R.string.yesterday
        days < 8L -> R.string.previous_7
        else -> R.string.older
    }
}

private fun buildRows(chats: List<ChatMeta>, query: String): List<DrawerRow> {
    val q = query.trim()
    val list = if (q.isEmpty()) chats else chats.filter { it.title.contains(q, ignoreCase = true) }
    val out = ArrayList<DrawerRow>()
    var lastRes = -1
    for (m in list) {
        val g = groupRes(m)
        if (g != lastRes) { out.add(DrawerRow.Header(g)); lastRes = g }
        out.add(DrawerRow.Item(m))
    }
    return out
}

@Composable
private fun ChatDrawer(vm: ChatViewModel, onClose: () -> Unit, onNavigate: (Int) -> Unit) {
    var query by remember { mutableStateOf("") }
    var renameTarget by remember { mutableStateOf<ChatMeta?>(null) }
    var deleteTarget by remember { mutableStateOf<ChatMeta?>(null) }
    val rows = buildRows(vm.chats, query)
    val cs = MaterialTheme.colorScheme

    ModalDrawerSheet {
        Column(Modifier.fillMaxHeight()) {
            Row(Modifier.padding(start = 24.dp, end = 12.dp, top = 16.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(34.dp).clip(CircleShape).background(cs.primary), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = cs.onPrimary, modifier = Modifier.size(19.dp))
                }
                Spacer(Modifier.width(12.dp))
                Text(stringResource(R.string.app_name), style = MaterialTheme.typography.titleLarge)
            }
            FilledTonalButton(
                onClick = { vm.newChat(); onClose() },
                enabled = !vm.streaming,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            ) {
                Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.new_chat))
            }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text(stringResource(R.string.search_chats)) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
            )
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                if (rows.isEmpty()) {
                    item {
                        Text(
                            stringResource(R.string.no_chats),
                            Modifier.padding(horizontal = 28.dp, vertical = 16.dp),
                            color = cs.onSurfaceVariant,
                        )
                    }
                }
                items(rows, key = { r -> when (r) { is DrawerRow.Header -> "h" + r.res; is DrawerRow.Item -> r.meta.id } }) { row ->
                    when (row) {
                        is DrawerRow.Header -> Text(
                            stringResource(row.res),
                            Modifier.padding(start = 28.dp, top = 14.dp, bottom = 4.dp),
                            style = MaterialTheme.typography.labelMedium,
                            color = cs.primary,
                        )
                        is DrawerRow.Item -> ChatRow(
                            meta = row.meta,
                            selected = row.meta.id == vm.currentId,
                            enabled = !vm.streaming,
                            onClick = { vm.openChat(row.meta.id); onClose() },
                            onPin = { vm.togglePin(row.meta.id) },
                            onRename = { renameTarget = row.meta },
                            onDelete = { deleteTarget = row.meta },
                        )
                    }
                }
            }
            HorizontalDivider(Modifier.padding(horizontal = 16.dp))
            NavigationDrawerItem(
                label = { Text(stringResource(R.string.models)) },
                selected = false,
                onClick = { onNavigate(SCREEN_MODELS) },
                icon = { Icon(Icons.Filled.Download, contentDescription = null) },
                modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
            )
            NavigationDrawerItem(
                label = { Text(stringResource(R.string.memory)) },
                selected = false,
                onClick = { onNavigate(SCREEN_MEMORY) },
                icon = { Icon(Icons.Filled.Memory, contentDescription = null) },
                modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
            )
            NavigationDrawerItem(
                label = { Text(stringResource(R.string.settings)) },
                selected = false,
                onClick = { onNavigate(SCREEN_SETTINGS) },
                icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
            )
            Spacer(Modifier.height(8.dp))
        }
    }

    renameTarget?.let { t ->
        RenameDialog(
            initial = t.title,
            onDismiss = { renameTarget = null },
            onSave = { vm.renameChat(t.id, it); renameTarget = null },
        )
    }
    deleteTarget?.let { t ->
        ConfirmDialog(
            title = stringResource(R.string.delete_chat_title),
            text = stringResource(R.string.delete_chat_msg),
            confirmLabel = stringResource(R.string.delete),
            onConfirm = { vm.deleteChat(t.id); deleteTarget = null },
            onDismiss = { deleteTarget = null },
        )
    }
}

@Composable
private fun ChatRow(
    meta: ChatMeta,
    selected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    onPin: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(28.dp),
        color = if (selected) cs.secondaryContainer else Color.Transparent,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
    ) {
        Row(Modifier.padding(start = 16.dp, end = 4.dp).heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
            if (meta.pinned) {
                Icon(Icons.Filled.PushPin, contentDescription = null, tint = cs.primary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
            }
            Text(
                meta.title,
                Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Content),
            )
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, contentDescription = null) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text(stringResource(if (meta.pinned) R.string.unpin else R.string.pin)) },
                        leadingIcon = { Icon(Icons.Filled.PushPin, contentDescription = null) },
                        onClick = { menu = false; onPin() },
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.rename)) },
                        leadingIcon = { Icon(Icons.Filled.Edit, contentDescription = null) },
                        onClick = { menu = false; onRename() },
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.delete), color = cs.error) },
                        leadingIcon = { Icon(Icons.Filled.Close, contentDescription = null, tint = cs.error) },
                        onClick = { menu = false; onDelete() },
                    )
                }
            }
        }
    }
}

@Composable
private fun RenameDialog(initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.rename_chat)) },
        text = { OutlinedTextField(value = t, onValueChange = { t = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { onSave(t) }) { Text(stringResource(R.string.save)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

// ============================================================================ chat screen

@Composable
private fun ChatScreen(vm: ChatViewModel, snackbar: SnackbarHostState, onMenu: () -> Unit, onModels: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val loadedName by vm.loaded.collectAsStateWithLifecycle()
    // derived from the engine state: computed here so it refreshes whenever the model changes
    val showThinkingChip = vm.supportsThinkingToggle && loadedName != null
    val hasModels = vm.files.isNotEmpty()

    Scaffold(
        topBar = { ChatTopBar(vm, loadedName, onMenu, onModels) },
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = MaterialTheme.colorScheme.background,
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding()) {
            StatusBanner(vm)
            if (vm.loadingName != null) LinearProgressIndicator(Modifier.fillMaxWidth())
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (vm.messages.isEmpty()) {
                    EmptyState(hasModels, onModels, onSend = { vm.send(it) })
                } else {
                    MessageList(vm, listState)
                }
            }
            Composer(
                streaming = vm.streaming,
                busy = vm.loadingName != null,
                input = input,
                showThinking = showThinkingChip,
                thinkingOn = vm.prefs.thinking,
                onThinking = { vm.prefs.thinking = !vm.prefs.thinking; vm.prefs.save() },
                onInput = { input = it },
                onSend = { vm.send(input); input = "" },
                onStop = { vm.stop() },
            )
        }
    }
}

@Composable
private fun ChatTopBar(vm: ChatViewModel, loadedName: String?, onMenu: () -> Unit, onModels: () -> Unit) {
    TopAppBar(
        title = { ModelSwitcher(vm, loadedName, onModels) },
        navigationIcon = {
            IconButton(onClick = onMenu) { Icon(Icons.Filled.Menu, contentDescription = stringResource(R.string.menu)) }
        },
        actions = {
            IconButton(onClick = { vm.newChat() }, enabled = !vm.streaming) {
                Icon(Icons.Filled.Edit, contentDescription = stringResource(R.string.new_chat))
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
    )
}

/** Model picker in the top bar: tap to switch between downloaded models, or open the model library. */
@Composable
private fun ModelSwitcher(vm: ChatViewModel, loadedName: String?, onModels: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    val busy = vm.loadingName
    val active = loadedName ?: vm.activeName
    val title = busy ?: active ?: stringResource(R.string.choose_model)
    val sub: String? = when {
        busy != null -> stringResource(R.string.loading)
        loadedName == null && active != null -> stringResource(R.string.tap_to_load)
        loadedName != null && vm.tps > 0 -> stringResource(R.string.speed, vm.tps)
        else -> null
    }
    val canSwitch = !vm.streaming && busy == null

    Box {
        Surface(onClick = { open = true }, shape = RoundedCornerShape(50), color = cs.surfaceContainerHigh) {
            Row(Modifier.padding(start = 16.dp, end = 6.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f, fill = false)) {
                    Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (sub != null) {
                        Text(sub, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1)
                    }
                }
                Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
            }
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            if (vm.files.isEmpty()) {
                DropdownMenuItem(text = { Text(stringResource(R.string.no_models_yet)) }, onClick = { open = false; onModels() })
            }
            vm.files.forEach { f ->
                val n = vm.displayName(f)
                val on = n == loadedName
                DropdownMenuItem(
                    text = {
                        Column {
                            Text(n, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${f.length() / 1048576} MB", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                        }
                    },
                    leadingIcon = {
                        if (on) Icon(Icons.Filled.Check, contentDescription = null, tint = cs.primary) else Spacer(Modifier.size(24.dp))
                    },
                    enabled = canSwitch,
                    onClick = { open = false; vm.selectModel(f) },
                )
            }
            HorizontalDivider()
            DropdownMenuItem(
                text = { Text(stringResource(R.string.browse_models)) },
                leadingIcon = { Icon(Icons.Filled.Add, contentDescription = null) },
                onClick = { open = false; onModels() },
            )
        }
    }
}

@Composable
private fun StatusBanner(vm: ChatViewModel) {
    val st = vm.status ?: return
    val loading = vm.loadingName != null
    val cs = MaterialTheme.colorScheme
    Surface(
        color = if (loading) cs.surfaceContainerHigh else cs.errorContainer,
        contentColor = if (loading) cs.onSurface else cs.onErrorContainer,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
    ) {
        Row(Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(st, Modifier.weight(1f).padding(vertical = 8.dp), style = MaterialTheme.typography.bodyMedium)
            if (!loading) {
                IconButton(onClick = { vm.dismissStatus() }) { Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.close)) }
            }
        }
    }
}

@Composable
private fun EmptyState(hasModels: Boolean, onModels: () -> Unit, onSend: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val suggestions = listOf(
        stringResource(R.string.suggestion_1),
        stringResource(R.string.suggestion_2),
        stringResource(R.string.suggestion_3),
        stringResource(R.string.suggestion_4),
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(Modifier.size(68.dp).clip(CircleShape).background(cs.primaryContainer), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = cs.primary, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text(stringResource(R.string.greeting), style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(4.dp))
        Text(stringResource(R.string.greeting_sub), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
        Spacer(Modifier.height(28.dp))
        if (!hasModels) {
            Surface(shape = RoundedCornerShape(20.dp), color = cs.surfaceContainerLow, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(stringResource(R.string.no_models_yet), textAlign = TextAlign.Center)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = onModels) {
                        Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.get_models))
                    }
                }
            }
        } else {
            suggestions.forEach { s ->
                Surface(
                    onClick = { onSend(s) },
                    shape = RoundedCornerShape(18.dp),
                    color = cs.surfaceContainerLow,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                ) {
                    Text(
                        s,
                        Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                        style = MaterialTheme.typography.bodyMedium.copy(textDirection = TextDirection.Content),
                    )
                }
            }
        }
    }
}

@Composable
private fun MessageList(vm: ChatViewModel, listState: LazyListState) {
    val n = vm.messages.size
    LaunchedEffect(n) { if (n > 0) listState.animateScrollToItem(0) }
    // reverseLayout: the newest message is item 0 at the bottom, so a growing reply stays in view while it streams
    LazyColumn(
        Modifier.fillMaxSize(),
        state = listState,
        reverseLayout = true,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        items(n, key = { n - 1 - it }) { i ->
            val idx = n - 1 - i
            val m = vm.messages.getOrNull(idx)
            if (m != null) {
                if (m.role == "user") {
                    UserMessage(m.text)
                } else {
                    AssistantMessage(
                        text = m.text,
                        streaming = vm.streaming && idx == n - 1,
                        isLast = idx == n - 1,
                        onRegenerate = { vm.regenerate() },
                    )
                }
            }
        }
    }
}

@Composable
private fun UserMessage(text: String) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
        Surface(shape = RoundedCornerShape(22.dp), color = cs.primaryContainer, modifier = Modifier.widthIn(max = 320.dp)) {
            SelectionContainer {
                Text(
                    text,
                    Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    style = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Content),
                    color = cs.onPrimaryContainer,
                )
            }
        }
    }
}

@Composable
private fun AssistantMessage(text: String, streaming: Boolean, isLast: Boolean, onRegenerate: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val parsed = remember(text) { splitThink(text) }
    val thinking = parsed.thinking
    val clip = LocalClipboardManager.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(30.dp).clip(CircleShape).background(cs.primaryContainer), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = cs.primary, modifier = Modifier.size(17.dp))
        }
        Column(Modifier.weight(1f)) {
            if (thinking != null && (thinking.isNotBlank() || parsed.thinkingOpen)) {
                ThinkBlock(thinking, active = parsed.thinkingOpen && streaming)
            }
            if (parsed.answer.isNotBlank()) {
                MarkdownText(parsed.answer)
            } else if (streaming && (thinking == null || !parsed.thinkingOpen)) {
                CircularProgressIndicator(Modifier.padding(top = 6.dp).size(18.dp), strokeWidth = 2.dp)
            }
            if (!streaming && text.isNotBlank()) {
                Row(Modifier.padding(top = 4.dp)) {
                    IconButton(onClick = { clip.setText(AnnotatedString(parsed.answer.ifBlank { text })) }) {
                        Icon(Icons.Filled.ContentCopy, contentDescription = stringResource(R.string.copy), tint = cs.onSurfaceVariant, modifier = Modifier.size(19.dp))
                    }
                    if (isLast) {
                        IconButton(onClick = onRegenerate) {
                            Icon(Icons.Filled.Refresh, contentDescription = stringResource(R.string.regenerate), tint = cs.onSurfaceVariant, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ThinkBlock(text: String, active: Boolean) {
    var open by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = cs.surfaceContainerLow,
        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).animateContentSize(),
    ) {
        Column {
            Row(
                Modifier.clickable { open = !open }.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Psychology, contentDescription = null, tint = cs.primary, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    stringResource(if (active) R.string.thinking else R.string.thought_process),
                    Modifier.weight(1f),
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.onSurfaceVariant,
                )
                if (active) {
                    CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                } else {
                    Icon(if (open) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown, contentDescription = null, tint = cs.onSurfaceVariant)
                }
            }
            if (open || active) {
                Text(
                    if (open) text else text.takeLast(350),
                    Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                    style = MaterialTheme.typography.bodyMedium.copy(textDirection = TextDirection.Content),
                    color = cs.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun Composer(
    streaming: Boolean,
    busy: Boolean,
    input: String,
    showThinking: Boolean,
    thinkingOn: Boolean,
    onThinking: () -> Unit,
    onInput: (String) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
        if (showThinking) {
            FilterChip(
                selected = thinkingOn,
                onClick = onThinking,
                label = { Text(stringResource(R.string.thinking_mode)) },
                leadingIcon = { Icon(Icons.Filled.Psychology, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.padding(bottom = 6.dp),
            )
        }
        Surface(shape = RoundedCornerShape(28.dp), color = cs.surfaceContainerHigh) {
            Row(Modifier.padding(start = 4.dp, end = 6.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.Bottom) {
                TextField(
                    value = input,
                    onValueChange = onInput,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text(stringResource(R.string.hint)) },
                    maxLines = 6,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Content),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        disabledContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        disabledIndicatorColor = Color.Transparent,
                    ),
                )
                FilledIconButton(
                    onClick = { if (streaming) onStop() else onSend() },
                    enabled = streaming || (input.isNotBlank() && !busy),
                    modifier = Modifier.padding(bottom = 4.dp),
                ) {
                    if (streaming) Icon(Icons.Filled.Stop, contentDescription = stringResource(R.string.stop))
                    else Icon(Icons.AutoMirrored.Filled.Send, contentDescription = stringResource(R.string.send))
                }
            }
        }
    }
}
