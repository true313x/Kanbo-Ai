package ai.kanbo.app.ui

import ai.kanbo.app.R
import ai.kanbo.app.engine.ChatMsg
import ai.kanbo.app.models.Catalog
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import java.io.File

@Composable
fun KanboRoot(vm: ChatViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(bottomBar = {
        NavigationBar {
            listOf("💬" to R.string.chat, "🧠" to R.string.models, "⚙️" to R.string.settings).forEachIndexed { i, item ->
                NavigationBarItem(tab == i, { tab = i }, { Text(item.first) }, label = { Text(stringResource(item.second)) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) { 0 -> ChatScreen(vm); 1 -> ModelsScreen(vm); else -> SettingsScreen(vm) }
        }
    }
}

@Composable
fun ChatScreen(vm: ChatViewModel) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val name by vm.loaded.collectAsStateWithLifecycle()
    val n = name
    val st = vm.status

    LaunchedEffect(vm.messages.size, vm.messages.lastOrNull()?.text?.length) {
        if (vm.messages.isNotEmpty()) listState.scrollToItem(vm.messages.lastIndex)
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                st ?: if (n == null) stringResource(R.string.no_model)
                else n + if (vm.tps > 0) " · " + stringResource(R.string.speed, vm.tps) else "",
                Modifier.weight(1f), style = MaterialTheme.typography.labelMedium,
            )
            TextButton({ vm.newChat() }) { Text(stringResource(R.string.new_chat)) }
        }
        LazyColumn(
            Modifier.weight(1f), state = listState,
            contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
        ) { items(vm.messages) { Bubble(it) } }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, Modifier.weight(1f),
                placeholder = { Text(stringResource(R.string.hint)) }, maxLines = 5,
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { if (vm.streaming) vm.stop() else { vm.send(input); input = "" } }) {
                Text(stringResource(if (vm.streaming) R.string.stop else R.string.send))
            }
        }
    }
}

@Composable
private fun Bubble(m: ChatMsg) {
    val user = m.role == "user"
    Box(Modifier.fillMaxWidth(), contentAlignment = if (user) Alignment.CenterEnd else Alignment.CenterStart) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (user) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        ) { Text(m.text.ifEmpty { "…" }, Modifier.padding(12.dp)) }
    }
}

@Composable
private fun ModelCard(title: String, sub: String, badge: String?, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                if (badge != null) Text(badge, style = MaterialTheme.typography.labelSmall)
            }
            Text(sub, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun RunRow(vm: ChatViewModel, f: File, name: String, active: String?) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Button({ vm.load(f, name) }, enabled = active != name) {
            Text(stringResource(if (active == name) R.string.loaded else R.string.load))
        }
        Spacer(Modifier.width(8.dp))
        TextButton({ vm.delete(f) }, enabled = active != name) { Text(stringResource(R.string.delete)) }
    }
}

@Composable
fun ModelsScreen(vm: ChatViewModel) {
    val p = vm.profile
    val name by vm.loaded.collectAsStateWithLifecycle()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importModel(uri) }
    val best = Catalog.lastOrNull { p.totalRamMb >= it.minRamMb }
    val locals = vm.files.filter { f -> Catalog.none { it.file == f.name } }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text(stringResource(R.string.device, p.totalRamMb, p.perfCores, p.tier.name), style = MaterialTheme.typography.labelLarge) }
        item {
            OutlinedButton({ picker.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth(), enabled = vm.importing == null) {
                Text(stringResource(R.string.import_model))
            }
            val ip = vm.importing
            if (ip != null) LinearProgressIndicator(progress = { ip }, modifier = Modifier.fillMaxWidth())
        }
        items(Catalog) { m ->
            val prog = vm.progress[m.id]
            val f = vm.files.firstOrNull { it.name == m.file }
            ModelCard(m.name, "${m.sizeMb} MB · ≥ ${m.minRamMb / 1000} GB RAM", if (m == best) "⭐ " + stringResource(R.string.recommended) else null) {
                when {
                    prog != null -> LinearProgressIndicator(progress = { prog }, modifier = Modifier.fillMaxWidth())
                    f != null -> RunRow(vm, f, m.name, name)
                    else -> OutlinedButton({ vm.download(m) }, enabled = p.totalRamMb >= m.minRamMb) { Text(stringResource(R.string.download)) }
                }
            }
        }
        items(locals) { f ->
            ModelCard(f.name, "${f.length() / 1048576} MB", stringResource(R.string.local_model)) { RunRow(vm, f, f.name, name) }
        }
    }
}

@Composable
private fun <T> Choices(label: Int, options: List<Pair<String, T>>, current: T, onPick: (T) -> Unit) {
    Text(stringResource(label), style = MaterialTheme.typography.labelLarge)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { o ->
            if (o.second == current) Button({ onPick(o.second) }) { Text(o.first) }
            else OutlinedButton({ onPick(o.second) }) { Text(o.first) }
        }
    }
}

@Composable
fun SettingsScreen(vm: ChatViewModel) {
    val s = vm.prefs
    var showLog by remember { mutableStateOf(false) }
    val auto = stringResource(R.string.auto)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(stringResource(R.string.generation), style = MaterialTheme.typography.titleMedium)
        Text(stringResource(R.string.temperature) + ": " + "%.2f".format(s.temp))
        Slider(s.temp, { s.temp = it }, valueRange = 0f..1.5f, onValueChangeFinished = { s.save() })
        Text(stringResource(R.string.top_p) + ": " + "%.2f".format(s.topP))
        Slider(s.topP, { s.topP = it }, valueRange = 0.1f..1f, onValueChangeFinished = { s.save() })
        Text(stringResource(R.string.top_k) + ": " + s.topK)
        Slider(s.topK.toFloat(), { s.topK = it.toInt() }, valueRange = 1f..100f, onValueChangeFinished = { s.save() })
        Choices(R.string.max_tokens, listOf("256" to 256, "512" to 512, "1024" to 1024, "2048" to 2048), s.maxTokens) { s.maxTokens = it; s.save() }
        OutlinedTextField(
            s.system, { s.system = it; s.save() }, Modifier.fillMaxWidth(),
            label = { Text(stringResource(R.string.system_prompt)) }, minLines = 2, maxLines = 5,
        )

        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.engine), style = MaterialTheme.typography.titleMedium)
        Text(stringResource(R.string.apply_note), style = MaterialTheme.typography.bodySmall)
        Choices(R.string.context, listOf(auto to 0, "512" to 512, "1024" to 1024, "2048" to 2048, "4096" to 4096, "8192" to 8192), s.ctxSize) { s.ctxSize = it; s.save() }
        Choices(R.string.threads, listOf(auto to 0, "2" to 2, "3" to 3, "4" to 4, "6" to 6, "8" to 8), s.threads) { s.threads = it; s.save() }
        Choices(R.string.kv_cache, listOf(auto to -1, "F16" to 0, "Q8" to 1, "Q4" to 2), s.kv) { s.kv = it; s.save() }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.safe_cpu), Modifier.weight(1f))
            Switch(s.safeCpu, { s.safeCpu = it; s.save(); vm.applySafe() })
        }
        OutlinedButton({ showLog = true }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.show_log)) }
    }

    if (showLog) AlertDialog(
        onDismissRequest = { showLog = false },
        confirmButton = { TextButton({ showLog = false }) { Text(stringResource(R.string.close)) } },
        text = { Text(vm.log().ifEmpty { "—" }, Modifier.verticalScroll(rememberScrollState()), style = MaterialTheme.typography.bodySmall) },
    )
}
