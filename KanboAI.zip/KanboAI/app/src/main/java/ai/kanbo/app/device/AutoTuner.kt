package ai.kanbo.app.device

import ai.kanbo.app.engine.EngineConfig
import ai.kanbo.app.engine.KvType
import ai.kanbo.app.engine.ModelInfo
import android.content.Context
import android.os.Build
import android.os.PowerManager

object AutoTuner {
    private const val MB = 1048576.0

    /** Picks context size, KV-cache precision, threads and batch so the model fits the RAM budget. Null = too large. */
    fun tune(p: DeviceProfile, modelBytes: Long, m: ModelInfo): EngineConfig? {
        val modelMb = modelBytes / MB
        val budget = minOf(p.availRamMb * 0.8, p.totalRamMb * 0.6)
        val overhead = 128 + modelMb * 0.06
        val embdKv = if (m.heads > 0) m.embd.toDouble() / m.heads * m.headsKv else m.embd.toDouble()
        val cap = when (p.tier) { Tier.LOW -> 2048; Tier.MID -> 4096; Tier.HIGH -> 8192 }
        val ctxs = listOf(8192, 6144, 4096, 3072, 2048, 1536, 1024, 512).filter { it <= cap && it <= m.ctxTrain }
        val kvs = if (p.tier == Tier.LOW) listOf(KvType.Q8_0, KvType.Q4_0) else KvType.values().toList()
        val threads = p.perfCores.coerceIn(1, when (p.tier) { Tier.LOW -> 4; Tier.MID -> 5; Tier.HIGH -> 6 })
        val batch = when (p.tier) { Tier.LOW -> 128; Tier.MID -> 256; Tier.HIGH -> 512 }

        for (ctx in ctxs) for (kv in kvs) {
            val kvMb = ctx * 2.0 * m.layers * embdKv * kv.bytes / MB
            if (modelMb + overhead + kvMb <= budget)
                return EngineConfig(ctx, minOf(batch, ctx), threads, true, kv, kv != KvType.F16 || p.tier != Tier.LOW)
        }
        return null
    }
}

/** Lowers thread count when the phone heats up, restores it when it cools down. */
class ThermalGuard(private val ctx: Context, private val base: Int, private val onThreads: (Int) -> Unit) {
    private var listener: Any? = null

    fun start() {
        if (Build.VERSION.SDK_INT < 29) return
        val l = PowerManager.OnThermalStatusChangedListener { s ->
            onThreads(when {
                s >= PowerManager.THERMAL_STATUS_SEVERE -> maxOf(1, base / 2)
                s >= PowerManager.THERMAL_STATUS_MODERATE -> maxOf(1, base * 3 / 4)
                else -> base
            })
        }
        listener = l
        ctx.getSystemService(PowerManager::class.java).addThermalStatusListener(l)
    }

    fun stop() {
        if (Build.VERSION.SDK_INT < 29) return
        (listener as? PowerManager.OnThermalStatusChangedListener)?.let {
            ctx.getSystemService(PowerManager::class.java).removeThermalStatusListener(it)
        }
    }
}
