package ai.kanbo.app.device

import android.app.ActivityManager
import android.content.Context
import java.io.File

enum class Tier { LOW, MID, HIGH }

data class DeviceProfile(
    val totalRamMb: Long, val availRamMb: Long, val cores: Int, val perfCores: Int,
    val dotprod: Boolean, val i8mm: Boolean, val tier: Tier,
)

object DeviceProfiler {
    fun read(ctx: Context): DeviceProfile {
        val mi = ActivityManager.MemoryInfo()
        ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        val totalMb = mi.totalMem / 1048576
        val cores = Runtime.getRuntime().availableProcessors()

        // count only the fast cores (big.LITTLE): slow cores drag down multi-threaded inference
        val freqs = (0 until cores).mapNotNull {
            runCatching { File("/sys/devices/system/cpu/cpu$it/cpufreq/cpuinfo_max_freq").readText().trim().toLong() }.getOrNull()
        }
        val perf = if (freqs.size == cores) { val mx = freqs.max(); freqs.count { it >= mx * 0.8 } } else maxOf(2, cores / 2)

        val feat = runCatching { File("/proc/cpuinfo").useLines { l -> l.firstOrNull { it.startsWith("Features") } } }.getOrNull().orEmpty()
        val tier = when {
            totalMb < 4800 || cores <= 4 -> Tier.LOW
            totalMb < 9500 -> Tier.MID
            else -> Tier.HIGH
        }
        return DeviceProfile(totalMb, mi.availMem / 1048576, cores, perf, "asimddp" in feat, "i8mm" in feat, tier)
    }
}
