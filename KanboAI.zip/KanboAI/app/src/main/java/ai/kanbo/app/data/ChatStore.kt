package ai.kanbo.app.data

import ai.kanbo.app.engine.ChatMsg
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ChatMeta(val id: String, val title: String, val pinned: Boolean, val updated: Long)

/** One JSON file per conversation in filesDir/chats. All methods are blocking: call them from Dispatchers.IO. */
class ChatStore(ctx: Context) {
    private val dir = File(ctx.filesDir, "chats").also { it.mkdirs() }
    private fun file(id: String) = File(dir, "$id.json")

    fun list(): List<ChatMeta> =
        dir.listFiles { f -> f.name.endsWith(".json") }.orEmpty().mapNotNull { f ->
            try {
                val o = JSONObject(f.readText())
                ChatMeta(o.getString("id"), o.optString("title", ""), o.optBoolean("pinned", false), o.optLong("updated", f.lastModified()))
            } catch (e: Exception) {
                null
            }
        }

    fun load(id: String): List<ChatMsg> = try {
        val a = JSONObject(file(id).readText()).getJSONArray("messages")
        List(a.length()) { i ->
            val m = a.getJSONObject(i)
            ChatMsg(m.getString("r"), m.getString("t"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(meta: ChatMeta, msgs: List<ChatMsg>) {
        val arr = JSONArray()
        msgs.forEach { arr.put(JSONObject().put("r", it.role).put("t", it.text)) }
        val o = JSONObject()
            .put("id", meta.id).put("title", meta.title).put("pinned", meta.pinned)
            .put("updated", meta.updated).put("messages", arr)
        val tmp = File(dir, "${meta.id}.tmp")
        tmp.writeText(o.toString())
        val dst = file(meta.id)
        if (!tmp.renameTo(dst)) {
            dst.delete()
            tmp.renameTo(dst)
        }
    }

    fun delete(id: String) {
        file(id).delete()
    }
}
