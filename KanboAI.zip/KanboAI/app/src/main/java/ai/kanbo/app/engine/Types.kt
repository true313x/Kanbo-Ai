package ai.kanbo.app.engine

enum class KvType(val code: Int, val bytes: Double) { F16(0, 2.0), Q8_0(1, 1.0625), Q4_0(2, 0.5625) }

data class EngineConfig(
    val nCtx: Int, val nBatch: Int, val nThreads: Int,
    val useMmap: Boolean, val kv: KvType, val flashAttn: Boolean,
)

data class SamplerParams(val maxTokens: Int = 1024, val temperature: Float = 0.7f, val topP: Float = 0.9f, val topK: Int = 40)
data class ChatMsg(val role: String, val text: String)
data class ModelInfo(val layers: Int, val embd: Int, val heads: Int, val headsKv: Int, val ctxTrain: Int)
class EngineException(val code: Int) : Exception("engine error $code")
