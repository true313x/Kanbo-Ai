package ai.kanbo.app.engine

enum class KvType(val code: Int, val bytes: Double) { F16(0, 2.0), Q8_0(1, 1.0625), Q4_0(2, 0.5625) }

data class EngineConfig(
    val nCtx: Int, val nBatch: Int, val nThreads: Int,
    val useMmap: Boolean, val kv: KvType, val flashAttn: Boolean,
)

data class SamplerParams(val maxTokens: Int = 1024, val temperature: Float = 0.7f, val topP: Float = 0.9f, val topK: Int = 40)
data class ChatMsg(val role: String, val text: String)
data class ModelInfo(val layers: Int, val embd: Int, val heads: Int, val headsKv: Int, val ctxTrain: Int, val keyLen: Int = 0)

/** [code] values 0 > c >= -4 come from the native layer; the rest are raised by the IPC client. */
class EngineException(val code: Int, msg: String? = null) : Exception(msg ?: "engine error $code") {
    companion object {
        const val CTX_FULL = -2
        const val TEMPLATE = -3
        const val DECODE = -4
        const val REMOTE = -5
        const val CRASHED = -9      // engine process died
        const val TIMEOUT = -10     // engine did not answer in time (it is restarted)
        const val NO_ENGINE = -11   // engine process could not be started / bound
        const val CANCELLED = -12   // engine restarted on purpose (cancel, safe-mode switch)
        const val BAD_MODEL = -13
    }
}
