package ai.kanbo.app.engine

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.Process
import java.io.File
import java.util.concurrent.Executors

object Proto {
    const val INSPECT = 1; const val LOAD = 2; const val GEN = 3; const val CANCEL = 4
    const val UNLOAD = 5; const val THREADS = 6; const val EXIT = 7
    const val R_OK = 10; const val R_ERR = 11; const val R_TOKEN = 12; const val R_DONE = 13
}

/** Runs llama.cpp in its own process: a native crash or OOM kill never takes the UI down. */
class EngineService : Service() {
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var handle = 0L
    private var inited = false
    private val messenger = Messenger(Handler(Looper.getMainLooper()) { m -> dispatch(m); true })

    override fun onBind(intent: Intent?): IBinder = messenger.binder

    private fun reply(to: Messenger?, what: Int, id: Int, fill: Bundle.() -> Unit = {}) {
        try { to?.send(Message.obtain(null, what, id, 0).apply { data = Bundle().apply(fill) }) } catch (_: Exception) {}
    }

    private fun dispatch(m: Message) {
        val to = m.replyTo
        val id = m.arg1
        val d = m.data
        when (m.what) {
            Proto.CANCEL -> if (handle != 0L) NativeBridge.nativeCancel(handle)
            Proto.EXIT -> Process.killProcess(Process.myPid())
            Proto.THREADS -> exec.execute { if (handle != 0L) NativeBridge.nativeSetThreads(handle, d.getInt("n")) }
            else -> exec.execute {
                try { work(m.what, id, d, to) }
                catch (t: Throwable) { reply(to, Proto.R_ERR, id) { putString("msg", t.toString()) } }
            }
        }
    }

    private fun init(d: Bundle) {
        if (inited) return
        NativeBridge.nativeInit(applicationInfo.nativeLibraryDir, File(filesDir, "native.log").path, d.getBoolean("safe"))
        inited = true
    }

    private fun free() { if (handle != 0L) { NativeBridge.nativeFree(handle); handle = 0L } }

    private fun work(what: Int, id: Int, d: Bundle, to: Messenger?) {
        when (what) {
            Proto.INSPECT -> {
                init(d)
                val r = NativeBridge.nativeInspect(d.getString("path")!!) ?: error("not a valid GGUF model")
                reply(to, Proto.R_OK, id) { putLongArray("v", r) }
            }
            Proto.LOAD -> {
                init(d)
                free()
                val h = NativeBridge.nativeLoad(
                    d.getString("path")!!, d.getInt("ctx"), d.getInt("batch"), d.getInt("threads"),
                    d.getBoolean("mmap"), d.getInt("kv"), d.getBoolean("flash"),
                )
                if (h == 0L) error("load failed (see log)")
                handle = h
                reply(to, Proto.R_OK, id)
            }
            Proto.UNLOAD -> { free(); reply(to, Proto.R_OK, id) }
            Proto.GEN -> {
                val h = handle
                if (h == 0L) error("no model loaded")
                val texts = d.getStringArray("texts")!!
                val rc = NativeBridge.nativeGenerate(
                    h, d.getStringArray("roles")!!, Array(texts.size) { texts[it].toByteArray(Charsets.UTF_8) },
                    d.getInt("max"), d.getFloat("temp"), d.getFloat("topP"), d.getInt("topK"),
                    TokenListener { b -> reply(to, Proto.R_TOKEN, id) { putString("t", String(b, Charsets.UTF_8)) }; true },
                )
                val st = NativeBridge.nativeStats(h)
                reply(to, Proto.R_DONE, id) { putInt("rc", rc); putDoubleArray("st", st) }
            }
        }
    }
}
