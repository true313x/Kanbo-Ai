package ai.kanbo.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** User settings. 0 / -1 mean "auto" (chosen by the device tuner). */
class AppPrefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("kanbo", Context.MODE_PRIVATE)
    var ctxSize by mutableIntStateOf(sp.getInt("ctx", 0))
    var threads by mutableIntStateOf(sp.getInt("threads", 0))
    var kv by mutableIntStateOf(sp.getInt("kv", -1))
    var temp by mutableFloatStateOf(sp.getFloat("temp", 0.7f))
    var topP by mutableFloatStateOf(sp.getFloat("topP", 0.9f))
    var topK by mutableIntStateOf(sp.getInt("topK", 40))
    var maxTokens by mutableIntStateOf(sp.getInt("max", 1024))
    var system by mutableStateOf(sp.getString("system", "") ?: "")
    var safeCpu by mutableStateOf(sp.getBoolean("safe", false))

    fun save() {
        sp.edit().putInt("ctx", ctxSize).putInt("threads", threads).putInt("kv", kv).putFloat("temp", temp)
            .putFloat("topP", topP).putInt("topK", topK).putInt("max", maxTokens).putString("system", system)
            .putBoolean("safe", safeCpu).apply()
    }
}
