package ai.kanbo.app.ui

import ai.kanbo.app.KanboApp
import ai.kanbo.app.R
import ai.kanbo.app.device.AutoTuner
import ai.kanbo.app.device.DeviceProfiler
import ai.kanbo.app.device.ThermalGuard
import ai.kanbo.app.engine.ChatMsg
import ai.kanbo.app.engine.EngineException
import ai.kanbo.app.engine.SamplerParams
import ai.kanbo.app.models.CatalogModel
import ai.kanbo.app.models.ModelDownloader
import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val engine = (app as KanboApp).engine
    val loaded = engine.loaded
    val messages = mutableStateListOf<ChatMsg>()
    val progress = mutableStateMapOf<String, Float>()
    var streaming by mutableStateOf(false); private set
    var status by mutableStateOf<Int?>(null); private set
    var tps by mutableStateOf(0.0); private set
    var profile by mutableStateOf(DeviceProfiler.read(app)); private set

    private val system = ChatMsg("system", "You are Kanbo AI, a concise helpful assistant. Answer in the user's language.")
    private var job: Job? = null
    private var guard: ThermalGuard? = null
    private var lastModel: CatalogModel? = null

    fun file(m: CatalogModel) = File(getApplication<Application>().filesDir, "models/${m.file}")
    fun isDownloaded(m: CatalogModel) = file(m).exists()

    fun download(m: CatalogModel) {
        if (progress.containsKey(m.id)) return
        viewModelScope.launch {
            progress[m.id] = 0f
            try { ModelDownloader.download(m, file(m)).collect { progress[m.id] = it } } catch (e: Exception) { status = R.string.error }
            progress.remove(m.id)
        }
    }

    fun load(m: CatalogModel) { viewModelScope.launch { loadModel(m) } }

    private suspend fun loadModel(m: CatalogModel): Boolean {
        status = R.string.loading
        val f = file(m)
        val p = DeviceProfiler.read(getApplication()).also { profile = it }
        val info = engine.inspect(f.path)
        val cfg = info?.let { AutoTuner.tune(p, f.length(), it) }
        if (cfg == null) { status = R.string.too_large; return false }
        val ok = engine.load(f.path, m.name, cfg)
        if (ok) {
            lastModel = m
            guard?.stop()
            guard = ThermalGuard(getApplication(), cfg.nThreads) { engine.requestThreads(it) }.also { it.start() }
            status = null
        } else status = R.string.error
        return ok
    }

    fun send(text: String) {
        if (text.isBlank() || streaming) return
        messages += ChatMsg("user", text)
        messages += ChatMsg("assistant", "")
        streaming = true
        job = viewModelScope.launch {
            try {
                if (loaded.value == null) {
                    val m = lastModel
                    if (m == null) { status = R.string.no_model; return@launch }
                    if (!loadModel(m)) return@launch
                }
                var rest = messages.dropLast(1).toList()
                while (true) {
                    try {
                        val sb = StringBuilder()
                        engine.generate(listOf(system) + rest, SamplerParams()).collect {
                            sb.append(it)
                            messages[messages.lastIndex] = ChatMsg("assistant", sb.toString())
                        }
                        break
                    } catch (e: EngineException) {
                        // context full: drop the oldest exchange from the model input and retry
                        if (e.code == -2 && rest.size > 1) rest = rest.drop(2) else { status = R.string.error; break }
                    }
                }
                tps = engine.stats().second
            } finally {
                streaming = false
            }
        }
    }

    fun stop() { job?.cancel() }
    override fun onCleared() { guard?.stop() }
}
