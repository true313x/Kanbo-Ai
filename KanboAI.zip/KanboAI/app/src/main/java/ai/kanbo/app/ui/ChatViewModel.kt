package ai.kanbo.app.ui

import ai.kanbo.app.KanboApp
import ai.kanbo.app.R
import ai.kanbo.app.data.ChatMeta
import ai.kanbo.app.data.ChatStore
import ai.kanbo.app.data.MemoryStore
import ai.kanbo.app.device.AutoTuner
import ai.kanbo.app.device.DeviceProfiler
import ai.kanbo.app.device.ThermalGuard
import ai.kanbo.app.engine.ChatMsg
import ai.kanbo.app.engine.EngineException
import ai.kanbo.app.engine.EngineLog
import ai.kanbo.app.engine.KvType
import ai.kanbo.app.engine.SamplerParams
import ai.kanbo.app.models.Catalog
import ai.kanbo.app.models.CatalogModel
import ai.kanbo.app.models.ModelDownloader
import ai.kanbo.app.models.parseModelLink
import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.UUID

private const val DEFAULT_SYSTEM = "You are Kanbo AI, a helpful and accurate assistant. Always answer in the same language the user writes in. Be clear and concise."

/** Rough characters per token used to keep the prompt inside the context window (the engine double-checks and reports CTX_FULL). */
private const val CHARS_PER_TOKEN = 3.0

class ChatViewModel(private val app: Application) : AndroidViewModel(app) {
    private val kanbo = app as KanboApp
    private val engine = kanbo.engine
    val prefs = kanbo.prefs
    val loaded = engine.loaded

    val messages = mutableStateListOf<ChatMsg>()
    val chats = mutableStateListOf<ChatMeta>()
    val memory = MemoryStore(app)
    private val store = ChatStore(app)
    private val saveMutex = Mutex()

    var currentId by mutableStateOf<String?>(null); private set

    val progress = mutableStateMapOf<String, Float>()
    val files = mutableStateListOf<File>()
    var importing by mutableStateOf<Float?>(null); private set
    var streaming by mutableStateOf(false); private set
    var status by mutableStateOf<String?>(null); private set
    /** Name of the model being loaded right now (null when idle). */
    var loadingName by mutableStateOf<String?>(null); private set
    var tps by mutableStateOf(0.0); private set
    var profile by mutableStateOf(DeviceProfiler.read(app)); private set
    /** Set when something was just saved to long-term memory; the UI shows a snackbar and clears it. */
    var memoryNotice by mutableStateOf<String?>(null); private set

    private val dir = File(app.filesDir, "models").also { it.mkdirs() }
    private var job: Job? = null
    private var loadJob: Job? = null
    private var guard: ThermalGuard? = null
    private var last: Pair<File, String>? = null
    private var ctxTokens = 0
    private val downloads = HashMap<String, Job>()

    init {
        engine.setSafe(prefs.safeCpu)
        File(app.filesDir, "native.log").takeIf { it.length() > 200_000 }?.writeText("")
        refresh()
        restoreLast()?.let { last = it }
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { store.list() }
            chats.clear()
            chats.addAll(sortChats(list))
        }
    }

    private fun str(id: Int) = app.getString(id)

    // ------------------------------------------------------------------ models

    fun displayName(f: File): String = Catalog.firstOrNull { it.file == f.name }?.name ?: f.name.removeSuffix(".gguf")

    /** Model shown in the top bar: the running one, or the one that will be loaded on the next message. */
    val activeName: String? get() = loaded.value ?: last?.second

    private fun restoreLast(): Pair<File, String>? {
        val n = prefs.lastModel
        if (n.isBlank()) return null
        val f = File(dir, n)
        return if (f.exists()) f to displayName(f) else null
    }

    fun refresh() {
        val list = dir.listFiles { f -> f.name.endsWith(".gguf") }.orEmpty().sortedBy { it.name }
        files.clear()
        files.addAll(list)
    }

    fun file(m: CatalogModel) = File(dir, m.file)
    fun applySafe() = engine.setSafe(prefs.safeCpu)
    fun log(): String = File(app.filesDir, "native.log").takeIf { it.exists() }?.readText()?.takeLast(12_000).orEmpty()
    fun clearLog() { File(app.filesDir, "native.log").takeIf { it.exists() }?.writeText("") }
    fun dismissStatus() { status = null }
    fun clearMemoryNotice() { memoryNotice = null }

    fun delete(f: File) {
        f.delete()
        if (last?.first?.name == f.name) { last = null; prefs.lastModel = ""; prefs.save() }
        refresh()
    }

    fun download(m: CatalogModel) {
        if (downloads.containsKey(m.id)) return
        progress[m.id] = 0f
        downloads[m.id] = viewModelScope.launch {
            try {
                ModelDownloader.download(m, file(m)).collect { progress[m.id] = it }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status = str(R.string.error) + ": " + e.message
            } finally {
                progress.remove(m.id)
                downloads.remove(m.id)
                refresh()
            }
        }
    }

    fun cancelDownload(id: String) { downloads[id]?.cancel() }

    /** Starts a download from a pasted link. Returns false when the text is not a valid .gguf link. */
    fun downloadFromLink(text: String): Boolean {
        val m = parseModelLink(text) ?: return false
        download(m)
        return true
    }

    fun importModel(uri: Uri) {
        viewModelScope.launch {
            importing = 0f
            val tmp = File(dir, "import.part")
            try {
                var name = "model.gguf"
                var size = 0L
                app.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        c.getColumnIndex(OpenableColumns.DISPLAY_NAME).let { if (it >= 0) name = c.getString(it) }
                        c.getColumnIndex(OpenableColumns.SIZE).let { if (it >= 0) size = c.getLong(it) }
                    }
                }
                if (!name.endsWith(".gguf", true)) name += ".gguf"
                val target = File(dir, name.replace(Regex("[/\\\\]"), "_").removePrefix("."))
                if (displayName(target) == loaded.value) throw IOException("model is running")
                withContext(Dispatchers.IO) {
                    app.contentResolver.openInputStream(uri)!!.use { inp ->
                        tmp.outputStream().use { out ->
                            val buf = ByteArray(1 shl 20)
                            var done = 0L
                            var lastP = -1f
                            while (true) {
                                val n = inp.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                done += n
                                if (size > 0 && done.toFloat() / size - lastP > 0.01f) { lastP = done.toFloat() / size; importing = lastP }
                            }
                        }
                    }
                    val magic = tmp.inputStream().use { s -> ByteArray(4).also { s.read(it) } }
                    if (String(magic, Charsets.US_ASCII) != "GGUF") throw IOException("not gguf")
                    target.delete()
                    if (!tmp.renameTo(target)) throw IOException("rename failed")
                }
                refresh()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status = str(R.string.bad_file)
            } finally {
                tmp.delete()
                importing = null
            }
        }
    }

    fun load(f: File, name: String) {
        if (loadJob?.isActive == true || streaming) return
        loadJob = viewModelScope.launch { loadModel(f, name) }
    }

    /** Switch to another downloaded model (top bar menu). */
    fun selectModel(f: File) {
        val name = displayName(f)
        if (name == loaded.value) return
        load(f, name)
    }

    /** Aborts a running load: the engine process is killed, so even a stuck native load stops immediately. */
    fun cancelLoad() { loadJob?.cancel() }

    private fun errorText(e: EngineException): String? = when (e.code) {
        EngineException.CRASHED -> str(R.string.crashed_again)
        EngineException.TIMEOUT -> str(R.string.engine_timeout)
        EngineException.NO_ENGINE -> str(R.string.engine_unavailable)
        EngineException.BAD_MODEL -> str(R.string.bad_file)
        EngineException.CTX_FULL -> str(R.string.ctx_too_long)
        EngineException.CANCELLED -> null
        else -> str(R.string.error) + ": " + (e.message ?: e.code)
    }

    private suspend fun loadModel(f: File, name: String): Boolean {
        loadingName = name
        status = str(R.string.loading)
        var retriedSafe = false
        try {
            while (true) {
                try {
                    val p = DeviceProfiler.read(app).also { profile = it }
                    engine.setSafe(prefs.safeCpu)
                    EngineLog.w("load: ${f.name} (${f.length() / 1048576} MB) safe=${prefs.safeCpu}")
                    val info = engine.inspect(f.path) ?: throw EngineException(EngineException.BAD_MODEL)
                    val auto = AutoTuner.tune(p, f.length(), info)
                    if (auto == null) { status = str(R.string.too_large); return false }
                    val s = prefs
                    val c1 = auto.copy(
                        nCtx = if (s.ctxSize > 0) minOf(s.ctxSize, info.ctxTrain.takeIf { it > 0 } ?: s.ctxSize) else auto.nCtx,
                        nThreads = if (s.threads > 0) s.threads else auto.nThreads,
                        kv = if (s.kv in 0..2) KvType.values()[s.kv] else auto.kv,
                    )
                    val cfg = c1.copy(nBatch = minOf(c1.nBatch, c1.nCtx), flashAttn = c1.flashAttn || c1.kv != KvType.F16)
                    EngineLog.w("load: config $cfg")
                    status = str(R.string.loading_model)
                    engine.load(f.path, name, f.length() / 1048576, cfg)
                    last = f to name
                    ctxTokens = cfg.nCtx
                    prefs.lastModel = f.name
                    prefs.save()
                    guard?.stop()
                    guard = ThermalGuard(app, cfg.nThreads) { engine.requestThreads(it) }.also { it.start() }
                    status = null
                    return true
                } catch (e: EngineException) {
                    if (e.code == EngineException.CRASHED && !retriedSafe && !prefs.safeCpu) {
                        // native crash (usually an unsupported CPU kernel): retry once, automatically, with baseline kernels
                        retriedSafe = true
                        prefs.safeCpu = true
                        prefs.save()
                        status = str(R.string.retry_safe)
                        continue
                    }
                    status = errorText(e)
                    return false
                }
            }
        } catch (e: CancellationException) {
            EngineLog.w("load cancelled by user")
            engine.restartEngine()
            status = null
            throw e
        } catch (e: Exception) {
            EngineLog.w("load failed: $e")
            status = str(R.string.error) + ": " + e.message
            return false
        } finally {
            loadingName = null
        }
    }

    // ------------------------------------------------------------------ chats

    private fun sortChats(l: List<ChatMeta>): List<ChatMeta> =
        l.sortedWith(compareByDescending<ChatMeta> { it.pinned }.thenByDescending { it.updated })

    private fun upsert(m: ChatMeta) {
        val i = chats.indexOfFirst { it.id == m.id }
        if (i >= 0) chats[i] = m else chats.add(m)
        val sorted = sortChats(chats.toList())
        chats.clear()
        chats.addAll(sorted)
    }

    fun newChat() {
        if (streaming) return
        messages.clear()
        currentId = null
        tps = 0.0
        status = null
    }

    fun openChat(id: String) {
        if (streaming || id == currentId) return
        viewModelScope.launch {
            val msgs = withContext(Dispatchers.IO) { store.load(id) }
            messages.clear()
            messages.addAll(msgs)
            currentId = id
            tps = 0.0
            status = null
        }
    }

    fun deleteChat(id: String) {
        if (streaming && id == currentId) return
        chats.removeAll { it.id == id }
        if (id == currentId) { messages.clear(); currentId = null }
        viewModelScope.launch(Dispatchers.IO) { saveMutex.withLock { store.delete(id) } }
    }

    private fun updateMeta(id: String, f: (ChatMeta) -> ChatMeta) {
        val old = chats.firstOrNull { it.id == id } ?: return
        val m = f(old)
        upsert(m)
        val snap = if (id == currentId) messages.toList() else null
        viewModelScope.launch(Dispatchers.IO) { saveMutex.withLock { store.save(m, snap ?: store.load(id)) } }
    }

    fun togglePin(id: String) = updateMeta(id) { it.copy(pinned = !it.pinned) }

    fun renameChat(id: String, title: String) {
        val t = title.trim().take(60)
        if (t.isNotEmpty()) updateMeta(id) { it.copy(title = t) }
    }

    private fun titleFrom(msgs: List<ChatMsg>): String {
        val t = msgs.firstOrNull { it.role == "user" }?.text.orEmpty().replace(Regex("\\s+"), " ").trim().take(48)
        return t.ifEmpty { str(R.string.new_chat) }
    }

    /** Saves the current conversation (called after the user message and after every finished reply). */
    private fun persist() {
        val id = currentId ?: return
        if (messages.isEmpty()) return
        val old = chats.firstOrNull { it.id == id }
        val meta = ChatMeta(id, old?.title ?: titleFrom(messages), old?.pinned ?: false, System.currentTimeMillis())
        upsert(meta)
        val snap = messages.toList()
        viewModelScope.launch(Dispatchers.IO) { saveMutex.withLock { store.save(meta, snap) } }
    }

    // ------------------------------------------------------------------ prompt / memory / context

    private fun isReasoningName(n: String?): Boolean {
        if (n == null) return false
        return Catalog.firstOrNull { it.name == n }?.reasoning == true ||
            n.contains("r1", true) || n.contains("qwen3", true) || n.contains("think", true)
    }

    /** Qwen3 has a "/no_think" soft switch; other reasoning models cannot be told to skip thinking. */
    val supportsThinkingToggle: Boolean get() = activeName?.contains("qwen3", true) == true

    private fun effectiveMaxTokens(): Int {
        val base = prefs.maxTokens
        // reasoning models spend hundreds of tokens thinking before the answer: give them room
        return if (isReasoningName(activeName) && (prefs.thinking || !supportsThinkingToggle)) maxOf(base, 3072) else base
    }

    private fun digest(dropped: List<ChatMsg>): String {
        val lines = ArrayList<String>()
        var total = 0
        for (m in dropped.asReversed()) {
            val who = if (m.role == "user") "User" else "You"
            val line = "- $who: " + m.text.replace(Regex("\\s+"), " ").trim().take(110)
            if (total + line.length > 700) break
            total += line.length
            lines.add(line)
        }
        lines.reverse()
        return "Earlier in this conversation (older messages were trimmed to fit memory; use as background):\n" + lines.joinToString("\n")
    }

    /**
     * Builds what the model sees: system prompt + long-term memory + a short digest of trimmed old messages + as much
     * recent history as fits in the context window. [dropExtra] removes more old messages after a CTX_FULL error.
     */
    private fun buildContext(history: List<ChatMsg>, dropExtra: Int): List<ChatMsg> {
        val base = prefs.system.ifBlank { DEFAULT_SYSTEM }
        val mem = if (prefs.memoryEnabled) memory.promptBlock() else ""
        val ctx = if (ctxTokens > 0) ctxTokens else 2048
        val reply = minOf(effectiveMaxTokens(), ctx / 3)
        val budget = ((ctx - reply - 48) * CHARS_PER_TOKEN).toInt() - base.length - mem.length - 420

        // the reasoning of earlier answers is not sent back to the model
        val clean = history.map {
            if (it.role == "assistant") ChatMsg("assistant", splitThink(it.text).answer.trim().ifEmpty { "..." }) else it
        }

        var keep = clean.size
        var used = 0
        for (i in clean.indices.reversed()) {
            val c = clean[i].text.length + 16
            if (keep < clean.size && used + c > budget) break
            used += c
            keep = i
        }
        keep = maxOf(keep, minOf(dropExtra, clean.size - 1))
        while (keep < clean.size - 1 && clean[keep].role != "user") keep++

        val kept = clean.subList(keep, clean.size).toMutableList()
        val dropped = clean.subList(0, keep)
        var sys = base
        if (mem.isNotEmpty()) sys += "\n\n" + mem
        if (dropped.isNotEmpty()) sys += "\n\n" + digest(dropped)

        if (!prefs.thinking && supportsThinkingToggle) {
            val li = kept.indexOfLast { it.role == "user" }
            if (li >= 0) kept[li] = ChatMsg("user", kept[li].text + " /no_think")
        }
        return listOf(ChatMsg("system", sys)) + kept
    }

    // ------------------------------------------------------------------ sending

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || streaming || loadingName != null) return
        if (loaded.value == null) {
            if (last == null) last = restoreLast()
            if (last == null) { status = str(R.string.no_model); return }   // nothing to answer with: do not leave an orphan message
        }
        if (currentId == null) currentId = UUID.randomUUID().toString()
        messages += ChatMsg("user", t)
        if (prefs.memoryEnabled) {
            val saved = memory.capture(t)
            if (saved.isNotEmpty()) memoryNotice = saved.first()
        }
        messages += ChatMsg("assistant", "")
        persist()
        runGeneration()
    }

    /** Re-answers the last user message. */
    fun regenerate() {
        if (streaming || loadingName != null || messages.isEmpty()) return
        if (messages.last().role == "assistant") messages.removeAt(messages.lastIndex)
        if (messages.lastOrNull()?.role != "user") return
        messages += ChatMsg("assistant", "")
        runGeneration()
    }

    private fun runGeneration() {
        streaming = true
        status = null
        job = viewModelScope.launch {
            try {
                if (loaded.value == null) {
                    val l = last ?: restoreLast()
                    if (l == null) { status = str(R.string.no_model); return@launch }
                    if (!loadModel(l.first, l.second)) return@launch
                }
                val sp = SamplerParams(effectiveMaxTokens(), prefs.temp, prefs.topP, prefs.topK)
                val history = messages.dropLast(1)
                var drop = 0
                while (true) {
                    try {
                        val sb = StringBuilder()
                        engine.generate(buildContext(history, drop), sp).collect {
                            sb.append(it)
                            messages[messages.lastIndex] = ChatMsg("assistant", sb.toString())
                        }
                        break
                    } catch (e: EngineException) {
                        if (e.code == EngineException.CTX_FULL && history.size - drop > 1) drop += 2   // context full: drop the oldest exchange
                        else { status = errorText(e) ?: str(R.string.error); break }
                    }
                }
                tps = engine.stats().second
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status = str(R.string.error) + ": " + e.message
            } finally {
                streaming = false
                // never leave an empty bubble behind when nothing was produced
                if (messages.lastOrNull()?.let { it.role == "assistant" && it.text.isEmpty() } == true) messages.removeAt(messages.lastIndex)
                persist()
            }
        }
    }

    fun stop() { job?.cancel() }
    override fun onCleared() { guard?.stop() }
}
