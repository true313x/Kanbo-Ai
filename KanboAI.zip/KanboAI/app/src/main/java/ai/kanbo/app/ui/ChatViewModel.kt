package ai.kanbo.app.ui

import ai.kanbo.app.AppPrefs
import ai.kanbo.app.KanboApp
import ai.kanbo.app.R
import ai.kanbo.app.device.AutoTuner
import ai.kanbo.app.device.DeviceProfiler
import ai.kanbo.app.device.ThermalGuard
import ai.kanbo.app.engine.ChatMsg
import ai.kanbo.app.engine.EngineException
import ai.kanbo.app.engine.KvType
import ai.kanbo.app.engine.SamplerParams
import ai.kanbo.app.models.Catalog
import ai.kanbo.app.models.CatalogModel
import ai.kanbo.app.models.ModelDownloader
import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

private const val DEFAULT_SYSTEM = "You are Kanbo AI, a concise helpful assistant. Answer in the user's language."

class ChatViewModel(private val app: Application) : AndroidViewModel(app) {
    private val engine = (app as KanboApp).engine
    val prefs = AppPrefs(app)
    val loaded = engine.loaded
    val messages = mutableStateListOf<ChatMsg>()
    val progress = mutableStateMapOf<String, Float>()
    val files = mutableStateListOf<File>()
    var importing by mutableStateOf<Float?>(null); private set
    var streaming by mutableStateOf(false); private set
    var status by mutableStateOf<String?>(null); private set
    var tps by mutableStateOf(0.0); private set
    var profile by mutableStateOf(DeviceProfiler.read(app)); private set

    private val dir = File(app.filesDir, "models").also { it.mkdirs() }
    private var job: Job? = null
    private var guard: ThermalGuard? = null
    private var last: Pair<File, String>? = null

    init {
        engine.setSafe(prefs.safeCpu)
        File(app.filesDir, "native.log").takeIf { it.length() > 200_000 }?.writeText("")
        refresh()
    }

    private fun str(id: Int) = app.getString(id)

    fun refresh() {
        val list = dir.listFiles { f -> f.name.endsWith(".gguf") }.orEmpty().sortedBy { it.name }
        files.clear()
        files.addAll(list)
    }

    fun file(m: CatalogModel) = File(dir, m.file)
    fun applySafe() = engine.setSafe(prefs.safeCpu)
    fun log(): String = File(app.filesDir, "native.log").takeIf { it.exists() }?.readText()?.takeLast(6000).orEmpty()
    fun newChat() { if (!streaming) { messages.clear(); tps = 0.0; status = null } }
    fun delete(f: File) { f.delete(); refresh() }

    fun download(m: CatalogModel) {
        if (progress.containsKey(m.id)) return
        viewModelScope.launch {
            progress[m.id] = 0f
            try { ModelDownloader.download(m, file(m)).collect { progress[m.id] = it } } catch (e: Exception) { status = str(R.string.error) + ": " + e.message }
            progress.remove(m.id)
            refresh()
        }
    }

    fun importModel(uri: Uri) {
        viewModelScope.launch {
            importing = 0f
            val tmp = File(dir, "import.part")
            try {
                var name = "model.gguf"
                var size = 0L
                app.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        c.getColumnIndex(OpenableColumns.DISPLAY_NAME).let { if (it >= 0) name = c.getString(it) }
                        c.getColumnIndex(OpenableColumns.SIZE).let { if (it >= 0) size = c.getLong(it) }
                    }
                }
                if (!name.endsWith(".gguf", true)) name += ".gguf"
                withContext(Dispatchers.IO) {
                    app.contentResolver.openInputStream(uri)!!.use { inp ->
                        tmp.outputStream().use { out ->
                            val buf = ByteArray(1 shl 20)
                            var done = 0L
                            var lastP = -1f
                            while (true) {
                                val n = inp.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                done += n
                                if (size > 0 && done.toFloat() / size - lastP > 0.01f) { lastP = done.toFloat() / size; importing = lastP }
                            }
                        }
                    }
                    val magic = tmp.inputStream().use { s -> ByteArray(4).also { s.read(it) } }
                    if (String(magic, Charsets.US_ASCII) != "GGUF") throw IOException("not gguf")
                    tmp.renameTo(File(dir, name.replace('/', '_')))
                }
                refresh()
            } catch (e: Exception) {
                status = str(R.string.bad_file)
            } finally {
                tmp.delete()
                importing = null
            }
        }
    }

    fun load(f: File, name: String) { viewModelScope.launch { loadModel(f, name) } }

    private suspend fun loadModel(f: File, name: String): Boolean {
        status = str(R.string.loading)
        val p = DeviceProfiler.read(app).also { profile = it }
        try {
            engine.setSafe(prefs.safeCpu)
            val info = engine.inspect(f.path) ?: error("invalid model")
            val auto = AutoTuner.tune(p, f.length(), info)
            if (auto == null) { status = str(R.string.too_large); return false }
            val s = prefs
            val c1 = auto.copy(
                nCtx = if (s.ctxSize > 0) minOf(s.ctxSize, info.ctxTrain) else auto.nCtx,
                nThreads = if (s.threads > 0) s.threads else auto.nThreads,
                kv = if (s.kv >= 0) KvType.values()[s.kv] else auto.kv,
            )
            val cfg = c1.copy(nBatch = minOf(c1.nBatch, c1.nCtx), flashAttn = c1.flashAttn || c1.kv != KvType.F16)
            engine.load(f.path, name, cfg)
            last = f to name
            guard?.stop()
            guard = ThermalGuard(app, cfg.nThreads) { engine.requestThreads(it) }.also { it.start() }
            status = null
            return true
        } catch (e: EngineException) {
            // engine process died: restart it in safe CPU mode for the next attempt
            prefs.safeCpu = true
            prefs.save()
            engine.setSafe(true)
            status = str(R.string.crashed)
        } catch (e: Exception) {
            status = str(R.string.error) + ": " + e.message
        }
        return false
    }

    fun send(text: String) {
        if (text.isBlank() || streaming) return
        messages += ChatMsg("user", text)
        messages += ChatMsg("assistant", "")
        streaming = true
        job = viewModelScope.launch {
            try {
                if (loaded.value == null) {
                    val l = last
                    if (l == null) { status = str(R.string.no_model); return@launch }
                    if (!loadModel(l.first, l.second)) return@launch
                }
                val sys = ChatMsg("system", prefs.system.ifBlank { DEFAULT_SYSTEM })
                val sp = SamplerParams(prefs.maxTokens, prefs.temp, prefs.topP, prefs.topK)
                var rest = messages.dropLast(1).toList()
                while (true) {
                    try {
                        val sb = StringBuilder()
                        engine.generate(listOf(sys) + rest, sp).collect {
                            sb.append(it)
                            messages[messages.lastIndex] = ChatMsg("assistant", sb.toString())
                        }
                        break
                    } catch (e: EngineException) {
                        if (e.code == -2 && rest.size > 1) rest = rest.drop(2)   // context full: drop oldest exchange
                        else { status = str(if (e.code == -9) R.string.crashed else R.string.error); break }
                    }
                }
                tps = engine.stats().second
            } finally {
                streaming = false
            }
        }
    }

    fun stop() { job?.cancel() }
    override fun onCleared() { guard?.stop() }
}
