# Kanbo AI
git submodule add https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp
Open in Android Studio → Run (release build for full speed).
