# Kanbo AI

Local LLM chat for Android (llama.cpp, arm64) with a Material 3 UI.

## Features
- Material 3 interface: light / dark / system theme, optional Material You dynamic colors, Arabic (RTL) and English.
- Chat history like ChatGPT / Gemini / Claude: side drawer, search, pin, rename, delete, grouped by date. Stored on the device.
- Model switcher in the top bar of the chat. Models screen with a catalog (DeepSeek R1 distills, Qwen3, Gemma 3, Phi-4 mini, Llama, ...),
  "Add from link" (any Hugging Face .gguf link) and "Import file".
- Reasoning models (DeepSeek-R1, Qwen3): the thinking is shown in a collapsible block. Qwen3 has a Thinking on/off chip.
- Memory: facts you share ("my name is ...", "remember that ...", "تذكّر أن ...") are saved on the phone and used in every chat.
  Within a chat the history is trimmed automatically to fit the context window, and a short digest of trimmed messages is kept.

## Build
1. `git clone https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp` (or add it as a submodule).
2. Open in Android Studio → Run, or use the GitHub Actions workflow.

Diagnostics: Settings → Engine log (copy button). Each load prints stage markers:
`nativeInspect` → `nativeLoad: weights loaded` → `nativeLoad: ready`. The last marker shows where a failure happened.
